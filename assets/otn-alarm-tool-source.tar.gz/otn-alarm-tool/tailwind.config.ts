/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'otn-bg': '#0a1929',
        'otn-card': '#1a2332',
        'otn-border': '#2d3d50',
        'otn-text': '#e0e0e0',
        'otn-accent': '#2196f3',
        'alarm-critical': '#f44336',
        'alarm-major': '#ff9800',
        'alarm-minor': '#ffc107',
        'alarm-info': '#2196f3',
      },
    },
  },
  plugins: [],
  corePlugins: {
    preflight: false,
  },
};
