@echo off
title 停止OTN告警工具
cd /d "%~dp0"
echo ========================================
echo   正在关闭服务器...
echo ========================================

:: 停掉node服务器
taskkill /f /im node.exe 2>nul

:: 释放端口
powershell -Command "Get-NetTCPConnection -ErrorAction SilentlyContinue | Where-Object { $_.LocalPort -in @(8899,8900) -and $_.State -eq 'Listen' } | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }" 2>nul

echo.
echo [OK] 服务器已停止，端口已释放。
echo 可以关闭此窗口了。
echo.
pause
