/**
 * Electron 主进程
 *
 * 职责（解决大数据量卡死问题）：
 * 1. XLS/XLSX 文件解析 — 在主进程而非渲染进程执行，不阻塞 UI
 * 2. 告警聚合计算 — 后台线程执行
 * 3. 文件系统读写 — 替代浏览器 IndexedDB，使用本地 JSON 存储
 * 4. 窗口管理 + 系统托盘
 */

const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const XLSX = require('xlsx');

// ============================
// 常量与状态
// ============================

const isDev = !app.isPackaged;
let mainWindow = null;

/** 数据存储目录（替代 IndexedDB） */
const DATA_DIR = path.join(app.getPath('userData'), 'alarm-data');

/** MIME 类型（导出用） */
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
};

// ============================
// 窗口管理
// ============================

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1000,
    minHeight: 700,
    title: 'OTN历史告警可视化巡检工具',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
    icon: path.join(__dirname, '..', 'public', 'icon.png'),
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:3000');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
  }
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

// ============================
// IPC: XLS 文件解析（解决卡死根因）
// ============================

ipcMain.handle('parse-xls', async (_event, filePath) => {
  try {
    const buf = fs.readFileSync(filePath);
    const workbook = XLSX.read(buf, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];

    // 转为二维数组，分块处理避免大文件内存溢出
    const allRows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
    return { success: true, rows: allRows, totalRows: allRows.length };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// ============================
// IPC: 文件选择对话框
// ============================

ipcMain.handle('open-file-dialog', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [
      { name: 'Excel 文件', extensions: ['xls', 'xlsx'] },
      { name: '所有文件', extensions: ['*'] },
    ],
  });
  if (result.canceled) return { canceled: true };
  return { canceled: false, filePath: result.filePaths[0], fileName: path.basename(result.filePaths[0]) };
});

// ============================
// IPC: 数据持久化（替代 IndexedDB）
// ============================

// 确保数据目录存在
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function getProjectDir(projectId) {
  const dir = path.join(DATA_DIR, projectId);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

ipcMain.handle('project-list', async () => {
  try {
    if (!fs.existsSync(DATA_DIR)) return [];
    const dirs = fs.readdirSync(DATA_DIR, { withFileTypes: true })
      .filter((d) => d.isDirectory());
    const projects = dirs.map((d) => {
      const metaPath = path.join(DATA_DIR, d.name, 'meta.json');
      if (fs.existsSync(metaPath)) {
        return JSON.parse(fs.readFileSync(metaPath, 'utf8'));
      }
      return null;
    }).filter(Boolean);
    return projects.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  } catch { return []; }
});

ipcMain.handle('project-create', async (_event, name) => {
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  const meta = { id, name, createdAt: now, updatedAt: now, alarmCount: 0, neCount: 0 };
  const dir = getProjectDir(id);
  fs.writeFileSync(path.join(dir, 'meta.json'), JSON.stringify(meta, null, 2));
  return meta;
});

ipcMain.handle('project-delete', async (_event, id) => {
  const dir = getProjectDir(id);
  fs.rmSync(dir, { recursive: true, force: true });
});

ipcMain.handle('project-rename', async (_event, id, name) => {
  const metaPath = path.join(getProjectDir(id), 'meta.json');
  const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
  meta.name = name;
  meta.updatedAt = new Date().toISOString();
  fs.writeFileSync(metaPath, JSON.stringify(meta, null, 2));
});

ipcMain.handle('data-save', async (_event, projectId, type, data) => {
  const filePath = path.join(getProjectDir(projectId), `${type}.json`);
  fs.writeFileSync(filePath, JSON.stringify(data));
  // 更新元数据
  const metaPath = path.join(getProjectDir(projectId), 'meta.json');
  const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
  meta.updatedAt = new Date().toISOString();
  if (type === 'alarms') meta.alarmCount = data.length;
  fs.writeFileSync(metaPath, JSON.stringify(meta, null, 2));
  return true;
});

ipcMain.handle('data-load', async (_event, projectId, type) => {
  const filePath = path.join(getProjectDir(projectId), `${type}.json`);
  try {
    const data = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(data);
  } catch { return []; }
});

ipcMain.handle('project-export', async (_event, projectId) => {
  const dir = getProjectDir(projectId);
  const meta = JSON.parse(fs.readFileSync(path.join(dir, 'meta.json'), 'utf8'));
  const alarms = await loadDataFile(projectId, 'alarms');
  const networkElements = await loadDataFile(projectId, 'networkElements');
  const alarmTypeDefinitions = await loadDataFile(projectId, 'alarmTypeDefinitions');
  const exportData = { version: 1, exportedAt: new Date().toISOString(), project: meta, alarms, networkElements, alarmTypeDefinitions };

  const result = await dialog.showSaveDialog(mainWindow, {
    defaultPath: `otn-backup-${meta.name}-${new Date().toISOString().slice(0, 10)}.json`,
    filters: [{ name: 'JSON 备份', extensions: ['json'] }],
  });
  if (!result.canceled && result.filePath) {
    fs.writeFileSync(result.filePath, JSON.stringify(exportData, null, 2));
    return { success: true, path: result.filePath };
  }
  return { success: false };
});

ipcMain.handle('project-import', async (_event) => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [{ name: 'JSON 备份', extensions: ['json'] }],
  });
  if (result.canceled) return { canceled: true };

  const raw = fs.readFileSync(result.filePaths[0], 'utf8');
  const data = JSON.parse(raw);

  // 创建新项目
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  const meta = { ...data.project, id, createdAt: now, updatedAt: now };
  const dir = getProjectDir(id);
  fs.writeFileSync(path.join(dir, 'meta.json'), JSON.stringify(meta, null, 2));
  fs.writeFileSync(path.join(dir, 'alarms.json'), JSON.stringify(data.alarms || []));
  fs.writeFileSync(path.join(dir, 'networkElements.json'), JSON.stringify(data.networkElements || []));
  fs.writeFileSync(path.join(dir, 'alarmTypeDefinitions.json'), JSON.stringify(data.alarmTypeDefinitions || []));

  return { success: true, project: meta, alarms: data.alarms || [], networkElements: data.networkElements || [], alarmTypeDefinitions: data.alarmTypeDefinitions || [] };
});

async function loadDataFile(projectId, type) {
  const filePath = path.join(getProjectDir(projectId), `${type}.json`);
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch { return []; }
}

// ============================
// IPC: 告警聚合（后台执行）
// ============================

ipcMain.handle('aggregate-alarms', async (_event, alarms, windowMinutes) => {
  // 在下一个 tick 执行，不阻塞主进程
  return new Promise((resolve) => {
    setImmediate(() => {
      const result = aggregateWorker(alarms, windowMinutes || 15);
      resolve(result);
    });
  });
});

/** 纯计算函数：告警聚合（从原有的 alarmAggregator 移植） */
function aggregateWorker(alarms, windowMinutes) {
  if (!alarms || alarms.length < 2) return [];

  const windowMs = windowMinutes * 60 * 1000;
  const sorted = [...alarms].sort((a, b) => new Date(a.firstOccurTime).getTime() - new Date(b.firstOccurTime).getTime());

  // 滑动窗口分群
  const clusters = [];
  let current = [sorted[0]];
  for (let i = 1; i < sorted.length; i++) {
    const gap = new Date(sorted[i].firstOccurTime).getTime() - new Date(sorted[i - 1].firstOccurTime).getTime();
    const effectiveWindow = sorted[i].neName === sorted[i-1].neName ? windowMs * 3 : windowMs;
    if (gap <= effectiveWindow) {
      current.push(sorted[i]);
    } else {
      if (current.length >= 2) clusters.push(current);
      current = [sorted[i]];
    }
  }
  if (current.length >= 2) clusters.push(current);

  // 每个簇分析根因
  const groups = clusters.map((cluster) => {
    const levelOrder = { 紧急: 4, 主要: 3, 次要: 2, 提示: 1 };
    const rootCause = cluster.reduce((best, cur) => {
      const bestScore = (7 - layerOf(best)) * 0.5 + levelOrder[best.alarmLevel] * 0.3;
      const curScore = (7 - layerOf(cur)) * 0.5 + levelOrder[cur.alarmLevel] * 0.3;
      return curScore > bestScore ? cur : best;
    });

    const derived = cluster.filter((a) => a.id !== rootCause.id)
      .sort((a, b) => levelOrder[b.alarmLevel] - levelOrder[a.alarmLevel]);

    return {
      id: crypto.randomUUID(),
      neName: rootCause.neName,
      boardName: rootCause.boardName,
      slotNo: rootCause.slotNo,
      windowStart: cluster[0].firstOccurTime,
      windowEnd: cluster[cluster.length - 1].firstOccurTime,
      alarms: [rootCause, ...derived],
      rootCauseAlarm: { ...rootCause, _isRootCause: true },
      rootCauseScore: 0.95,
      severity: cluster.length >= 10 ? 'storm' : cluster.length >= 5 ? 'cluster' : 'scattered',
      derivedCount: derived.length,
    };
  });

  groups.sort((a, b) => {
    const p = { storm: 3, cluster: 2, scattered: 1 };
    return (p[b.severity] - p[a.severity]) || (b.derivedCount - a.derivedCount);
  });

  return groups;
}

function layerOf(alarm) {
  const c = (alarm.alarmTitle + ' ' + alarm.alarmName).toUpperCase();
  if (/RLOS|LOS |POWER_DOWN|LASER_TF/.test(c)) return 0;
  if (/IOP_LOW|IOP_HIGH|ILS|OLS/.test(c)) return 1;
  if (/^OSC_|FERF/.test(c)) return 2;
  if (/^ODU_|^OTU_/.test(c)) return 3;
  if (/ETH_|PTP_|PACKET/.test(c)) return 4;
  return 5;
}
