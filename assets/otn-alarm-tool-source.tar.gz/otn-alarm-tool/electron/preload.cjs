/**
 * Electron 预加载脚本
 *
 * 通过 contextBridge 安全地向渲染进程暴露主进程能力，
 * 渲染进程无需 nodeIntegration 即可调用主进程的 IPC 处理函数。
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // ========== 文件操作 ==========
  /** 打开文件选择对话框，返回文件路径 */
  openFileDialog: () => ipcRenderer.invoke('open-file-dialog'),

  /** 解析 XLS/XLSX 文件（在主进程执行，不阻塞 UI） */
  parseXLS: (filePath) => ipcRenderer.invoke('parse-xls', filePath),

  // ========== 项目管理 ==========
  /** 获取项目列表 */
  getProjects: () => ipcRenderer.invoke('project-list'),
  /** 创建新项目 */
  createProject: (name) => ipcRenderer.invoke('project-create', name),
  /** 删除项目 */
  deleteProject: (id) => ipcRenderer.invoke('project-delete', id),
  /** 重命名项目 */
  renameProject: (id, name) => ipcRenderer.invoke('project-rename', id, name),
  /** 导出项目 */
  exportProject: (id) => ipcRenderer.invoke('project-export', id),
  /** 导入项目 */
  importProject: () => ipcRenderer.invoke('project-import'),

  // ========== 数据存取 ==========
  /** 保存数据（alarms/networkElements/alarmTypeDefinitions） */
  saveData: (projectId, type, data) => ipcRenderer.invoke('data-save', projectId, type, data),
  /** 加载数据 */
  loadData: (projectId, type) => ipcRenderer.invoke('data-load', projectId, type),

  // ========== 告警分析 ==========
  /** 在后台执行告警聚合计算（不阻塞 UI） */
  aggregateAlarms: (alarms, windowMinutes) => ipcRenderer.invoke('aggregate-alarms', alarms, windowMinutes),
});
