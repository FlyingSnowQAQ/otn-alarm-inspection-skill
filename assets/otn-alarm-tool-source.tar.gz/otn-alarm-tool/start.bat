@echo off
chcp 65001 >nul
title OTN Alarm Tool
cd /d "%~dp0"

echo.
echo ========================================
echo   OTN Alarm Inspection Tool
echo   Starting...
echo ========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Node.js not found - install from https://nodejs.org/
    pause
    exit /b 1
)

if not exist "dist\index.html" (
    echo [INFO] Building project first...
    call npm run build
)

echo.
echo [INFO] Open http://localhost:8080 after server starts
echo [INFO] Close this window to stop server
echo.
node scripts\server.js
pause
