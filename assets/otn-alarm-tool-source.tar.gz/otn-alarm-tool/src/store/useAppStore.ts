import { create } from 'zustand';
import type {
  NetworkElement,
  AlarmRecord,
  AlarmTypeDefinition,
  PageRoute,
  ProjectMeta,
  AggregationViewMode,
  TimeWindowMinutes,
} from '../types';
import { mockNetworkElements, mockAlarms, mockAlarmTypeDefinitions, extraNetworkElements } from '../data/mockData';
import * as db from '../db';

/** Electron IPC 接口定义 */
interface ElectronAPI {
  openFileDialog: () => Promise<any>;
  parseXLS: (path: string) => Promise<any>;
  getProjects: () => Promise<any>;
  createProject: (name: string) => Promise<any>;
  deleteProject: (id: string) => Promise<void>;
  renameProject: (id: string, name: string) => Promise<void>;
  saveData: (projectId: string, type: string, data: any) => Promise<boolean>;
  loadData: (projectId: string, type: string) => Promise<any>;
  exportProject: (id: string) => Promise<any>;
  importProject: () => Promise<any>;
  aggregateAlarms: (alarms: AlarmRecord[], windowMinutes: number) => Promise<any>;
}

/** Electron IPC 适配层：浏览器端用 IndexedDB，Electron 端用主进程 IPC */
const electronAPI = (globalThis as any).electronAPI as ElectronAPI | undefined;
const api: ElectronAPI | null = electronAPI || null;

/** 是否运行在 Electron 环境中 */
const isElectron = !!api;

/** 应用全局状态接口 */
interface AppState {
  // ========== V1.0 现有状态 ==========
  /** 当前页面路由 */
  currentPage: PageRoute;
  /** 网元列表 */
  networkElements: NetworkElement[];
  /** 告警列表 */
  alarms: AlarmRecord[];
  /** 告警类型定义列表 */
  alarmTypeDefinitions: AlarmTypeDefinition[];
  /** 侧边栏是否折叠 */
  sidebarCollapsed: boolean;

  // ========== V1.1 新增状态 ==========
  /** 项目列表 */
  projects: ProjectMeta[];
  /** 当前活跃项目ID（null 表示使用 mockData） */
  activeProjectId: string | null;
  /** 聚合视图模式 */
  aggregationViewMode: AggregationViewMode;
  /** 聚合时间窗口（分钟） */
  aggregationWindow: TimeWindowMinutes;

  // ========== V1.0 现有 actions ==========
  /** 切换页面 */
  setCurrentPage: (page: PageRoute) => void;
  /** 设置网元列表 */
  setNetworkElements: (elements: NetworkElement[]) => void;
  /** 添加告警（导入追加） */
  addAlarms: (alarms: AlarmRecord[]) => void;
  /** 设置告警列表 */
  setAlarms: (alarms: AlarmRecord[]) => void;
  /** 设置告警类型定义列表 */
  setAlarmTypeDefinitions: (definitions: AlarmTypeDefinition[]) => void;
  /** 切换侧边栏折叠状态 */
  toggleSidebar: () => void;

  // ========== V1.1 新增 actions ==========
  /** 项目数据加载：从 IndexedDB 加载所有项目，无项目则加载 mockData */
  loadProjects: () => Promise<void>;
  /** 切换项目 */
  switchProject: (id: string) => Promise<void>;
  /** 创建新项目 */
  createProject: (name: string) => Promise<void>;
  /** 删除项目 */
  deleteProject: (id: string) => Promise<void>;
  /** 重命名项目 */
  renameProject: (id: string, name: string) => Promise<void>;
  /** 将当前 store 数据持久化到 IndexedDB */
  persistCurrentProject: () => Promise<void>;
  /** 设置聚合时间窗口 */
  setAggregationWindow: (minutes: TimeWindowMinutes) => void;
  /** 设置聚合视图模式 */
  setAggregationViewMode: (mode: AggregationViewMode) => void;
  /** 导出当前项目备份为 JSON */
  exportBackup: () => Promise<string>;
  /** 从 JSON 导入备份 */
  importBackup: (json: string) => Promise<void>;
}

/** 应用全局状态管理 */
const useAppStore = create<AppState>((set, get) => ({
  // ========== V1.0 默认值 ==========
  currentPage: 'dashboard',
  // 合并 mock 网元 + 新加24省网元（类型断言处理扩展网元）
  networkElements: [...mockNetworkElements, ...extraNetworkElements] as NetworkElement[] as NetworkElement[],
  alarms: mockAlarms,
  alarmTypeDefinitions: mockAlarmTypeDefinitions,
  sidebarCollapsed: false,

  // ========== V1.1 默认值 ==========
  projects: [],
  activeProjectId: null,
  aggregationViewMode: 'detail',
  aggregationWindow: 15,

  // ========== V1.0 actions ==========
  setCurrentPage: (page) => set({ currentPage: page }),
  setNetworkElements: (elements) => set({ networkElements: elements }),
  addAlarms: (newAlarms) =>
    set((state) => {
      const updated = [...state.alarms, ...newAlarms];
      // 异步持久化，不阻塞 UI
      if (state.activeProjectId) {
        db.saveAlarms(state.activeProjectId, updated).catch((err) =>
          console.error('[Store] addAlarms persist failed:', err)
        );
      }
      return { alarms: updated };
    }),
  setAlarms: (alarms) => set({ alarms }),
  setAlarmTypeDefinitions: (definitions) =>
    set({ alarmTypeDefinitions: definitions }),
  toggleSidebar: () =>
    set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),

  // ========== V1.1 actions ==========

  /**
   * 加载项目列表
   * - Electron 端：通过 IPC 从主进程加载（文件系统）
   * - 浏览器端：通过 IndexedDB 加载
   */
  loadProjects: async () => {
    try {
      if (isElectron && api) {
        const projects = await api.getProjects();
        set({ projects });

        if (projects.length > 0) {
          const first = projects[0];
          const [alarms, networkElements, alarmTypeDefinitions] = await Promise.all([
            api.loadData(first.id, 'alarms'),
            api.loadData(first.id, 'networkElements'),
            api.loadData(first.id, 'alarmTypeDefinitions'),
          ]);
          set({
            activeProjectId: first.id,
            alarms: alarms.length > 0 ? alarms : mockAlarms,
            networkElements: networkElements.length > 0 ? networkElements : [...mockNetworkElements, ...extraNetworkElements] as NetworkElement[] as NetworkElement[],
            alarmTypeDefinitions: alarmTypeDefinitions.length > 0 ? alarmTypeDefinitions : mockAlarmTypeDefinitions,
          });
        } else {
          set({ activeProjectId: null, alarms: mockAlarms, networkElements: [...mockNetworkElements, ...extraNetworkElements] as NetworkElement[], alarmTypeDefinitions: mockAlarmTypeDefinitions });
        }
        return;
      }

      // 浏览器端：使用 IndexedDB
      const projects = await db.getAllProjects();
      set({ projects });

      if (projects.length > 0) {
        const firstProject = projects[0];
        const [alarms, networkElements, alarmTypeDefinitions] = await Promise.all([
          db.loadAlarms(firstProject.id),
          db.loadNetworkElements(firstProject.id),
          db.loadAlarmTypeDefinitions(firstProject.id),
        ]);
        set({
          activeProjectId: firstProject.id,
          alarms: alarms.length > 0 ? alarms : mockAlarms,
          networkElements: networkElements.length > 0 ? networkElements : [...mockNetworkElements, ...extraNetworkElements] as NetworkElement[],
          alarmTypeDefinitions:
            alarmTypeDefinitions.length > 0
              ? alarmTypeDefinitions
              : mockAlarmTypeDefinitions,
        });
      } else {
        // 无项目：使用 mockData（含扩展网元）
        set({
          activeProjectId: null,
          alarms: mockAlarms,
          networkElements: [...mockNetworkElements, ...extraNetworkElements] as NetworkElement[],
          alarmTypeDefinitions: mockAlarmTypeDefinitions,
        });
      }
    } catch (err) {
      console.error('[Store] loadProjects failed:', err);
      // 降级：使用 mockData（含扩展网元）
      set({
        projects: [],
        activeProjectId: null,
        alarms: mockAlarms,
        networkElements: [...mockNetworkElements, ...extraNetworkElements] as NetworkElement[],
        alarmTypeDefinitions: mockAlarmTypeDefinitions,
      });
    }
  },

  /**
   * 切换项目：先持久化当前项目，再加载目标项目
   */
  switchProject: async (id: string) => {
    const state = get();
    if (state.activeProjectId) {
      await state.persistCurrentProject();
    }

    try {
      let alarms: AlarmRecord[], networkElements: NetworkElement[], alarmTypeDefinitions: AlarmTypeDefinition[];
      if (isElectron && api) {
        [alarms, networkElements, alarmTypeDefinitions] = await Promise.all([
          api.loadData(id, 'alarms'),
          api.loadData(id, 'networkElements'),
          api.loadData(id, 'alarmTypeDefinitions'),
        ]);
      } else {
        [alarms, networkElements, alarmTypeDefinitions] = await Promise.all([
          db.loadAlarms(id),
          db.loadNetworkElements(id),
          db.loadAlarmTypeDefinitions(id),
        ]);
      }
      set({ activeProjectId: id, alarms, networkElements, alarmTypeDefinitions });
    } catch (err) {
      console.error('[Store] switchProject failed:', err);
    }
  },

  /**
   * 创建新项目
   */
  createProject: async (name: string) => {
    const state = get();
    if (state.activeProjectId) {
      await state.persistCurrentProject();
    }

    let project: ProjectMeta;
    if (isElectron && api) {
      project = await api.createProject(name);
    } else {
      project = await db.createProject(name);
    }
    const projects = isElectron && api ? await api.getProjects() : await db.getAllProjects();
    set({ projects, activeProjectId: project.id, alarms: [], networkElements: [], alarmTypeDefinitions: [] });
  },

  /**
   * 删除项目
   */
  deleteProject: async (id: string) => {
    if (isElectron && api) {
      await api.deleteProject(id);
    } else {
      await db.deleteProject(id);
    }
    const projects = isElectron && api ? await api.getProjects() : await db.getAllProjects();

    if (id === get().activeProjectId) {
      if (projects.length > 0) {
        const first = projects[0];
        let alarms: AlarmRecord[], networkElements: NetworkElement[], alarmTypeDefinitions: AlarmTypeDefinition[];
        if (isElectron && api) {
          [alarms, networkElements, alarmTypeDefinitions] = await Promise.all([
            api.loadData(first.id, 'alarms'),
            api.loadData(first.id, 'networkElements'),
            api.loadData(first.id, 'alarmTypeDefinitions'),
          ]);
        } else {
          [alarms, networkElements, alarmTypeDefinitions] = await Promise.all([
            db.loadAlarms(first.id),
            db.loadNetworkElements(first.id),
            db.loadAlarmTypeDefinitions(first.id),
          ]);
        }
        set({ projects, activeProjectId: first.id, alarms, networkElements, alarmTypeDefinitions });
      } else {
        set({ projects: [], activeProjectId: null, alarms: mockAlarms, networkElements: [...mockNetworkElements, ...extraNetworkElements] as NetworkElement[], alarmTypeDefinitions: mockAlarmTypeDefinitions });
      }
    } else {
      set({ projects });
    }
  },

  /**
   * 重命名项目
   */
  renameProject: async (id: string, name: string) => {
    if (isElectron && api) {
      await api.renameProject(id, name);
      const projects = await api.getProjects();
      set({ projects });
    } else {
      await db.updateProject(id, { name });
      const projects = await db.getAllProjects();
      set({ projects });
    }
  },

  /**
   * 持久化当前项目数据
   */
  persistCurrentProject: async () => {
    const { activeProjectId, alarms, networkElements, alarmTypeDefinitions } = get();
    if (!activeProjectId) return;

    try {
      if (isElectron && api) {
        await Promise.all([
          api.saveData(activeProjectId, 'alarms', alarms),
          api.saveData(activeProjectId, 'networkElements', networkElements),
          api.saveData(activeProjectId, 'alarmTypeDefinitions', alarmTypeDefinitions),
        ]);
      } else {
        await Promise.all([
          db.saveAlarms(activeProjectId, alarms),
          db.saveNetworkElements(activeProjectId, networkElements),
          db.saveAlarmTypeDefinitions(activeProjectId, alarmTypeDefinitions),
        ]);
        const dataSize = await db.getProjectDataSize(activeProjectId);
        await db.updateProject(activeProjectId, { alarmCount: alarms.length, neCount: networkElements.length, dataSizeBytes: dataSize });
      }
      const projects = isElectron && api ? await api.getProjects() : await db.getAllProjects();
      set({ projects });
    } catch (err) {
      console.error('[Store] persistCurrentProject failed:', err);
    }
  },

  setAggregationWindow: (minutes) => set({ aggregationWindow: minutes }),
  setAggregationViewMode: (mode) => set({ aggregationViewMode: mode }),

  /**
   * 导出当前项目备份
   */
  exportBackup: async () => {
    if (isElectron && api) {
      const result = await api.exportProject(get().activeProjectId!);
      if (result.success) return result.path;
      throw new Error('Export cancelled');
    }
    const { activeProjectId } = get();
    if (!activeProjectId) throw new Error('No active project to export');
    return db.exportProjectJSON(activeProjectId);
  },

  /**
   * 导入备份
   */
  importBackup: async (json: string) => {
    if (isElectron && api) {
      const result = await api.importProject();
      if (result.canceled || !result.success) return;
      // 已导入到主进程，刷新项目列表和数据
      const projects = await api.getProjects();
      set({ projects, activeProjectId: result.project.id, alarms: result.alarms, networkElements: result.networkElements, alarmTypeDefinitions: result.alarmTypeDefinitions });
      return;
    }
    const project = await db.importProjectJSON(json);
    const projects = await db.getAllProjects();
    const [alarms, networkElements, alarmTypeDefinitions] = await Promise.all([
      db.loadAlarms(project.id),
      db.loadNetworkElements(project.id),
      db.loadAlarmTypeDefinitions(project.id),
    ]);
    set({ projects, activeProjectId: project.id, alarms, networkElements, alarmTypeDefinitions });
  },
}));

export default useAppStore;
