import React from 'react';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import theme from './theme';
import useAppStore from './store/useAppStore';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Topology from './pages/Topology';
import AlarmAnalysis from './pages/AlarmAnalysis';
import Import from './pages/Import';
import Report from './pages/Report';
import Projects from './pages/Projects';

/** 页面路由映射 */
const PAGE_MAP: Record<string, React.ReactNode> = {
  dashboard: <Dashboard />,
  topology: <Topology />,
  analysis: <AlarmAnalysis />,
  import: <Import />,
  report: <Report />,
  projects: <Projects />,
};

/** 应用根组件 */
const App: React.FC = () => {
  const currentPage = useAppStore((state) => state.currentPage);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Layout>
        {PAGE_MAP[currentPage] || <Dashboard />}
      </Layout>
    </ThemeProvider>
  );
};

export default App;
