import React from 'react';
import {
  Box,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Divider,
  Chip,
} from '@mui/material';
import DashboardIcon from '@mui/icons-material/Dashboard';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import AssessmentIcon from '@mui/icons-material/Assessment';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import SummarizeIcon from '@mui/icons-material/Summarize';
import FolderIcon from '@mui/icons-material/Folder';
import MenuIcon from '@mui/icons-material/Menu';
import NotificationsIcon from '@mui/icons-material/Notifications';
import SettingsIcon from '@mui/icons-material/Settings';
import useAppStore from '../store/useAppStore';
import type { PageRoute } from '../types';

/** 侧边栏宽度 */
const DRAWER_WIDTH = 240;
const DRAWER_WIDTH_COLLAPSED = 64;

/** 导航菜单项配置 */
const NAV_ITEMS: { key: PageRoute; label: string; icon: React.ReactNode }[] = [
  { key: 'dashboard', label: '仪表盘', icon: <DashboardIcon /> },
  { key: 'topology', label: '拓扑视图', icon: <AccountTreeIcon /> },
  { key: 'analysis', label: '告警分析', icon: <AssessmentIcon /> },
  { key: 'import', label: '数据导入', icon: <UploadFileIcon /> },
  { key: 'report', label: '报表', icon: <SummarizeIcon /> },
  { key: 'projects', label: '项目管理', icon: <FolderIcon /> },
];

/** 应用主布局组件 */
const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentPage, setCurrentPage, sidebarCollapsed, toggleSidebar, alarms } =
    useAppStore();

  const criticalCount = alarms.filter(
    (a) => a.alarmLevel === '紧急' && a.alarmStatus !== '已确认已清除'
  ).length;

  const drawerWidth = sidebarCollapsed ? DRAWER_WIDTH_COLLAPSED : DRAWER_WIDTH;

  return (
    <Box sx={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      {/* 侧边导航栏 */}
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: drawerWidth,
            boxSizing: 'border-box',
            backgroundColor: '#0d1b2a',
            borderRight: '1px solid #2d3d50',
            transition: 'width 0.2s ease',
            overflowX: 'hidden',
          },
        }}
      >
        {/* Logo 区域 */}
        <Box
          sx={{
            height: 64,
            display: 'flex',
            alignItems: 'center',
            justifyContent: sidebarCollapsed ? 'center' : 'flex-start',
            px: sidebarCollapsed ? 0 : 2,
            borderBottom: '1px solid #2d3d50',
          }}
        >
          {sidebarCollapsed ? (
            <Typography
              sx={{
                fontSize: 18,
                fontWeight: 700,
                color: '#2196f3',
              }}
            >
              OTN
            </Typography>
          ) : (
            <Typography
              sx={{
                fontSize: 16,
                fontWeight: 700,
                color: '#2196f3',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
              }}
            >
              OTN告警巡检工具
            </Typography>
          )}
        </Box>

        {/* 导航菜单 */}
        <List sx={{ pt: 1 }}>
          {NAV_ITEMS.map((item) => (
            <ListItem key={item.key} disablePadding sx={{ display: 'block' }}>
              <ListItemButton
                onClick={() => setCurrentPage(item.key)}
                sx={{
                  minHeight: 48,
                  justifyContent: sidebarCollapsed ? 'center' : 'initial',
                  px: 2.5,
                  backgroundColor:
                    currentPage === item.key ? 'rgba(33,150,243,0.12)' : 'transparent',
                  borderLeft:
                    currentPage === item.key
                      ? '3px solid #2196f3'
                      : '3px solid transparent',
                  '&:hover': {
                    backgroundColor: 'rgba(33,150,243,0.08)',
                  },
                }}
              >
                <ListItemIcon
                  sx={{
                    minWidth: 0,
                    mr: sidebarCollapsed ? 0 : 2,
                    justifyContent: 'center',
                    color: currentPage === item.key ? '#2196f3' : '#9e9e9e',
                  }}
                >
                  {item.icon}
                </ListItemIcon>
                {!sidebarCollapsed && (
                  <ListItemText
                    primary={item.label}
                    sx={{
                      '& .MuiListItemText-primary': {
                        fontSize: 14,
                        fontWeight: currentPage === item.key ? 600 : 400,
                        color: currentPage === item.key ? '#e0e0e0' : '#9e9e9e',
                      },
                    }}
                  />
                )}
              </ListItemButton>
            </ListItem>
          ))}
        </List>

        <Divider sx={{ borderColor: '#2d3d50', mt: 'auto' }} />

        {/* 底部版本信息 */}
        {!sidebarCollapsed && (
          <Box sx={{ p: 2 }}>
            <Typography variant="caption" sx={{ color: '#666' }}>
              一干400G OTN网络
            </Typography>
            <br />
            <Typography variant="caption" sx={{ color: '#666' }}>
              烽火FONST设备 v1.0.0
            </Typography>
          </Box>
        )}
      </Drawer>

      {/* 主内容区域 */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* 顶部工具栏 */}
        <AppBar
          position="static"
          elevation={0}
          sx={{
            backgroundColor: '#0d1b2a',
            borderBottom: '1px solid #2d3d50',
          }}
        >
          <Toolbar sx={{ minHeight: '64px !important' }}>
            <IconButton
              edge="start"
              color="inherit"
              aria-label="toggle sidebar"
              onClick={toggleSidebar}
              sx={{ mr: 2 }}
            >
              <MenuIcon />
            </IconButton>

            <Typography variant="h6" sx={{ flexGrow: 1, fontWeight: 600 }}>
              {NAV_ITEMS.find((item) => item.key === currentPage)?.label || '仪表盘'}
            </Typography>

            {/* 告警通知 */}
            <IconButton color="inherit" sx={{ mr: 1 }}>
              <NotificationsIcon />
              {criticalCount > 0 && (
                <Chip
                  label={criticalCount}
                  size="small"
                  color="error"
                  sx={{
                    position: 'absolute',
                    top: 8,
                    right: 8,
                    height: 18,
                    fontSize: 11,
                    fontWeight: 700,
                    minWidth: 18,
                  }}
                />
              )}
            </IconButton>

            <IconButton color="inherit">
              <SettingsIcon />
            </IconButton>
          </Toolbar>
        </AppBar>

        {/* 页面内容 */}
        <Box
          sx={{
            flex: 1,
            overflow: 'auto',
            backgroundColor: '#0a1929',
            p: 2,
          }}
        >
          {children}
        </Box>
      </Box>
    </Box>
  );
};

export default Layout;
