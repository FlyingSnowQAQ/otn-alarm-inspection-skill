import React, { useState } from 'react';
import {
  Box,
  Card,
  Typography,
  Chip,
  Collapse,
  IconButton,
  List,
  ListItem,
  ListItemText,
  Tooltip,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import type { AlarmGroup, AlarmStormSeverity } from '../types';
import { ALARM_LEVEL_COLORS } from '../types';
import dayjs from 'dayjs';

/** 严重程度 → 显示标签及颜色 */
const SEVERITY_CONFIG: Record<AlarmStormSeverity, { label: string; color: string; bg: string }> = {
  storm: { label: '风暴', color: '#f44336', bg: '#f4433622' },
  cluster: { label: '聚集', color: '#ff9800', bg: '#ff980022' },
  scattered: { label: '零星', color: '#2196f3', bg: '#2196f322' },
};

/** 告警聚合时间线组件 Props */
interface AlarmTimelineProps {
  groups: AlarmGroup[];
}

/** 单个 AlarmGroup 卡片，含衍生告警折叠列表 */
const TimelineGroupCard: React.FC<{ group: AlarmGroup }> = ({ group }) => {
  const [expanded, setExpanded] = useState(false);
  const {
    neName,
    boardName,
    slotNo,
    severity,
    windowStart,
    windowEnd,
    alarms,
    rootCauseAlarm,
    derivedCount,
  } = group;

  const sevConfig = SEVERITY_CONFIG[severity];
  const derivedAlarms = alarms.filter((a) => a.id !== rootCauseAlarm.id);

  return (
    <Card
      sx={{
        backgroundColor: '#1a2332',
        borderLeft: `4px solid ${sevConfig.color}`,
        borderRadius: 2,
        mb: 1.5,
        overflow: 'hidden',
      }}
    >
      {/* 头部信息 */}
      <Box sx={{ p: 1.5, pb: 0.5 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap', mb: 0.5 }}>
          <Tooltip title={neName}>
            <Typography variant="body2" sx={{ fontWeight: 700, fontSize: 13, maxWidth: 220 }} noWrap>
              {neName.split('-').slice(2).join('-') || neName}
            </Typography>
          </Tooltip>
          <Chip
            label={`${sevConfig.label} (${alarms.length}条)`}
            size="small"
            sx={{
              backgroundColor: sevConfig.bg,
              color: sevConfig.color,
              fontWeight: 700,
              fontSize: 11,
              height: 22,
            }}
          />
        </Box>
        <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', mb: 0.5 }}>
          <Typography variant="caption" sx={{ color: '#9e9e9e' }}>
            槽位: {slotNo || '-'}
          </Typography>
          <Typography variant="caption" sx={{ color: '#9e9e9e' }}>
            单板: {boardName || '-'}
          </Typography>
        </Box>
        <Typography variant="caption" sx={{ color: '#9e9e9e', display: 'block', mb: 0.5 }}>
          {dayjs(windowStart).format('MM-DD HH:mm:ss')} ~ {dayjs(windowEnd).format('MM-DD HH:mm:ss')}
        </Typography>
      </Box>

      {/* 根因告警 */}
      <Box
        sx={{
          mx: 1.5,
          mb: 0.5,
          p: 1,
          backgroundColor: '#0d1a2b',
          borderRadius: 1,
          borderLeft: '3px solid #f44336',
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.8, mb: 0.3 }}>
          <Chip
            label="根因"
            size="small"
            sx={{
              backgroundColor: '#f4433622',
              color: '#f44336',
              fontWeight: 700,
              fontSize: 10,
              height: 20,
            }}
          />
          <Typography variant="caption" sx={{ fontWeight: 600, fontSize: 12 }}>
            {rootCauseAlarm.alarmTitle}
          </Typography>
        </Box>
        <Typography variant="caption" sx={{ color: '#9e9e9e', fontSize: 11 }}>
          {dayjs(rootCauseAlarm.firstOccurTime).format('MM-DD HH:mm:ss')}
          {' · '}
          级别: {rootCauseAlarm.alarmLevel}
          {' · '}
          得分: {group.rootCauseScore.toFixed(2)}
        </Typography>

        {/* 告警传播链 */}
        {group.propagationChain && (
          <Box sx={{ mt: 0.5, pt: 0.5, borderTop: '1px solid #2d3d5033' }}>
            <Typography variant="caption" sx={{ color: '#ff9800', fontSize: 10, fontWeight: 600, display: 'block', mb: 0.3 }}>
              传播链
            </Typography>
            <Typography variant="caption" sx={{ color: '#90caf9', fontSize: 10, wordBreak: 'break-all', lineHeight: 1.4 }}>
              {group.propagationChain}
            </Typography>
          </Box>
        )}

        {/* 拓扑影响摘要 */}
        {group.topologySummary && (
          <Box sx={{ mt: 0.5, pt: 0.5, borderTop: '1px solid #2d3d5033' }}>
            <Typography variant="caption" sx={{ color: '#ff5722', fontSize: 10, fontWeight: 600, display: 'block', mb: 0.3 }}>
              拓扑影响
            </Typography>
            <Typography variant="caption" sx={{ color: '#ffab91', fontSize: 10, lineHeight: 1.4 }}>
              {group.topologySummary}
            </Typography>
          </Box>
        )}
      </Box>

      {/* 衍生告警折叠区 */}
      <Box sx={{ px: 1.5, pb: 1 }}>
        <Box
          onClick={() => setExpanded(!expanded)}
          sx={{
            display: 'flex',
            alignItems: 'center',
            cursor: 'pointer',
            color: '#9e9e9e',
            '&:hover': { color: '#e0e0e0' },
          }}
        >
          <Typography variant="caption" sx={{ fontSize: 11 }}>
            衍生告警 ({derivedCount}条)
          </Typography>
          <IconButton size="small" sx={{ ml: 0.3, p: 0, color: 'inherit' }}>
            {expanded ? <ExpandLessIcon fontSize="small" /> : <ExpandMoreIcon fontSize="small" />}
          </IconButton>
        </Box>
        <Collapse in={expanded}>
          <List dense disablePadding sx={{ mt: 0.5 }}>
            {derivedAlarms.map((alarm) => (
              <ListItem
                key={alarm.id}
                sx={{
                  py: 0.3,
                  px: 1,
                  borderRadius: 1,
                  '&:hover': { backgroundColor: '#243447' },
                }}
              >
                <FiberManualRecordIcon
                  sx={{
                    fontSize: 8,
                    mr: 1,
                    color: ALARM_LEVEL_COLORS[alarm.alarmLevel],
                  }}
                />
                <ListItemText
                  primary={alarm.alarmTitle}
                  secondary={dayjs(alarm.firstOccurTime).format('MM-DD HH:mm:ss')}
                  primaryTypographyProps={{ fontSize: 12, noWrap: true }}
                  secondaryTypographyProps={{ fontSize: 11, color: '#9e9e9e' }}
                />
              </ListItem>
            ))}
          </List>
        </Collapse>
      </Box>
    </Card>
  );
};

/** 告警聚合时间线可视化组件 */
const AlarmTimeline: React.FC<AlarmTimelineProps> = ({ groups }) => {
  if (groups.length === 0) {
    return (
      <Card sx={{ backgroundColor: '#1a2332', p: 3, textAlign: 'center' }}>
        <Typography variant="body2" sx={{ color: '#9e9e9e' }}>
          暂无告警聚合数据
        </Typography>
      </Card>
    );
  }

  return (
    <Box sx={{ position: 'relative' }}>
      {/* 时间线竖线 */}
      <Box
        sx={{
          position: 'absolute',
          left: 12,
          top: 0,
          bottom: 0,
          width: 2,
          backgroundColor: '#2d3d50',
          zIndex: 0,
        }}
      />

      {groups.map((group) => (
        <Box key={group.id} sx={{ display: 'flex', mb: 1, position: 'relative', zIndex: 1 }}>
          {/* 左侧圆点 */}
          <Box sx={{ flexShrink: 0, width: 26, display: 'flex', justifyContent: 'center', pt: 2 }}>
            <FiberManualRecordIcon
              sx={{
                fontSize: 14,
                color: SEVERITY_CONFIG[group.severity].color,
              }}
            />
          </Box>

          {/* 右侧卡片内容 */}
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <TimelineGroupCard group={group} />
          </Box>
        </Box>
      ))}
    </Box>
  );
};

export default AlarmTimeline;
