import React, { useMemo } from 'react';
import {
  Card,
  CardContent,
  Typography,
  List,
  ListItem,
  ListItemText,
  Chip,
  Box,
  Tooltip,
  Divider,
} from '@mui/material';
import WhatshotIcon from '@mui/icons-material/Whatshot';
import useAppStore from '../store/useAppStore';
import { aggregate } from '../utils/alarmAggregator';
import type { AlarmStormSeverity } from '../types';

/** 严重程度 Chip 样式配置 */
const SEVERITY_CHIP_STYLES: Record<AlarmStormSeverity, { label: string; color: string; bg: string }> = {
  storm: { label: '风暴', color: '#f44336', bg: '#f4433622' },
  cluster: { label: '聚集', color: '#ff9800', bg: '#ff980022' },
  scattered: { label: '零星', color: '#2196f3', bg: '#2196f322' },
};

/** 告警风暴 Top10 卡片组件 */
const AlarmStormCard: React.FC = () => {
  const alarms = useAppStore((state) => state.alarms);

  /** 聚合结果（15分钟窗口），按 derivedCount 降序取前 10 */
  const topGroups = useMemo(() => {
    // 只取尾部最新 5000 条告警做聚合，避免全量 20 万条排序阻塞主线程
    const recentAlarms = alarms.slice(Math.max(0, alarms.length - 5000));
    const groups = aggregate(recentAlarms, 15, true);
    return groups
      .sort((a, b) => b.derivedCount - a.derivedCount)
      .slice(0, 10);
  }, [alarms]);

  if (topGroups.length === 0) {
    return (
      <Card sx={{ backgroundColor: '#1a2332', height: '100%' }}>
        <CardContent>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
            <WhatshotIcon sx={{ color: '#f44336' }} />
            <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
              告警风暴 Top10
            </Typography>
          </Box>
          <Typography variant="body2" sx={{ color: '#9e9e9e', textAlign: 'center', py: 4 }}>
            暂无告警风暴数据
          </Typography>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card sx={{ backgroundColor: '#1a2332', height: '100%' }}>
      <CardContent sx={{ pb: '12px !important' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
          <WhatshotIcon sx={{ color: '#f44336' }} />
          <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
            告警风暴 Top10
          </Typography>
          <Chip
            label={`${topGroups.length} 组`}
            size="small"
            sx={{
              ml: 'auto',
              backgroundColor: '#2d3d5044',
              color: '#9e9e9e',
              fontSize: 11,
              height: 20,
            }}
          />
        </Box>

        <List dense disablePadding>
          {topGroups.map((group, index) => {
            const sevStyle = SEVERITY_CHIP_STYLES[group.severity];
            const displayName = group.neName.split('-').slice(2).join('-') || group.neName;

            return (
              <React.Fragment key={group.id}>
                <ListItem sx={{ px: 0, py: 0.6, alignItems: 'flex-start' }}>
                  {/* 排名序号 */}
                  <Typography
                    variant="body2"
                    sx={{
                      fontWeight: 700,
                      minWidth: 20,
                      mr: 1,
                      color: index < 3 ? '#f44336' : '#9e9e9e',
                      fontSize: index < 3 ? 14 : 12,
                    }}
                  >
                    {index + 1}
                  </Typography>

                  {/* 主要内容 */}
                  <ListItemText
                    primary={
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.8, flexWrap: 'wrap' }}>
                        <Tooltip title={group.neName}>
                          <Typography
                            variant="body2"
                            noWrap
                            sx={{ fontSize: 13, fontWeight: 600, maxWidth: 140 }}
                          >
                            {displayName}
                          </Typography>
                        </Tooltip>
                        <Chip
                          label={`+${group.derivedCount}条`}
                          size="small"
                          sx={{
                            backgroundColor: sevStyle.bg,
                            color: sevStyle.color,
                            fontWeight: 700,
                            fontSize: 10,
                            height: 20,
                          }}
                        />
                        <Chip
                          label={sevStyle.label}
                          size="small"
                          sx={{
                            backgroundColor: sevStyle.bg,
                            color: sevStyle.color,
                            fontWeight: 600,
                            fontSize: 10,
                            height: 20,
                          }}
                        />
                      </Box>
                    }
                    secondary={
                      <Typography
                        variant="caption"
                        noWrap
                        sx={{ color: '#9e9e9e', fontSize: 11, mt: 0.2, display: 'block' }}
                      >
                        根因: {group.rootCauseAlarm.alarmTitle}
                      </Typography>
                    }
                    primaryTypographyProps={{ component: 'div' }}
                    secondaryTypographyProps={{ component: 'div' }}
                  />
                </ListItem>
                {index < topGroups.length - 1 && (
                  <Divider sx={{ borderColor: '#2d3d5033' }} />
                )}
              </React.Fragment>
            );
          })}
        </List>
      </CardContent>
    </Card>
  );
};

export default AlarmStormCard;
