/**
 * OTN 告警根因聚合分析 — 基于知识库 + 拓扑结构重写
 *
 * ## 核心原理
 *
 * ### 1. OTN分层传播模型（来自烽火告警清单）
 *    物理层(光缆) → 光层(OTS/OMS) → OSC → 电层(ODU/OTU) → 业务层
 *
 * ### 2. 拓扑感知的根因推断（新增）
 *    同一复用段(OMS/line-system)的多个网元同时上报告警 → 共享光缆段中断
 *    相邻网元告警级联 → 沿光纤路径传播
 *
 * ### 3. 告警码语义规则
 *    - AIS/LCK/OCI → 上游故障的被动指示（衍生）
 *    - LOS/RLOS/LOF → 信号中断（可能是根因或传播）
 *    - FAIL/COMFAIL/POWER → 本地设备故障（根因）
 *    - BDI/BEI/FDI → 对端/前向反馈（衍生）
 *
 * ### 4. 拓扑传播场景
 *    光缆断 → 该OMS上所有单波RLOS → 沿线各站LOS → 电层AIS级联
 *    多站同时RLOS，且处于同一条OMS链路 → 共享段光缆中断
 */

import type { AlarmRecord, AlarmGroup, AlarmStormSeverity } from '../types';
import { ALARM_LEVEL_ORDER } from '../types';
import { mockTopologyLinks } from '../data/mockData';
import { SYSTEM_NE_MAP } from '../data/neSystemMap';

// ============================
// 1. OTN 分层映射
// ============================

const OTN_LAYER: Record<string, number> = {
  PHY: 0, OTS: 1, OMS: 2, OCH: 3,
  OSC: 4, ODU: 5, OTU: 5, PKT: 6, DEV: 7, OAM: 8,
};

function inferAlarmLayer(alarm: AlarmRecord): number {
  const c = (alarm.alarmTitle + ' ' + alarm.alarmName).toUpperCase();

  if (/POWER_DOWN|POWERALM|POWER_LOW|POWER_HIGH|DCVOL|SHUT_DOWN|FANALM|TEMP_TCT|TEMP_ABNORMAL|CASETEMP|LIGHTNING_PRO/.test(c))
    return OTN_LAYER.PHY;
  if (/OTS_|OMS_/.test(c) && !/ODU_|OTU_/.test(c))
    return OTN_LAYER.OTS;
  if (/RLOS/.test(c))
    return OTN_LAYER.OTS;
  if (/^OSC_|FERF|MANUAL_SET_FERF/.test(c))
    return OTN_LAYER.OSC;
  if (/IOP_LOW|IOP_HIGH|OOP_LOW|OOP_HIGH|ILS|OLS/.test(c))
    return OTN_LAYER.PHY;
  if (/^ODU_|^OTU_|ODU_LOF|ODU_AIS|ODU_OCI|ODU_LCK|ODU_LOM|OTU_LOF|OTU_AIS|OTU_SSF/.test(c))
    return OTN_LAYER.ODU;
  if (/^PM_|^TCM\d_|SM_TIM|SM_BDI|SM_BEI/.test(c))
    return OTN_LAYER.ODU;
  if (/ETH_|GFP_|PTP_|PACKET_SD|PCS_|FDI_/.test(c))
    return OTN_LAYER.PKT;
  if (/FAIL|CARD_ABSENT|BOARD_ERR|COMFAIL|COMMUN_FAIL|MODULE_/.test(c))
    return OTN_LAYER.DEV;
  if (/LASER_|EYESAFE|FPLL|SW_CHIP/.test(c))
    return OTN_LAYER.PHY;
  if (/SWITCH|SW_FAIL|LOOPL|LOOP|BRIDGE/.test(c))
    return OTN_LAYER.OAM;
  return OTN_LAYER.DEV;
}

// ============================
// 2. 告警关联规则
// ============================

function isRootCauseCandidate(alarm: AlarmRecord): boolean {
  const c = (alarm.alarmTitle + ' ' + alarm.alarmName).toUpperCase();
  if (/RLOS|LOS |FAIL|LASER_TF|LASER_CUT|FPLL|LINK_LOS|POWER_DOWN|POWERALM|SHUT_DOWN_48V/.test(c)) return true;
  if (/OSC_LOF|OSC_OOF|ILS|OLS/.test(c)) return true;
  if (/_AIS|_LCK|_OCI|_BDI|_BEI|_SSF|_FDI/.test(c)) return false;
  if (/SD$|_SD|_LIMIT|_EXC|_ES_|_SES_|CRC_ERR|BIP8/.test(c)) return false;
  const layer = inferAlarmLayer(alarm);
  return layer <= OTN_LAYER.OCH;
}

function isDerivedFrom(alarmA: AlarmRecord, alarmB: AlarmRecord): boolean {
  if (alarmA.id === alarmB.id) return false;
  const a = (alarmA.alarmTitle + ' ' + alarmA.alarmName).toUpperCase();
  const b = (alarmB.alarmTitle + ' ' + alarmB.alarmName).toUpperCase();
  const la = inferAlarmLayer(alarmA), lb = inferAlarmLayer(alarmB);
  if (lb >= la && alarmA.neName !== alarmB.neName) return false;

  if (/LOS|RLOS/.test(b) && /AIS|LOF|LOM|SSF/.test(a)) return true;
  if (/LASER_TF|LASER_CUT|LASER_OFF/.test(b) && (/LOS|LINK_LOS|IOP_LOW/.test(a))) return true;
  if (/FAIL|COMFAIL|CARD_ABSENT/.test(b) && !/FAIL|CARD_ABSENT|COMFAIL/.test(a)) return true;
  if (/POWER_DOWN|POWERALM/.test(b) && /FAIL|COMFAIL|COMMUN_FAIL/.test(a)) return true;
  if (/LOF|LOM/.test(b) && /AIS|LCK|OCI/.test(a)) return true;
  if (/SD$/.test(b) && /BIP8|_ES_|_SES_|_LIMIT/.test(a)) return true;
  if (/IOP_LOW|IOP_HIGH/.test(b) && /LOS|OOP_LOW|OOP_HIGH/.test(a)) return true;
  return false;
}

// ============================
// 3. 拓扑结构分析（新增）
// ============================

/** 拓扑图数据：网元名称 ↔ 相连的网元名 + 传输系统 */
interface TopoNeighbor {
  neName: string;
  system: string;
  linkLabel: string;
}

/**
 * 构建拓扑图：基于 TopologyLink + NetworkElements
 * 返回：Map<neName, TopoNeighbor[]> 
 */
function buildTopologyGraph(nesMap: Map<string, { id: string; neName: string }>): Map<string, TopoNeighbor[]> {
  const graph = new Map<string, TopoNeighbor[]>();

  for (const link of mockTopologyLinks) {
    const srcNe = nesMap.get(link.source);
    const tgtNe = nesMap.get(link.target);
    if (!srcNe || !tgtNe) continue;

    const add = (from: string, to: string, sys: string, label: string) => {
      if (!graph.has(from)) graph.set(from, []);
      graph.get(from)!.push({ neName: to, system: sys, linkLabel: label });
    };
    add(srcNe.neName, tgtNe.neName, link.system, link.label);
    add(tgtNe.neName, srcNe.neName, link.system, link.label);
  }

  return graph;
}

/**
 * 按传输系统分组网元
 * 使用知识库中网元查询报表的 "所属传输系统"（复用段）数据
 * 返回：Map<system_name, neName[]>
 */
function groupNEsBySystem(nesMap: Map<string, { id: string; neName: string }>): Map<string, string[]> {
  // 优先使用知识库静态数据
  if (Object.keys(SYSTEM_NE_MAP).length > 0) {
    const sysGroups = new Map<string, string[]>();
    for (const [sysName, neList] of Object.entries(SYSTEM_NE_MAP)) {
      sysGroups.set(sysName, [...neList]);
    }
    return sysGroups;
  }

  // 降级：从拓扑链路推导
  const sysGroups = new Map<string, string[]>();
  for (const link of mockTopologyLinks) {
    const srcNe = nesMap.get(link.source);
    const tgtNe = nesMap.get(link.target);
    if (!srcNe || !tgtNe) continue;
    if (!sysGroups.has(link.system)) sysGroups.set(link.system, []);
    const grp = sysGroups.get(link.system)!;
    if (!grp.includes(srcNe.neName)) grp.push(srcNe.neName);
    if (!grp.includes(tgtNe.neName)) grp.push(tgtNe.neName);
  }
  return sysGroups;
}

/**
 * 拓扑感知的根因打分
 *
 * 如果多个网元在同一传输系统上同时出现 LOS/RLOS 类告警，
 * 说明该传输系统的共享段（光缆）可能中断，根因是光缆而非单个网元。
 * 
 * 分数提升规则：
 *   - 同一系统上更多网元告警 → 共享段故障概率更高 → 根因分更高
 *   - 跨多个系统的告警网元 → 接近上游的网元更可能是根因
 */
function getTopologyRootCauseBoost(
  alarm: AlarmRecord,
  cluster: AlarmRecord[],
  topoGraph: Map<string, TopoNeighbor[]>,
  sysGroups: Map<string, string[]>
): number {
  const c = (alarm.alarmTitle + ' ' + alarm.alarmName).toUpperCase();
  // 仅对光层/物理层告警做拓扑提升
  if (!/LOS|RLOS|LOF|LS$/.test(c)) return 0;

  let boost = 0;

  // 检查：与该告警同网元的其他告警网元是否有跨网元影响
  const sameSystemNEs = new Set<string>();
  const neighbors = topoGraph.get(alarm.neName) || [];
  for (const nb of neighbors) {
    // 找到该邻居关联的传输系统
    const sys = nb.system;
    const sysNEs = sysGroups.get(sys) || [];
    for (const sysNe of sysNEs) {
      if (sysNe !== alarm.neName) sameSystemNEs.add(sysNe);
    }
  }

  // 统计该传输系统上有几个网元也在本集群中报告了光层告警
  let affectedCount = 0;
  for (const other of cluster) {
    if (other.neName === alarm.neName) continue;
    const oc = (other.alarmTitle + ' ' + other.alarmName).toUpperCase();
    if (sameSystemNEs.has(other.neName) && /LOS|RLOS|LOF|LS$/.test(oc)) {
      affectedCount++;
    }
  }

  // 共享段上越多网元受影响 → 越可能是根因
  if (affectedCount >= 1) boost += 0.1;
  if (affectedCount >= 2) boost += 0.15;
  if (affectedCount >= 3) boost += 0.2;

  return boost;
}

// ============================
// 4. 聚合引擎
// ============================

const DEFAULT_WINDOW_MS = 15 * 60 * 1000;
let _topoGraph: Map<string, TopoNeighbor[]> | null = null;
let _sysGroups: Map<string, string[]> | null = null;

/** 懒加载拓扑结构 */
function ensureTopology(nesMap: Map<string, { id: string; neName: string }>) {
  if (!_topoGraph) {
    _topoGraph = buildTopologyGraph(nesMap);
    _sysGroups = groupNEsBySystem(nesMap);
  }
}

export function aggregate(alarms: AlarmRecord[], _windowMinutes?: number, _quickMode?: boolean): AlarmGroup[] {
  if (alarms.length < 2) return [];
  const windowMs = (_windowMinutes || 15) * 60 * 1000;

  // 快速模式：跳过拓扑构建和全局 store 读取
  if (!_quickMode) {
    // 从 store 获取网元数据
    // 这里通过全局 store 读取 networkElements（在 module 作用域延迟获取）
    const { useAppStore } = globalThis as any;
    let nesMap = new Map<string, { id: string; neName: string }>();
    try {
      if (useAppStore?.getState) {
        const nes = useAppStore.getState().networkElements || [];
        nesMap = new Map(nes.map((ne: any) => [ne.id, { id: ne.id, neName: ne.neName }]));
      }
    } catch { /* ignore */ }
    ensureTopology(nesMap);
  }

  // Step 1: 按时间排序
  const sorted = [...alarms].sort(
    (a, b) => new Date(a.firstOccurTime).getTime() - new Date(b.firstOccurTime).getTime()
  );

  // Step 2: 滑动窗口分群（同网元放宽时间窗口）
  const clusters: AlarmRecord[][] = [];
  let currentCluster: AlarmRecord[] = [sorted[0]];

  for (let i = 1; i < sorted.length; i++) {
    const prevTime = new Date(sorted[i - 1].firstOccurTime).getTime();
    const currTime = new Date(sorted[i].firstOccurTime).getTime();
    const sameNE = sorted[i].neName === sorted[i - 1].neName;
    const gap = currTime - prevTime;
    const effectiveWindow = sameNE ? windowMs * 3 : windowMs;

    if (gap <= effectiveWindow) {
      currentCluster.push(sorted[i]);
    } else {
      if (currentCluster.length >= 2) clusters.push(currentCluster);
      currentCluster = [sorted[i]];
    }
  }
  if (currentCluster.length >= 2) clusters.push(currentCluster);

  // Step 3: 对每个风暴群，进行 OTN 关联分析 + 拓扑分析
  const allGroups: AlarmGroup[] = [];

  for (const cluster of clusters) {
    if (cluster.length < 2) continue;
    if (cluster.length > 100) {
      const subClusters = splitByNE(cluster);
      for (const sub of subClusters) {
        if (sub.length >= 2) {
          const group = analyzeCluster(sub);
          if (group) allGroups.push(group);
        }
      }
    } else {
      const group = analyzeCluster(cluster);
      if (group) allGroups.push(group);
    }
  }

  // Step 4: 排序
  allGroups.sort((a, b) => {
    const ap = SEVERITY_PRIORITY[b.severity] - SEVERITY_PRIORITY[a.severity];
    if (ap !== 0) return ap;
    const la = inferAlarmLayer(a.rootCauseAlarm);
    const lb = inferAlarmLayer(b.rootCauseAlarm);
    if (la !== lb) return la - lb;
    return b.derivedCount - a.derivedCount;
  });

  return allGroups;
}

function splitByNE(cluster: AlarmRecord[]): AlarmRecord[][] {
  const neMap = new Map<string, AlarmRecord[]>();
  for (const alarm of cluster) {
    const list = neMap.get(alarm.neName) || [];
    list.push(alarm);
    neMap.set(alarm.neName, list);
  }
  return Array.from(neMap.values());
}

/**
 * 对单个告警风暴簇进行 OTN 关联 + 拓扑分析
 */
function analyzeCluster(cluster: AlarmRecord[]): AlarmGroup | null {
  if (cluster.length < 2) return null;

  // 拓扑图的引用
  const graph = _topoGraph || new Map();
  const systems = _sysGroups || new Map();

  // 找根因候选
  const candidates = cluster.filter((a) => {
    const hasDep = cluster.some((b) => b !== a && isDerivedFrom(a, b));
    if (hasDep) return false;
    return isRootCauseCandidate(a);
  });

  // 如果有拓扑数据，增加拓扑感知的根因打分
  const rootCandidates = candidates.length > 0 ? candidates : cluster;
  const rootCause = rootCandidates.reduce<AlarmRecord>((best, current) => {
    const bestTime = new Date(best.firstOccurTime).getTime();
    const currTime = new Date(current.firstOccurTime).getTime();
    const bestLevel = ALARM_LEVEL_ORDER[best.alarmLevel];
    const currLevel = ALARM_LEVEL_ORDER[current.alarmLevel];
    const bestLayer = inferAlarmLayer(best);
    const currLayer = inferAlarmLayer(current);

    // 基础分：层级(0.4) + 时间(0.3) + 级别(0.2) + 拓扑(0.1)
    let bestScore = (7 - bestLayer) / 7 * 0.4 + (1 - bestTime / (Date.now() || 1)) * 0.3 + bestLevel / 4 * 0.2;
    let currScore = (7 - currLayer) / 7 * 0.4 + (1 - currTime / (Date.now() || 1)) * 0.3 + currLevel / 4 * 0.2;

    // 叠加拓扑提升
    if (graph.size > 0) {
      bestScore += getTopologyRootCauseBoost(best, cluster, graph, systems) * 0.1;
      currScore += getTopologyRootCauseBoost(current, cluster, graph, systems) * 0.1;
    }

    return currScore > bestScore ? current : best;
  }, rootCandidates[0]);

  // 构建传播链
  const derivedAlarms = cluster.filter((a) => a !== rootCause).sort((a, b) => {
    const la = inferAlarmLayer(a);
    const lb = inferAlarmLayer(b);
    if (la !== lb) return la - lb;
    return new Date(a.firstOccurTime).getTime() - new Date(b.firstOccurTime).getTime();
  });

  // 传播链：考虑拓扑路径
  const propagationParts: string[] = [];
  propagationParts.push(`${rootCause.alarmTitle}(${rootCause.alarmLevel})`);

  // 按拓扑相邻+层级排列
  const added = new Set<string>([rootCause.neName]);
  const chainMap = new Map<number, { alarm: AlarmRecord; neName: string }[]>();
  for (const a of derivedAlarms) {
    const layer = inferAlarmLayer(a);
    if (!chainMap.has(layer)) chainMap.set(layer, []);
    chainMap.get(layer)!.push({ alarm: a, neName: a.neName });
  }
  const sortedLayers = [...chainMap.keys()].sort((a, b) => a - b);
  for (const layer of sortedLayers) {
    const items = chainMap.get(layer)!;
    for (const { alarm, neName } of items.sort((a, b) =>
      new Date(a.alarm.firstOccurTime).getTime() - new Date(b.alarm.firstOccurTime).getTime()
    )) {
      if (!added.has(neName)) {
        propagationParts.push(`${alarm.alarmTitle}(${alarm.alarmLevel}@${neName.split('-').slice(2).join('-')})`);
        added.add(neName);
      } else {
        propagationParts.push(`${alarm.alarmTitle}(${alarm.alarmLevel})`);
      }
    }
  }

  // 拓扑摘要：如果同一传输系统多个网元受影响，生成系统级描述
  let topologySummary = '';
  if (graph.size > 0) {
    const affectedSystems = new Map<string, Set<string>>();
    for (const a of cluster) {
      const nbs = graph.get(a.neName) || [];
      for (const nb of nbs) {
        const isAffected = cluster.some((x) => x.neName === nb.neName);
        if (isAffected) {
          if (!affectedSystems.has(nb.system)) affectedSystems.set(nb.system, new Set());
          affectedSystems.get(nb.system)!.add(a.neName);
          affectedSystems.get(nb.system)!.add(nb.neName);
        }
      }
    }
    const multiAffected = [...affectedSystems.entries()].filter(([_, nes]) => nes.size >= 2);
    if (multiAffected.length > 0) {
      const top = multiAffected.sort((a, b) => b[1].size - a[1].size)[0];
      topologySummary = `【传输系统影响】${top[0]} 共 ${top[1].size} 个站点受影响`;
    }
  }

  const windowStart = cluster.reduce((m, a) => a.firstOccurTime < m ? a.firstOccurTime : m, cluster[0].firstOccurTime);
  const windowEnd = cluster.reduce((m, a) => a.firstOccurTime > m ? a.firstOccurTime : m, cluster[0].firstOccurTime);
  const severity = inferSeverity(cluster.length);
  const rootLayer = inferAlarmLayer(rootCause);
  const rootLevel = ALARM_LEVEL_ORDER[rootCause.alarmLevel];
  const rootCauseScore = Math.round(((7 - rootLayer) / 7 * 0.5 + rootLevel / 4 * 0.3 + 0.2) * 10000) / 10000;
  const uniqueDerivedTypes = new Set(derivedAlarms.map((a) => a.alarmTitle)).size;

  return {
    id: crypto.randomUUID(),
    neName: rootCause.neName,
    boardName: rootCause.boardName,
    slotNo: rootCause.slotNo,
    windowStart,
    windowEnd,
    alarms: [rootCause, ...derivedAlarms],
    rootCauseAlarm: rootCause,
    rootCauseScore,
    severity,
    derivedCount: derivedAlarms.length,
    propagationChain: propagationParts.join(' → '),
    uniqueDerivedTypes,
    topologySummary,
  };
}

function inferSeverity(count: number): AlarmStormSeverity {
  if (count >= 10) return 'storm';
  if (count >= 5) return 'cluster';
  return 'scattered';
}

const SEVERITY_PRIORITY: Record<AlarmStormSeverity, number> = {
  storm: 3,
  cluster: 2,
  scattered: 1,
};
