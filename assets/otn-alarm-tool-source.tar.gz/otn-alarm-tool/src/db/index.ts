import { openDB, type IDBPDatabase } from 'idb';
import type { ProjectMeta, AlarmRecord, NetworkElement, AlarmTypeDefinition } from '../types';

/** 数据库名称 */
const DB_NAME = 'otn-alarm-tool';
/** 数据库版本 */
const DB_VERSION = 1;
/** 批量写入每批条数 */
const BATCH_SIZE = 1000;

/**
 * 数据库连接单例
 * 每次调用返回同一个 Promise，避免重复初始化
 */
let dbPromise: Promise<IDBPDatabase> | null = null;

/** 获取/初始化数据库连接 */
export function getDB(): Promise<IDBPDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = openDB(DB_NAME, DB_VERSION, {
    upgrade(db) {
      // 项目元数据存储
      if (!db.objectStoreNames.contains('projects')) {
        db.createObjectStore('projects', { keyPath: 'id' });
      }
      // 告警数据存储，按 projectId 索引
      if (!db.objectStoreNames.contains('alarms')) {
        const alarmStore = db.createObjectStore('alarms', { keyPath: 'id' });
        alarmStore.createIndex('by-project', 'projectId');
      }
      // 网元数据存储，按 projectId 索引
      if (!db.objectStoreNames.contains('networkElements')) {
        const neStore = db.createObjectStore('networkElements', { keyPath: 'id' });
        neStore.createIndex('by-project', 'projectId');
      }
      // 告警类型定义存储，按 projectId 索引
      if (!db.objectStoreNames.contains('alarmTypeDefinitions')) {
        const defStore = db.createObjectStore('alarmTypeDefinitions', { keyPath: 'id' });
        defStore.createIndex('by-project', 'projectId');
      }
    },
  });

  return dbPromise;
}

// ==============================
// 项目 CRUD
// ==============================

/** 生成 UUID v4 */
function generateId(): string {
  return crypto.randomUUID();
}

/** 获取所有项目列表 */
export async function getAllProjects(): Promise<ProjectMeta[]> {
  try {
    const db = await getDB();
    const projects = await db.getAll('projects');
    return projects.sort(
      (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
  } catch (err) {
    console.error('[DB] getAllProjects failed:', err);
    return [];
  }
}

/** 创建新项目 */
export async function createProject(name: string): Promise<ProjectMeta> {
  const db = await getDB();
  const now = new Date().toISOString();
  const project: ProjectMeta = {
    id: generateId(),
    name,
    createdAt: now,
    updatedAt: now,
    alarmCount: 0,
    neCount: 0,
    dataSizeBytes: 0,
  };
  await db.add('projects', project);
  return project;
}

/** 更新项目元数据 */
export async function updateProject(
  id: string,
  updates: Partial<ProjectMeta>
): Promise<void> {
  try {
    const db = await getDB();
    const existing = await db.get('projects', id);
    if (!existing) {
      console.warn(`[DB] updateProject: project ${id} not found`);
      return;
    }
    const updated: ProjectMeta = {
      ...existing,
      ...updates,
      id, // 不可变
      updatedAt: new Date().toISOString(),
    };
    await db.put('projects', updated);
  } catch (err) {
    console.error('[DB] updateProject failed:', err);
  }
}

/** 删除项目及其关联数据 */
export async function deleteProject(id: string): Promise<void> {
  try {
    const db = await getDB();
    // 删除项目下所有关联数据
    await clearByProject(db, 'alarms', id);
    await clearByProject(db, 'networkElements', id);
    await clearByProject(db, 'alarmTypeDefinitions', id);
    await db.delete('projects', id);
  } catch (err) {
    console.error('[DB] deleteProject failed:', err);
  }
}

/** 清空某个 store 中指定 projectId 的所有记录 */
async function clearByProject(
  db: IDBPDatabase,
  storeName: 'alarms' | 'networkElements' | 'alarmTypeDefinitions',
  projectId: string
): Promise<void> {
  const tx = db.transaction(storeName, 'readwrite');
  const store = tx.objectStore(storeName);
  const index = store.index('by-project');
  let cursor = await index.openCursor(IDBKeyRange.only(projectId));
  while (cursor) {
    store.delete(cursor.primaryKey);
    cursor = await cursor.continue();
  }
  await tx.done;
}

// ==============================
// 告警数据存取
// ==============================

/** 保存告警数据（先删旧数据，再批量写入） */
export async function saveAlarms(projectId: string, alarms: AlarmRecord[]): Promise<void> {
  try {
    const db = await getDB();
    // 先删除该项目的旧告警数据
    await clearByProject(db, 'alarms', projectId);

    // 批量写入，每批 BATCH_SIZE 条
    const records = alarms.map((a) => ({ ...a, projectId } as AlarmRecord & { projectId: string }));
    for (let i = 0; i < records.length; i += BATCH_SIZE) {
      const batch = records.slice(i, i + BATCH_SIZE);
      const tx = db.transaction('alarms', 'readwrite');
      for (const record of batch) {
        tx.store.put(record);
      }
      await tx.done;
    }
  } catch (err) {
    console.error('[DB] saveAlarms failed:', err);
    throw err;
  }
}

/** 加载告警数据 */
export async function loadAlarms(projectId: string): Promise<AlarmRecord[]> {
  try {
    const db = await getDB();
    const all = await db.getAllFromIndex('alarms', 'by-project', projectId);
    // 移除内部 projectId 字段，返回纯净的 AlarmRecord
    return all.map(({ projectId: _, ...rest }: Record<string, unknown>) => rest as unknown as AlarmRecord);
  } catch (err) {
    console.error('[DB] loadAlarms failed:', err);
    return [];
  }
}

// ==============================
// 网元数据存取
// ==============================

/** 保存网元数据 */
export async function saveNetworkElements(
  projectId: string,
  elements: NetworkElement[]
): Promise<void> {
  try {
    const db = await getDB();
    await clearByProject(db, 'networkElements', projectId);

    const records = elements.map((e) => ({ ...e, projectId }));
    for (let i = 0; i < records.length; i += BATCH_SIZE) {
      const batch = records.slice(i, i + BATCH_SIZE);
      const tx = db.transaction('networkElements', 'readwrite');
      for (const record of batch) {
        tx.store.put(record);
      }
      await tx.done;
    }
  } catch (err) {
    console.error('[DB] saveNetworkElements failed:', err);
    throw err;
  }
}

/** 加载网元数据 */
export async function loadNetworkElements(projectId: string): Promise<NetworkElement[]> {
  try {
    const db = await getDB();
    const all = await db.getAllFromIndex('networkElements', 'by-project', projectId);
    return all.map(({ projectId: _, ...rest }: Record<string, unknown>) => rest as unknown as NetworkElement);
  } catch (err) {
    console.error('[DB] loadNetworkElements failed:', err);
    return [];
  }
}

// ==============================
// 告警类型定义存取
// ==============================

/** 保存告警类型定义 */
export async function saveAlarmTypeDefinitions(
  projectId: string,
  defs: AlarmTypeDefinition[]
): Promise<void> {
  try {
    const db = await getDB();
    await clearByProject(db, 'alarmTypeDefinitions', projectId);

    const records = defs.map((d) => ({ ...d, projectId }));
    for (let i = 0; i < records.length; i += BATCH_SIZE) {
      const batch = records.slice(i, i + BATCH_SIZE);
      const tx = db.transaction('alarmTypeDefinitions', 'readwrite');
      for (const record of batch) {
        tx.store.put(record);
      }
      await tx.done;
    }
  } catch (err) {
    console.error('[DB] saveAlarmTypeDefinitions failed:', err);
    throw err;
  }
}

/** 加载告警类型定义 */
export async function loadAlarmTypeDefinitions(
  projectId: string
): Promise<AlarmTypeDefinition[]> {
  try {
    const db = await getDB();
    const all = await db.getAllFromIndex('alarmTypeDefinitions', 'by-project', projectId);
    return all.map(({ projectId: _, ...rest }: Record<string, unknown>) => rest as unknown as AlarmTypeDefinition);
  } catch (err) {
    console.error('[DB] loadAlarmTypeDefinitions failed:', err);
    return [];
  }
}

// ==============================
// 工具函数
// ==============================

/** 获取项目数据近似大小（字节） */
export async function getProjectDataSize(projectId: string): Promise<number> {
  try {
    const [alarms, nes, defs] = await Promise.all([
      loadAlarms(projectId),
      loadNetworkElements(projectId),
      loadAlarmTypeDefinitions(projectId),
    ]);
    const total = JSON.stringify({ alarms, nes, defs }).length;
    return total;
  } catch {
    return 0;
  }
}

/** 导出项目为 JSON 字符串 */
export async function exportProjectJSON(projectId: string): Promise<string> {
  const db = await getDB();
  const project = await db.get('projects', projectId);
  if (!project) throw new Error(`Project ${projectId} not found`);

  const [alarms, networkElements, alarmTypeDefinitions] = await Promise.all([
    loadAlarms(projectId),
    loadNetworkElements(projectId),
    loadAlarmTypeDefinitions(projectId),
  ]);

  return JSON.stringify(
    {
      version: 1,
      exportedAt: new Date().toISOString(),
      project,
      alarms,
      networkElements,
      alarmTypeDefinitions,
    },
    null,
    2
  );
}

/** 从 JSON 字符串导入项目 */
export async function importProjectJSON(json: string): Promise<ProjectMeta> {
  let data: {
    version: number;
    exportedAt: string;
    project: ProjectMeta;
    alarms: AlarmRecord[];
    networkElements: NetworkElement[];
    alarmTypeDefinitions: AlarmTypeDefinition[];
  };

  try {
    data = JSON.parse(json);
  } catch {
    throw new Error('Invalid JSON format');
  }

  if (!data.project || !data.project.id) {
    throw new Error('Invalid project data: missing project.id');
  }

  const db = await getDB();

  // 检查是否已存在同名项目，存在则更新
  const existing = await db.get('projects', data.project.id);
  const now = new Date().toISOString();
  const project: ProjectMeta = {
    ...data.project,
    updatedAt: now,
  };

  if (existing) {
    await db.put('projects', project);
  } else {
    // 新导入：更新 createdAt
    project.createdAt = now;
    await db.add('projects', project);
  }

  // 写入关联数据
  if (data.alarms?.length) {
    await saveAlarms(project.id, data.alarms);
  }
  if (data.networkElements?.length) {
    await saveNetworkElements(project.id, data.networkElements);
  }
  if (data.alarmTypeDefinitions?.length) {
    await saveAlarmTypeDefinitions(project.id, data.alarmTypeDefinitions);
  }

  // 更新统计
  const dataSize = await getProjectDataSize(project.id);
  await updateProject(project.id, {
    alarmCount: data.alarms?.length ?? 0,
    neCount: data.networkElements?.length ?? 0,
    dataSizeBytes: dataSize,
  });

  return project;
}
