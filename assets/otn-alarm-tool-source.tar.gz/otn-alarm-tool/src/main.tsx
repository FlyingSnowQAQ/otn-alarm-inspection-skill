import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import useAppStore from './store/useAppStore';
import { DataSourceRegistry } from './core/registry';
import { fibrehomeAdapter } from './adapters';
import './index.css';

// 注册内置烽火适配器
DataSourceRegistry.getInstance().register(fibrehomeAdapter);

// 应用启动前初始化：加载项目数据
useAppStore.getState().loadProjects().then(() => {
  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>,
  );
});
