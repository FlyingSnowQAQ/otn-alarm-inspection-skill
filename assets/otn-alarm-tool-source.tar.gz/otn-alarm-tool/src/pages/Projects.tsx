import React, { useState, useRef } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  TextField,
  Grid,
  Chip,
  Tooltip,
  Snackbar,
  Alert,
  CircularProgress,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import FileUploadIcon from '@mui/icons-material/FileUpload';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';
import FolderIcon from '@mui/icons-material/Folder';
import useAppStore from '../store/useAppStore';
import type { ProjectMeta } from '../types';

/** Electron环境检测 */
const electronAPI = (globalThis as any).electronAPI as any;
const isElectron = !!electronAPI;

/** 将字节数格式化为可读字符串 */
const formatSize = (bytes: number): string => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

/** 将 ISO 日期格式化为中文可读字符串 */
const formatDate = (iso: string): string => {
  try {
    return new Date(iso).toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
};

/** 项目管理页面 */
const Projects: React.FC = () => {
  const {
    projects,
    activeProjectId,
    createProject,
    switchProject,
    deleteProject,
    renameProject,
    exportBackup,
    importBackup,
    setCurrentPage,
  } = useAppStore();

  const fileInputRef = useRef<HTMLInputElement>(null);

  // ========== 新建项目对话框状态 ==========
  const [createOpen, setCreateOpen] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [createLoading, setCreateLoading] = useState(false);

  // ========== 删除确认对话框状态 ==========
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<ProjectMeta | null>(null);

  // ========== 重命名内联编辑状态 ==========
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');

  // ========== 提示状态 ==========
  const [snackOpen, setSnackOpen] = useState(false);
  const [snackMsg, setSnackMsg] = useState('');
  const [snackSeverity, setSnackSeverity] = useState<'success' | 'error'>('success');

  /** 显示提示消息 */
  const showSnack = (msg: string, severity: 'success' | 'error' = 'success'): void => {
    setSnackMsg(msg);
    setSnackSeverity(severity);
    setSnackOpen(true);
  };

  // ========== 新建项目处理 ==========
  const handleCreate = async (): Promise<void> => {
    const name = newProjectName.trim();
    if (!name) return;
    setCreateLoading(true);
    try {
      await createProject(name);
      setCreateOpen(false);
      setNewProjectName('');
      showSnack(`项目「${name}」创建成功`);
    } catch (err) {
      showSnack('创建项目失败', 'error');
    } finally {
      setCreateLoading(false);
    }
  };

  // ========== 切换项目处理 ==========
  const handleSwitch = async (id: string): Promise<void> => {
    try {
      await switchProject(id);
      setCurrentPage('dashboard');
    } catch (err) {
      showSnack('切换项目失败', 'error');
    }
  };

  // ========== 删除项目处理 ==========
  const handleDeleteConfirm = async (): Promise<void> => {
    if (!deleteTarget) return;
    try {
      await deleteProject(deleteTarget.id);
      showSnack(`项目「${deleteTarget.name}」已删除`);
    } catch (err) {
      showSnack('删除项目失败', 'error');
    } finally {
      setDeleteOpen(false);
      setDeleteTarget(null);
    }
  };

  // ========== 重命名处理 ==========
  const handleRenameStart = (project: ProjectMeta): void => {
    setEditingId(project.id);
    setEditingName(project.name);
  };

  const handleRenameConfirm = async (): Promise<void> => {
    if (!editingId || !editingName.trim()) {
      setEditingId(null);
      return;
    }
    try {
      await renameProject(editingId, editingName.trim());
      showSnack('项目重命名成功');
    } catch (err) {
      showSnack('重命名失败', 'error');
    } finally {
      setEditingId(null);
    }
  };

  const handleRenameCancel = (): void => {
    setEditingId(null);
  };

  // ========== JSON 导出处理 ==========
  const handleExport = async (): Promise<void> => {
    try {
      const result = await exportBackup();
      // Electron路径：exportBackup返回文件保存路径
      if (isElectron) {
        showSnack(`项目已导出到: ${result}`);
        return;
      }
      // 浏览器路径：Blob + 下载
      const blob = new Blob([result as string], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      const project = projects.find((p) => p.id === activeProjectId);
      link.download = `${project?.name || 'project'}_backup_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      showSnack('项目导出成功');
    } catch (err) {
      showSnack(
        '导出失败：' + (err instanceof Error ? err.message : '未知错误'),
        'error'
      );
    }
  };

  // ========== JSON 导入处理（Electron路径） ==========
  const handleElectronImport = async (): Promise<void> => {
    try {
      const result = await electronAPI.importProject();
      if (result.canceled) return;
      if (!result.success) {
        showSnack('导入失败：无效的备份文件', 'error');
        return;
      }
      // 手动刷新store数据（importBackup会再调IPC，但这次直接传入已读取的数据）
      useAppStore.setState({
        projects: await electronAPI.getProjects(),
        activeProjectId: result.project.id,
        alarms: result.alarms || [],
        networkElements: result.networkElements || [],
        alarmTypeDefinitions: result.alarmTypeDefinitions || [],
      });
      showSnack('项目导入成功');
    } catch (err) {
      showSnack(
        '导入失败：' + (err instanceof Error ? err.message : '未知错误'),
        'error'
      );
    }
  };

  // ========== JSON 导入处理（浏览器路径） ==========
  const handleImportClick = (): void => {
    // Electron路径：主进程打开文件对话框并导入
    if (isElectron) {
      handleElectronImport();
      return;
    }
    // 浏览器路径：触发隐藏file input
    fileInputRef.current?.click();
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>): Promise<void> => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      await importBackup(text);
      showSnack('项目导入成功');
    } catch (err) {
      showSnack(
        '导入失败：' + (err instanceof Error ? err.message : '无效的备份文件'),
        'error'
      );
    } finally {
      // 重置文件选择器，允许重复导入同一文件
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <Box>
      {/* 页面标题和操作按钮 */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          mb: 3,
          flexWrap: 'wrap',
          gap: 1,
        }}
      >
        <Typography variant="h5" sx={{ fontWeight: 600, color: '#e0e0e0' }}>
          项目管理
        </Typography>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Button
            variant="outlined"
            startIcon={<FileUploadIcon />}
            onClick={handleImportClick}
            sx={{ color: '#9e9e9e', borderColor: '#2d3d50' }}
          >
            导入JSON
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            style={{ display: 'none' }}
            onChange={handleImportFile}
          />
          {activeProjectId && (
            <Button
              variant="outlined"
              startIcon={<FileDownloadIcon />}
              onClick={handleExport}
              sx={{ color: '#2196f3', borderColor: '#2d3d50' }}
            >
              导出JSON
            </Button>
          )}
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => setCreateOpen(true)}
            sx={{ backgroundColor: '#2196f3' }}
          >
            新建项目
          </Button>
        </Box>
      </Box>

      {/* 空状态 */}
      {projects.length === 0 && (
        <Card
          sx={{
            backgroundColor: '#1a2332',
            p: 6,
            textAlign: 'center',
            borderRadius: 2,
          }}
        >
          <FolderIcon sx={{ fontSize: 64, color: '#2d3d50', mb: 2 }} />
          <Typography variant="h6" sx={{ color: '#9e9e9e', mb: 1 }}>
            暂无项目
          </Typography>
          <Typography variant="body2" sx={{ color: '#666' }}>
            请创建新项目或导入JSON备份
          </Typography>
        </Card>
      )}

      {/* 项目卡片网格 */}
      {projects.length > 0 && (
        <Grid container spacing={2}>
          {projects.map((project) => {
            const isActive = project.id === activeProjectId;
            const isEditing = editingId === project.id;

            return (
              <Grid item xs={12} sm={6} md={4} key={project.id}>
                <Card
                  sx={{
                    backgroundColor: '#1a2332',
                    cursor: isEditing ? 'default' : 'pointer',
                    border: isActive ? '2px solid #2196f3' : '2px solid transparent',
                    borderRadius: 2,
                    transition: 'border-color 0.2s, box-shadow 0.2s',
                    '&:hover': {
                      boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
                      borderColor: isActive ? '#2196f3' : '#2d3d50',
                    },
                  }}
                  onClick={() => {
                    if (!isEditing && !isActive) {
                      handleSwitch(project.id);
                    }
                  }}
                >
                  <CardContent>
                    {/* 项目名称行 */}
                    <Box
                      sx={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        mb: 2,
                      }}
                    >
                      {isEditing ? (
                        /* 内联编辑模式 */
                        <Box
                          sx={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 0.5,
                            flex: 1,
                          }}
                        >
                          <TextField
                            size="small"
                            value={editingName}
                            onChange={(e) => setEditingName(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleRenameConfirm();
                              if (e.key === 'Escape') handleRenameCancel();
                            }}
                            autoFocus
                            fullWidth
                            sx={{
                              '& .MuiInputBase-input': {
                                color: '#e0e0e0',
                                fontSize: 14,
                              },
                              '& .MuiOutlinedInput-notchedOutline': {
                                borderColor: '#2196f3',
                              },
                            }}
                          />
                          <IconButton
                            size="small"
                            onClick={handleRenameConfirm}
                            sx={{ color: '#4caf50' }}
                          >
                            <CheckIcon fontSize="small" />
                          </IconButton>
                          <IconButton
                            size="small"
                            onClick={handleRenameCancel}
                            sx={{ color: '#f44336' }}
                          >
                            <CloseIcon fontSize="small" />
                          </IconButton>
                        </Box>
                      ) : (
                        /* 正常显示模式 */
                        <>
                          <Box
                            sx={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: 1,
                              minWidth: 0,
                              flex: 1,
                            }}
                          >
                            <Typography
                              variant="subtitle1"
                              noWrap
                              sx={{ fontWeight: 600, color: '#e0e0e0' }}
                            >
                              {project.name}
                            </Typography>
                            {isActive && (
                              <Chip
                                label="当前"
                                size="small"
                                color="primary"
                                sx={{ height: 20, fontSize: 11, flexShrink: 0 }}
                              />
                            )}
                          </Box>
                          <Box sx={{ display: 'flex', flexShrink: 0 }}>
                            <Tooltip title="重命名">
                              <IconButton
                                size="small"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleRenameStart(project);
                                }}
                                sx={{ color: '#9e9e9e' }}
                              >
                                <EditIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="删除">
                              <IconButton
                                size="small"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setDeleteTarget(project);
                                  setDeleteOpen(true);
                                }}
                                sx={{ color: '#f44336' }}
                              >
                                <DeleteIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                          </Box>
                        </>
                      )}
                    </Box>

                    {/* 项目统计信息 */}
                    <Grid container spacing={1}>
                      <Grid item xs={6}>
                        <Typography variant="caption" sx={{ color: '#666' }}>
                          告警数
                        </Typography>
                        <Typography
                          variant="body2"
                          sx={{ color: '#e0e0e0', fontWeight: 500 }}
                        >
                          {project.alarmCount}
                        </Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="caption" sx={{ color: '#666' }}>
                          网元数
                        </Typography>
                        <Typography
                          variant="body2"
                          sx={{ color: '#e0e0e0', fontWeight: 500 }}
                        >
                          {project.neCount}
                        </Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="caption" sx={{ color: '#666' }}>
                          数据大小
                        </Typography>
                        <Typography
                          variant="body2"
                          sx={{ color: '#e0e0e0', fontWeight: 500 }}
                        >
                          {formatSize(project.dataSizeBytes)}
                        </Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="caption" sx={{ color: '#666' }}>
                          更新时间
                        </Typography>
                        <Typography
                          variant="body2"
                          noWrap
                          sx={{ color: '#e0e0e0', fontSize: 12 }}
                        >
                          {formatDate(project.updatedAt)}
                        </Typography>
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>
              </Grid>
            );
          })}
        </Grid>
      )}

      {/* 新建项目 Dialog */}
      <Dialog
        open={createOpen}
        onClose={() => !createLoading && setCreateOpen(false)}
        PaperProps={{
          sx: { backgroundColor: '#1a2332', borderRadius: 2, minWidth: 400 },
        }}
      >
        <DialogTitle sx={{ color: '#e0e0e0' }}>新建项目</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ color: '#9e9e9e', mb: 2 }}>
            请输入新项目的名称
          </DialogContentText>
          <TextField
            autoFocus
            fullWidth
            label="项目名称"
            placeholder="例如：Q1季度告警分析"
            value={newProjectName}
            onChange={(e) => setNewProjectName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleCreate();
            }}
            disabled={createLoading}
            sx={{
              '& .MuiInputLabel-root': { color: '#9e9e9e' },
              '& .MuiInputBase-input': { color: '#e0e0e0' },
              '& .MuiOutlinedInput-notchedOutline': { borderColor: '#2d3d50' },
            }}
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button
            onClick={() => setCreateOpen(false)}
            disabled={createLoading}
            sx={{ color: '#9e9e9e' }}
          >
            取消
          </Button>
          <Button
            onClick={handleCreate}
            variant="contained"
            disabled={!newProjectName.trim() || createLoading}
            sx={{ backgroundColor: '#2196f3' }}
          >
            {createLoading ? <CircularProgress size={20} /> : '创建'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* 删除确认 Dialog */}
      <Dialog
        open={deleteOpen}
        onClose={() => setDeleteOpen(false)}
        PaperProps={{
          sx: { backgroundColor: '#1a2332', borderRadius: 2 },
        }}
      >
        <DialogTitle sx={{ color: '#f44336' }}>确认删除</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ color: '#e0e0e0' }}>
            确定删除项目「{deleteTarget?.name}」及其所有数据？此操作不可撤销。
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setDeleteOpen(false)} sx={{ color: '#9e9e9e' }}>
            取消
          </Button>
          <Button
            onClick={handleDeleteConfirm}
            variant="contained"
            color="error"
          >
            确认删除
          </Button>
        </DialogActions>
      </Dialog>

      {/* 全局提示 Snackbar */}
      <Snackbar
        open={snackOpen}
        autoHideDuration={3000}
        onClose={() => setSnackOpen(false)}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert
          severity={snackSeverity}
          onClose={() => setSnackOpen(false)}
          sx={{ width: '100%' }}
        >
          {snackMsg}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default Projects;
