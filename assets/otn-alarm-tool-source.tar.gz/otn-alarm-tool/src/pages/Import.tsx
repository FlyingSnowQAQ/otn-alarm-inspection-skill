import React, { useState, useCallback, useRef } from 'react';
import {
  Box,
  Card,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  LinearProgress,
  Alert,
  Chip,
  Grid,
  Snackbar,
} from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import DeleteIcon from '@mui/icons-material/Delete';
import * as XLSX from 'xlsx';
import useAppStore from '../store/useAppStore';
import type {
  AlarmRecord,
  AlarmLevel,
  AlarmType,
  AlarmStatus,
  NetworkElement,
  ColumnMapping,
} from '../types';
import { NE_PROVINCE_MAP } from '../data/neProvinceMap';

/** Electron环境检测 */
const electronAPI = (globalThis as any).electronAPI as any;
const isElectron = !!electronAPI;

/** 告警字段与XLS列名的自动映射（支持两种报表格式） */
const FIELD_AUTO_MAP: Record<string, string[]> = {
  alarmNo: ['告警序号', '序号', 'No'],
  alarmTitle: ['告警标题', '标题'],
  alarmName: ['告警名称', '名称'],
  alarmLevel: ['告警级别', '级别'],
  neName: ['网元名称', '网元'],
  neIp: ['网元IP', 'IP地址', 'IP'],
  slotNo: ['槽位号', '槽位'],
  boardName: ['盘名称', '单板', '板名'],
  portNo: ['端口号', '端口'],
  alarmType: ['告警类型', '类型'],
  alarmStatus: ['告警状态', '告警确认状态', '确认状态'],
  firstOccurTime: ['首次发生时间', '首次发生', '告警发生时间', '发生时间'],
  lastOccurTime: ['最近发生时间', '最近发生'],
  clearTime: ['告警清除时间', '清除时间', '告警消失时间', '消失时间'],
  duration: ['告警持续时长', '持续时长'],
  confirmOperator: ['确认操作者', '确认人'],
  ruisikangConfirmTime: ['瑞斯康确认时间'],
  confirmTime: ['确认时间', '告警确认时间'],
  clearOperator: ['清除操作者', '清除人'],
  ruisikangClearTime: ['瑞斯康清除时间'],
  additionalInfo: ['附加信息', '备注', '告警原因', '原因'],
  alarmSource: ['告警源', '来源'],
};

/** 告警字段中文名映射 */
const FIELD_LABELS: Record<string, string> = {
  alarmNo: '告警序号',
  alarmTitle: '告警标题',
  alarmName: '告警名称',
  alarmLevel: '告警级别',
  neName: '网元名称',
  neIp: '网元IP',
  slotNo: '槽位号',
  boardName: '盘名称',
  portNo: '端口号',
  alarmType: '告警类型',
  alarmStatus: '告警状态',
  firstOccurTime: '首次发生时间',
  lastOccurTime: '最近发生时间',
  clearTime: '告警清除时间',
  duration: '告警持续时长',
  confirmOperator: '确认操作者',
  ruisikangConfirmTime: '瑞斯康确认时间',
  confirmTime: '确认时间',
  clearOperator: '清除操作者',
  ruisikangClearTime: '瑞斯康清除时间',
  additionalInfo: '附加信息',
  alarmSource: '告警源',
};

/** 网元字段与XLS列名的自动映射 */
const NE_FIELD_AUTO_MAP: Record<string, string[]> = {
  neName: ['网元名称', '网络设备名称', 'NE名称', '网元名'],
  neId: ['网元ID', 'NE ID', 'NE编号', '设备编号'],
  neType: ['网元类型', '设备型号', '类型', '设备类型', '产品型号'],
  region: ['所属区域', '区域', '片区', '大区'],
  province: ['所属省份', '省份', '省', '所属省'],
  city: ['所属城市', '城市', '地市', '所在地市'],
  logicalDomain: ['逻辑域', '域', '所属域'],
  emuType: ['EMU类型', 'EMU盘类型', '机框类型'],
  ipAddress: ['网元IP', 'IP地址', 'IP', '管理IP'],
  onlineDate: ['入网日期', '入网时间', '投产日期', '上线日期'],
  userLabel: ['用户标签', '用户标注', '别名'],
  sn: ['序列号', 'SN', '网元SN号', '设备序列号'],
  maintenanceStatus: ['维护状态', '维保状态'],
  onlineStatus: ['在线状态', '网元在线状态', '状态', '运行状态'],
  softwareVersion: ['软件版本', '版本', '版本号'],
  physicalLocation: ['物理位置', '安装位置', '位置', '机房位置'],
  remark: ['备注', '说明'],
  transportSystem: ['所属传输系统', '传输系统', '系统'],
};

/** NE 字段中文名映射 */
const NE_FIELD_LABELS: Record<string, string> = {
  neName: '网元名称',
  neId: '网元ID',
  neType: '网元类型',
  region: '所属区域',
  province: '所属省份',
  city: '所属城市',
  logicalDomain: '逻辑域',
  emuType: 'EMU类型',
  ipAddress: '网元IP',
  onlineDate: '入网日期',
  userLabel: '用户标签',
  sn: '序列号',
  maintenanceStatus: '维护状态',
  onlineStatus: '在线状态',
  softwareVersion: '软件版本',
  physicalLocation: '物理位置',
  remark: '备注',
  transportSystem: '所属传输系统',
};

/** 级别映射 */
const LEVEL_MAP: Record<string, AlarmLevel> = {
  '紧急': '紧急',
  '紧急告警': '紧急',
  '主要': '主要',
  '主要告警': '主要',
  '次要': '次要',
  '次要告警': '次要',
  '提示': '提示',
  '提示告警': '提示',
};

/** 类型映射 */
const TYPE_MAP: Record<string, AlarmType> = {
  '通信告警': '通信告警',
  '设备告警': '设备告警',
  '处理错误告警': '处理错误告警',
  '环境告警': '环境告警',
  '服务质量告警': '服务质量告警',
};

/** 状态映射（支持两种报表格式的状态值） */
const STATUS_MAP: Record<string, AlarmStatus> = {
  '未确认未清除': '未确认未清除',
  '已确认未清除': '已确认未清除',
  '已确认已清除': '已确认已清除',
  '未确认': '未确认',
  '自动确认': '自动确认',
  '手动确认': '已确认未清除',
};

/** 从网元名称中提取省份代码映射（当精确匹配 NE_PROVINCE_MAP 失败时使用） */
const PROVINCE_CODE_MAP: Record<string, string> = {
  'YN': '云南省(YN)', 'GZ': '贵州省(GZ)', 'SC': '四川省(SC)', 'CQ': '重庆市(CQ)',
  'QH': '青海省(QH)', 'SN': '陕西省(SN)', 'XJ': '新疆维吾尔自治区(XJ)',
  'GS': '甘肃省(GS)', 'NX': '宁夏回族自治区(NX)', 'GX': '广西壮族自治区(GX)',
  'XZ': '西藏自治区(XZ)', 'HE': '河北省(HE)', 'TJ': '天津市(TJ)',
  'HL': '黑龙江省(HL)', 'BJ': '北京市(BJ)', 'LN': '辽宁省(LN)',
  'NM': '内蒙古自治区(NM)', 'JL': '吉林省(JL)', 'SX': '山西省(SX)',
  'HB': '湖北省(HB)', 'HN': '湖南省(HN)', 'HA': '河南省(HA)', 'GD': '广东省(GD)',
};

const getProvinceFromCode = (neName: string): string => {
  const match = neName.match(/^N-\d+-(YN|GZ|SC|CQ|QH|SN|XJ|GS|NX|GX|XZ|HE|TJ|HL|BJ|LN|NM|JL|SX|HB|HN|HA|GD)/);
  return match ? PROVINCE_CODE_MAP[match[1]] || '' : '';
};

/** 导入模式 */
type ImportMode = 'alarm' | 'ne';

/** 数据导入页面 */
const Import: React.FC = () => {
  const { networkElements, setNetworkElements, setAlarms, addAlarms, alarms, activeProjectId, projects } = useAppStore();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [importMode, setImportMode] = useState<ImportMode>('alarm');
  const [importState, setImportState] = useState<'idle' | 'preview' | 'mapping' | 'importing' | 'done'>('idle');
  const [headers, setHeaders] = useState<string[]>([]);
  const [previewRows, setPreviewRows] = useState<string[][]>([]);
  const [allRows, setAllRows] = useState<string[][]>([]);
  const [columnMappings, setColumnMappings] = useState<ColumnMapping[]>([]);
  const [importProgress, setImportProgress] = useState(0);
  const [importResult, setImportResult] = useState<{ success: number; failed: number; total: number } | null>(null);
  const [snackOpen, setSnackOpen] = useState(false);
  const [snackMsg, setSnackMsg] = useState('');
  const [isDragOver, setIsDragOver] = useState(false);

  /** 智能查找表头行索引：跳过报表标题、导出时间等非数据行 */
  const findHeaderRowIndex = (rows: string[][], fieldAutoMap: Record<string, string[]> = FIELD_AUTO_MAP): number => {
    // 收集所有已知的关键列名片段
    const knownKeywords = Object.values(fieldAutoMap).flat();
    for (let i = 0; i < Math.min(rows.length, 20); i++) {
      const row = rows[i];
      if (!row || row.length < 3) continue;
      // 检查该行有多少列名能匹配到已知关键字
      const matchCount = row.filter((cell) => {
        const cellStr = String(cell).trim();
        return knownKeywords.some((kw) => cellStr.includes(kw));
      }).length;
      // 超过半数列名匹配，视为表头行
      if (matchCount >= Math.ceil(row.length * 0.4)) {
        return i;
      }
    }
    return 0; // 未找到则回退到第一行
  };

  /** 解析XLS文件 */
  const parseFile = useCallback((file: File, importMode: ImportMode = 'alarm') => {
    const fieldAutoMap = importMode === 'ne' ? NE_FIELD_AUTO_MAP : FIELD_AUTO_MAP;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json<string[]>(worksheet, { header: 1 });

        if (jsonData.length < 2) {
          setSnackMsg('文件内容为空或格式不正确');
          setSnackOpen(true);
          return;
        }

        // 智能查找表头行
        const headerRowIndex = findHeaderRowIndex(jsonData as string[][], fieldAutoMap);
        const fileHeaders = ((jsonData[headerRowIndex] || []) as string[]).map((h) => String(h).trim());
        const fileRows = (jsonData.slice(headerRowIndex + 1) as string[][]).filter((row) => row.length > 0);

        if (fileHeaders.length === 0 || fileRows.length === 0) {
          setSnackMsg('未找到有效数据，请检查文件格式');
          setSnackOpen(true);
          return;
        }

        setHeaders(fileHeaders);
        setPreviewRows(fileRows.slice(0, 10));
        setAllRows(fileRows);

        // 自动匹配列名
        const mappings: ColumnMapping[] = fileHeaders.map((header) => {
          let targetField = '';
          for (const [field, keywords] of Object.entries(fieldAutoMap)) {
            if (keywords.some((kw) => header.includes(kw))) {
              targetField = field;
              break;
            }
          }
          return { sourceColumn: header, targetField };
        });

        setColumnMappings(mappings);
        setImportState('preview');
      } catch (err) {
        setSnackMsg('文件解析失败，请检查文件格式');
        setSnackOpen(true);
      }
    };
    reader.readAsArrayBuffer(file);
  }, []);

  /** 处理Electron IPC解析结果（通用逻辑） */
  const handleParseResult = useCallback((result: any, importMode: ImportMode = 'alarm') => {
    const fieldAutoMap = importMode === 'ne' ? NE_FIELD_AUTO_MAP : FIELD_AUTO_MAP;
    if (!result.success) {
      setSnackMsg('文件解析失败: ' + (result.error || '未知错误'));
      setSnackOpen(true);
      return;
    }
    const { rows, totalRows } = result;
    if (!rows || rows.length < 2) {
      setSnackMsg('文件内容为空或格式不正确');
      setSnackOpen(true);
      return;
    }
    // 智能查找表头行
    const headerRowIndex = findHeaderRowIndex(rows, fieldAutoMap);
    const fileHeaders = (rows[headerRowIndex] || []).map((h: any) => String(h).trim());
    const fileRows = (rows.slice(headerRowIndex + 1) as string[][]).filter((row: any) => row.length > 0);
    if (fileHeaders.length === 0 || fileRows.length === 0) {
      setSnackMsg('未找到有效数据，请检查文件格式');
      setSnackOpen(true);
      return;
    }
    setHeaders(fileHeaders);
    setPreviewRows(fileRows.slice(0, 10));
    setAllRows(fileRows);
    // 自动匹配列名
    const mappings = fileHeaders.map((header: string) => {
      let targetField = '';
      for (const [field, keywords] of Object.entries(fieldAutoMap)) {
        if (keywords.some((kw) => header.includes(kw))) {
          targetField = field;
          break;
        }
      }
      return { sourceColumn: header, targetField };
    });
    setColumnMappings(mappings);
    setImportState('preview');
  }, []);

  /** 文件选择处理 */
  const handleFileSelect = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // 扩展名校验
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (ext !== 'xls' && ext !== 'xlsx') {
      setSnackMsg('请选择XLS或XLSX格式的文件');
      setSnackOpen(true);
      return;
    }

    // Electron路径：使用IPC解析（不阻塞UI）
    if (isElectron && electronAPI) {
      try {
        const result = await electronAPI.parseXLS((file as any).path);
        handleParseResult(result, importMode);
      } catch (err) {
        setSnackMsg('文件解析出错: ' + (err as Error).message);
        setSnackOpen(true);
      }
      return;
    }

    // 浏览器路径：使用 FileReader
    parseFile(file, importMode);
  }, [parseFile, handleParseResult, importMode]);

  /** 拖拽上传处理 */
  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files[0];
    if (!file) return;

    // Electron路径：使用IPC解析（不阻塞UI）
    if (isElectron && electronAPI) {
      try {
        const result = await electronAPI.parseXLS((file as any).path);
        handleParseResult(result, importMode);
      } catch (err) {
        setSnackMsg('文件解析出错: ' + (err as Error).message);
        setSnackOpen(true);
      }
      return;
    }

    // 浏览器路径：使用 FileReader
    parseFile(file, importMode);
  }, [parseFile, handleParseResult, importMode]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setIsDragOver(false);
  }, []);

  /** 更新列映射 */
  const handleMappingChange = (index: number, targetField: string) => {
    const newMappings = [...columnMappings];
    newMappings[index] = { ...newMappings[index], targetField };
    setColumnMappings(newMappings);
  };

  /** NE 导入执行函数 */
  const handleNEImport = useCallback(() => {
    setImportState('importing');
    setImportProgress(0);

    const fieldToIndex: Record<string, number> = {};
    columnMappings.forEach((mapping, index) => {
      if (mapping.targetField) {
        fieldToIndex[mapping.targetField] = index;
      }
    });

    const newNEs: NetworkElement[] = [];
    let failedCount = 0;

    allRows.forEach((row, rowIndex) => {
      try {
        const getVal = (field: string): string => {
          const idx = fieldToIndex[field];
          return idx !== undefined && row[idx] !== undefined ? String(row[idx]).trim() : '';
        };

        const neNameVal = getVal('neName');
        if (!neNameVal) { failedCount++; return; }

        const neTypeVal = getVal('neType') || 'FONST 6000 N32';

        // 从所属区域解析省份和城市：格式 "云南省(YN)-昆明市(KM)"
        let provinceVal = getVal('province');
        let cityVal = getVal('city');
        const regionVal = getVal('region');
        if (!provinceVal && regionVal) {
          const parts = regionVal.split('-');
          if (parts.length >= 1) provinceVal = parts[0].trim(); // "云南省(YN)"
          if (parts.length >= 2) cityVal = parts[1].trim();    // "昆明市(KM)"
        }

        const ne: NetworkElement = {
          id: `ne-imported-${Date.now()}-${rowIndex}`,
          neName: neNameVal,
          neId: getVal('neId') || neNameVal,
          neType: neTypeVal as any,
          province: provinceVal || '',
          region: regionVal,
          city: cityVal || '',
          logicalDomain: getVal('logicalDomain'),
          emuType: getVal('emuType'),
          ipAddress: getVal('ipAddress'),
          onlineDate: getVal('onlineDate'),
          userLabel: getVal('userLabel'),
          sn: getVal('sn'),
          maintenanceStatus: (getVal('maintenanceStatus') as any) || '正常',
          onlineStatus: (getVal('onlineStatus') as any) || '在线',
          softwareVersion: getVal('softwareVersion'),
          physicalLocation: getVal('physicalLocation'),
          remark: getVal('remark'),
          transportSystem: getVal('transportSystem'),
          // 以下字段没有映射时的默认值
          switchNo1: '',
          switchNo2: '',
          friendlyName: '',
          createTime: new Date().toISOString(),
          createUser: '',
          isSuperRing: false,
          isSuperLongLink: false,
          ringType: '',
          equivalentCoefficient: 1,
          crossCapacity: 0,
          channelType: '',
        };
        newNEs.push(ne);
      } catch { failedCount++; }
    });

    // 模拟进度
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setImportProgress(Math.min(progress, 100));
      if (progress >= 100) {
        clearInterval(interval);
        setNetworkElements(newNEs);
        setImportResult({ success: newNEs.length, failed: failedCount, total: allRows.length });
        setImportState('done');
      }
    }, 50);
  }, [allRows, columnMappings, setNetworkElements]);

  /** 执行导入 */
  const handleImport = useCallback(() => {
    // NE 模式：委托给 handleNEImport
    if (importMode === 'ne') {
      handleNEImport();
      return;
    }

    // 告警模式：原有逻辑
    setImportState('importing');
    setImportProgress(0);

    const fieldToIndex: Record<string, number> = {};
    columnMappings.forEach((mapping, index) => {
      if (mapping.targetField) {
        fieldToIndex[mapping.targetField] = index;
      }
    });

    const newAlarms: AlarmRecord[] = [];
    let failedCount = 0;

    allRows.forEach((row, rowIndex) => {
      try {
        const getVal = (field: string): string => {
          const idx = fieldToIndex[field];
          return idx !== undefined && row[idx] !== undefined ? String(row[idx]).trim() : '';
        };

        const levelRaw = getVal('alarmLevel');
        const typeRaw = getVal('alarmType');
        const statusRaw = getVal('alarmStatus');

        const alarmLevel = LEVEL_MAP[levelRaw];
        const alarmType = TYPE_MAP[typeRaw];
        const alarmStatus = STATUS_MAP[statusRaw];

        if (!alarmLevel || !alarmType) {
          failedCount++;
          return;
        }

        // 如果告警状态为空，根据是否有消失时间推断
        const resolvedStatus = alarmStatus || (getVal('clearTime') ? '自动确认' : '未确认');

        // 如果没有网元名称字段，尝试从告警源提取
        const neNameVal = getVal('neName') || getVal('alarmSource');

        const alarm: AlarmRecord = {
          id: `imported-${Date.now()}-${rowIndex}`,
          alarmNo: parseInt(getVal('alarmNo')) || rowIndex + 1,
          alarmTitle: getVal('alarmTitle') || getVal('alarmName'),
          alarmName: getVal('alarmName'),
          alarmLevel,
          neName: neNameVal,
          province: NE_PROVINCE_MAP[neNameVal] || getProvinceFromCode(neNameVal),
          neIp: getVal('neIp'),
          slotNo: getVal('slotNo'),
          boardName: getVal('boardName'),
          portNo: getVal('portNo'),
          alarmType,
          alarmStatus: resolvedStatus,
          firstOccurTime: getVal('firstOccurTime'),
          lastOccurTime: getVal('lastOccurTime') || getVal('firstOccurTime'),
          clearTime: getVal('clearTime'),
          duration: getVal('duration'),
          confirmOperator: getVal('confirmOperator'),
          ruisikangConfirmTime: getVal('ruisikangConfirmTime'),
          confirmTime: getVal('confirmTime'),
          clearOperator: getVal('clearOperator'),
          ruisikangClearTime: getVal('ruisikangClearTime'),
          additionalInfo: getVal('additionalInfo'),
          alarmSource: getVal('alarmSource'),
        };

        newAlarms.push(alarm);
      } catch {
        failedCount++;
      }
    });

    // 模拟进度
    let progress = 0;
    const interval = setInterval(async () => {
      progress += 10;
      setImportProgress(Math.min(progress, 100));
      if (progress >= 100) {
        clearInterval(interval);

        // V1.1: 如果当前无活跃项目，自动创建默认项目
        // 创建项目后 activeProjectId 被设置，addAlarms 将自动持久化到 IndexedDB
        const currentState = useAppStore.getState();
        if (!currentState.activeProjectId) {
          try {
            await currentState.createProject('默认项目');
          } catch (err) {
            console.error('[Import] Auto-create default project failed:', err);
          }
        }

        addAlarms(newAlarms);
        setImportResult({
          success: newAlarms.length,
          failed: failedCount,
          total: allRows.length,
        });
        setImportState('done');
      }
    }, 50);
  }, [allRows, columnMappings, addAlarms, importMode, handleNEImport]);

  /** 重置导入 */
  const handleReset = () => {
    setImportState('idle');
    setHeaders([]);
    setPreviewRows([]);
    setAllRows([]);
    setColumnMappings([]);
    setImportProgress(0);
    setImportResult(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  /** 当前活跃项目名称 */
  const activeProject = projects.find((p) => p.id === activeProjectId);

  return (
    <Box>
      {/* 文件上传区域 */}
      {(importState === 'idle') && (
        <Box>
          {/* 导入模式切换 */}
          <Box sx={{ display: 'flex', gap: 2, mb: 2, justifyContent: 'center' }}>
            <Chip
              label="导入告警数据"
              color={importMode === 'alarm' ? 'primary' : 'default'}
              onClick={() => setImportMode('alarm')}
              variant={importMode === 'alarm' ? 'filled' : 'outlined'}
            />
            <Chip
              label="导入网元信息"
              color={importMode === 'ne' ? 'primary' : 'default'}
              onClick={() => setImportMode('ne')}
              variant={importMode === 'ne' ? 'filled' : 'outlined'}
            />
          </Box>
          <Card
          sx={{
            backgroundColor: '#1a2332',
            p: 4,
            textAlign: 'center',
            border: isDragOver ? '2px dashed #2196f3' : '2px dashed #2d3d50',
            borderRadius: 2,
            transition: 'border-color 0.2s',
            cursor: 'pointer',
          }}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onClick={async () => {
            if (isElectron && electronAPI) {
              const dialogResult = await electronAPI.openFileDialog();
              if (!dialogResult.canceled && dialogResult.filePath) {
                try {
                  const result = await electronAPI.parseXLS(dialogResult.filePath);
                  handleParseResult(result, importMode);
                } catch (err) {
                  setSnackMsg('文件解析出错: ' + (err as Error).message);
                  setSnackOpen(true);
                }
              }
            } else if (fileInputRef.current) {
              fileInputRef.current.click();
            }
          }}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".xls,.xlsx"
            style={{ display: 'none' }}
            onChange={handleFileSelect}
          />
          <CloudUploadIcon sx={{ fontSize: 64, color: '#2d3d50', mb: 2 }} />
          <Typography variant="h6" sx={{ color: '#9e9e9e', mb: 1 }}>
            拖拽XLS/XLSX文件到此处，或点击选择文件
          </Typography>
          <Typography variant="body2" sx={{ color: '#666' }}>
            {importMode === 'ne'
              ? '支持烽火网管导出的网元查询报表格式'
              : '支持烽火通信FONST告警查询报表格式'}
          </Typography>
        </Card>
      </Box>
      )}

      {/* 清除网元数据 */}
      {importMode === 'ne' && networkElements.length > 0 && (
        <Card sx={{ backgroundColor: '#1a2332', p: 2, mb: 2, border: '1px solid #f4433633' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Box>
              <Typography variant="subtitle2" sx={{ fontWeight: 600, color: '#e0e0e0' }}>
                当前网元数据
              </Typography>
              <Typography variant="caption" sx={{ color: '#9e9e9e' }}>
                共 {networkElements.length} 条网元记录（{new Set(networkElements.map(ne => ne.province)).size} 个省）
              </Typography>
            </Box>
            <Button
              variant="outlined"
              color="error"
              startIcon={<DeleteIcon />}
              onClick={() => {
                setNetworkElements([]);
                setSnackMsg('网元数据已清除');
                setSnackOpen(true);
              }}
            >
              清除网元数据
            </Button>
          </Box>
        </Card>
      )}

      {/* 清除告警数据 */}
      {alarms.length > 0 && (
        <Card sx={{ backgroundColor: '#1a2332', p: 2, mb: 2, border: '1px solid #ff980033' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Box>
              <Typography variant="subtitle2" sx={{ fontWeight: 600, color: '#e0e0e0' }}>
                当前告警数据
              </Typography>
              <Typography variant="caption" sx={{ color: '#9e9e9e' }}>
                共 {alarms.length} 条告警记录
              </Typography>
            </Box>
            <Button
              variant="outlined"
              color="warning"
              startIcon={<DeleteIcon />}
              onClick={() => {
                setAlarms([]);
                setSnackMsg('告警数据已清除');
                setSnackOpen(true);
              }}
            >
              清除告警数据
            </Button>
          </Box>
        </Card>
      )}

      {/* 数据预览 */}
      {importState === 'preview' && (
        <Box>
          <Card sx={{ backgroundColor: '#1a2332', p: 2, mb: 2 }}>
            <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 600 }}>
              数据预览（前10行）
            </Typography>
            <TableContainer sx={{ maxHeight: 300 }}>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    {headers.map((header, i) => (
                      <TableCell key={i} sx={{ fontSize: 12, fontWeight: 600 }}>
                        {header}
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {previewRows.map((row, ri) => (
                    <TableRow key={ri}>
                      {headers.map((_, ci) => (
                        <TableCell key={ci} sx={{ fontSize: 11, color: '#9e9e9e', maxWidth: 150 }}>
                          <Typography variant="body2" noWrap sx={{ fontSize: 11 }}>
                            {row[ci] || ''}
                          </Typography>
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            <Typography variant="caption" sx={{ color: '#9e9e9e', mt: 1, display: 'block' }}>
              共 {allRows.length} 行数据，{headers.length} 列
            </Typography>
          </Card>

          {/* 列映射配置 */}
          <Card sx={{ backgroundColor: '#1a2332', p: 2, mb: 2 }}>
            <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 600 }}>
              列映射配置
            </Typography>
            <Typography variant="body2" sx={{ color: '#9e9e9e', mb: 2 }}>
              系统已自动匹配列名，请检查并手动调整未匹配的字段
            </Typography>
            <Grid container spacing={1}>
              {headers.map((header, index) => {
                const mapping = columnMappings[index];
                const isMapped = mapping.targetField !== '';
                return (
                  <Grid item xs={12} md={4} key={index}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Chip
                        label={header}
                        size="small"
                        sx={{
                          fontSize: 11,
                          maxWidth: 150,
                          backgroundColor: isMapped ? '#2196f322' : '#f4433622',
                          color: isMapped ? '#2196f3' : '#f44336',
                        }}
                      />
                      <Typography variant="caption" sx={{ color: '#666' }}>→</Typography>
                      <FormControl size="small" sx={{ minWidth: 120 }} fullWidth>
                        <Select
                          value={mapping.targetField}
                          onChange={(e) => handleMappingChange(index, e.target.value)}
                          displayEmpty
                          sx={{ fontSize: 12, height: 28 }}
                        >
                          <MenuItem value="" sx={{ fontSize: 12, color: '#666' }}>
                            不映射
                          </MenuItem>
                          {Object.entries(importMode === 'ne' ? NE_FIELD_LABELS : FIELD_LABELS).map(([field, label]) => (
                            <MenuItem key={field} value={field} sx={{ fontSize: 12 }}>
                              {label}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Box>
                  </Grid>
                );
              })}
            </Grid>
          </Card>

          {/* 操作按钮 */}
          <Box sx={{ display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
            <Button variant="outlined" onClick={handleReset} sx={{ color: '#9e9e9e' }}>
              取消
            </Button>
            <Button
              variant="contained"
              onClick={handleImport}
              sx={{ backgroundColor: '#2196f3' }}
            >
              {importMode === 'ne' ? '开始导入网元' : '开始导入'}
            </Button>
          </Box>
        </Box>
      )}

      {/* 导入进度 */}
      {importState === 'importing' && (
        <Card sx={{ backgroundColor: '#1a2332', p: 4, textAlign: 'center' }}>
          <Typography variant="h6" sx={{ mb: 2 }}>
            {importMode === 'ne' ? '正在导入网元数据...' : '正在导入数据...'}
          </Typography>
          <LinearProgress
            variant="determinate"
            value={importProgress}
            sx={{ height: 8, borderRadius: 4, mb: 1 }}
          />
          <Typography variant="body2" sx={{ color: '#9e9e9e' }}>
            {importProgress}% 完成
          </Typography>
        </Card>
      )}

      {/* 导入结果 */}
      {importState === 'done' && importResult && (
        <Card sx={{ backgroundColor: '#1a2332', p: 4, textAlign: 'center' }}>
          <CheckCircleIcon sx={{ fontSize: 64, color: '#4caf50', mb: 2 }} />
          <Typography variant="h6" sx={{ mb: 2 }}>
            {importMode === 'ne' ? '网元导入完成' : '导入完成'}
          </Typography>
          <Box sx={{ display: 'flex', justifyContent: 'center', gap: 4, mb: 3 }}>
            <Box>
              <Typography variant="h4" sx={{ color: '#4caf50', fontWeight: 700 }}>
                {importResult.success}
              </Typography>
              <Typography variant="body2" sx={{ color: '#9e9e9e' }}>成功导入</Typography>
            </Box>
            {importResult.failed > 0 && (
              <Box>
                <Typography variant="h4" sx={{ color: '#f44336', fontWeight: 700 }}>
                  {importResult.failed}
                </Typography>
                <Typography variant="body2" sx={{ color: '#9e9e9e' }}>导入失败</Typography>
              </Box>
            )}
            <Box>
              <Typography variant="h4" sx={{ fontWeight: 700 }}>
                {importResult.total}
              </Typography>
              <Typography variant="body2" sx={{ color: '#9e9e9e' }}>总计</Typography>
            </Box>
          </Box>
          <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center' }}>
            <Button variant="outlined" onClick={handleReset} sx={{ color: '#9e9e9e' }}>
              继续导入
            </Button>
            <Button
              variant="contained"
              sx={{ backgroundColor: '#2196f3' }}
              onClick={() => useAppStore.getState().setCurrentPage(importMode === 'ne' ? 'topology' : 'analysis')}
            >
              {importMode === 'ne' ? '查看拓扑' : '查看告警分析'}
            </Button>
          </Box>
          {/* V1.1: 显示当前项目名称 */}
          {activeProject && (
            <Typography variant="caption" sx={{ color: '#9e9e9e', mt: 2, display: 'block' }}>
              当前项目: {activeProject.name}
            </Typography>
          )}
          {importMode === 'ne' ? (
            <Typography variant="caption" sx={{ color: '#9e9e9e', mt: 1, display: 'block' }}>
              当前网元总数: {networkElements.length} 条
            </Typography>
          ) : (
            <Typography variant="caption" sx={{ color: '#9e9e9e', mt: 1, display: 'block' }}>
              当前告警总数: {alarms.length + importResult.success} 条
            </Typography>
          )}
        </Card>
      )}

      <Snackbar
        open={snackOpen}
        autoHideDuration={3000}
        onClose={() => setSnackOpen(false)}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert severity="error" onClose={() => setSnackOpen(false)} sx={{ width: '100%' }}>
          {snackMsg}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default Import;
