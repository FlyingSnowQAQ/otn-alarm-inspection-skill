import React, { useMemo, useState } from 'react';
import {
  Box,
  Card,
  Typography,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Chip,
  Divider,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
} from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import * as XLSX from 'xlsx';
import useAppStore from '../store/useAppStore';
import type { AlarmLevel } from '../types';
import { ALARM_LEVEL_COLORS, ALARM_LEVEL_ORDER } from '../types';
import dayjs from 'dayjs';

/** 报表页面 */
const Report: React.FC = () => {
  const { alarms, networkElements } = useAppStore();
  const [reportType, setReportType] = useState<'summary' | 'inspection'>('summary');
  const [reportPeriod, setReportPeriod] = useState<'week' | 'month' | 'quarter'>('month');

  /** 告警汇总统计 */
  const summaryStats = useMemo(() => {
    const total = alarms.length;
    const levelStats: Record<AlarmLevel, { total: number; active: number; cleared: number }> = {
      '紧急': { total: 0, active: 0, cleared: 0 },
      '主要': { total: 0, active: 0, cleared: 0 },
      '次要': { total: 0, active: 0, cleared: 0 },
      '提示': { total: 0, active: 0, cleared: 0 },
    };

    alarms.forEach((a) => {
      levelStats[a.alarmLevel].total += 1;
      if (a.alarmStatus === '已确认已清除') {
        levelStats[a.alarmLevel].cleared += 1;
      } else {
        levelStats[a.alarmLevel].active += 1;
      }
    });

    const activeAlarms = alarms.filter((a) => a.alarmStatus !== '已确认已清除').length;
    const clearedAlarms = total - activeAlarms;
    const clearanceRate = total > 0 ? ((clearedAlarms / total) * 100).toFixed(1) : '0.0';

    return { total, activeAlarms, clearedAlarms, clearanceRate, levelStats };
  }, [alarms]);

  /** 按网元类型统计 */
  const neTypeStats = useMemo(() => {
    const stats: Record<string, { type: string; count: number; critical: number }> = {};
    alarms.forEach((alarm) => {
      const ne = networkElements.find((n) => n.neName === alarm.neName);
      const neType = ne ? ne.neType : '未知';
      if (!stats[neType]) {
        stats[neType] = { type: neType, count: 0, critical: 0 };
      }
      stats[neType].count += 1;
      if (alarm.alarmLevel === '紧急') {
        stats[neType].critical += 1;
      }
    });
    return Object.values(stats);
  }, [alarms, networkElements]);

  /** 网元巡检报告数据 */
  const inspectionData = useMemo(() => {
    return networkElements.map((ne) => {
      const neAlarms = alarms.filter((a) => a.neName === ne.neName);
      const activeAlarms = neAlarms.filter((a) => a.alarmStatus !== '已确认已清除');
      const criticalCount = activeAlarms.filter((a) => a.alarmLevel === '紧急').length;
      const majorCount = activeAlarms.filter((a) => a.alarmLevel === '主要').length;
      const minorCount = activeAlarms.filter((a) => a.alarmLevel === '次要').length;
      const infoCount = activeAlarms.filter((a) => a.alarmLevel === '提示').length;

      const healthScore = Math.max(0, 100 - criticalCount * 20 - majorCount * 10 - minorCount * 5 - infoCount * 2);
      const healthStatus = healthScore >= 90 ? '优秀' : healthScore >= 70 ? '良好' : healthScore >= 50 ? '一般' : '较差';

      return {
        neName: ne.neName,
        neType: ne.neType,
        province: ne.province,
        city: ne.city,
        ipAddress: ne.ipAddress,
        onlineStatus: ne.onlineStatus,
        totalAlarms: neAlarms.length,
        activeAlarms: activeAlarms.length,
        criticalCount,
        majorCount,
        minorCount,
        infoCount,
        healthScore,
        healthStatus,
      };
    }).sort((a, b) => a.healthScore - b.healthScore);
  }, [networkElements, alarms]);

  /** 按省份统计（饼图数据） */
  const provinceChartData = useMemo(() => {
    const map: Record<string, number> = {};
    alarms.forEach((a) => {
      const ne = networkElements.find((n) => n.neName === a.neName);
      const prov = ne ? ne.province.replace('省', '').replace('市', '') : '未知';
      map[prov] = (map[prov] || 0) + 1;
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [alarms, networkElements]);

  /** 级别分布图数据 */
  const levelChartData = useMemo(() => {
    return (['紧急', '主要', '次要', '提示'] as AlarmLevel[]).map((level) => ({
      name: level,
      总数: summaryStats.levelStats[level].total,
      活动中: summaryStats.levelStats[level].active,
      已清除: summaryStats.levelStats[level].cleared,
    }));
  }, [summaryStats]);

  /** 导出Excel */
  const handleExportExcel = () => {
    const wb = XLSX.utils.book_new();

    if (reportType === 'summary') {
      // 告警汇总表
      const summaryData = alarms.map((a) => ({
        '告警序号': a.alarmNo,
        '告警标题': a.alarmTitle,
        '告警名称': a.alarmName,
        '告警级别': a.alarmLevel,
        '网元名称': a.neName,
        '网元IP': a.neIp,
        '槽位号': a.slotNo,
        '盘名称': a.boardName,
        '端口号': a.portNo,
        '告警类型': a.alarmType,
        '告警状态': a.alarmStatus,
        '首次发生时间': a.firstOccurTime,
        '最近发生时间': a.lastOccurTime,
        '告警清除时间': a.clearTime,
        '告警持续时长': a.duration,
        '确认操作者': a.confirmOperator,
        '确认时间': a.confirmTime,
        '清除操作者': a.clearOperator,
        '附加信息': a.additionalInfo,
        '告警源': a.alarmSource,
      }));
      const ws = XLSX.utils.json_to_sheet(summaryData);
      XLSX.utils.book_append_sheet(wb, ws, '告警汇总');
    } else {
      // 网元巡检表
      const inspectionExportData = inspectionData.map((item) => ({
        '网元名称': item.neName,
        '网元类型': item.neType,
        '省份': item.province,
        '城市': item.city,
        'IP地址': item.ipAddress,
        '在线状态': item.onlineStatus,
        '告警总数': item.totalAlarms,
        '活动告警数': item.activeAlarms,
        '紧急告警': item.criticalCount,
        '主要告警': item.majorCount,
        '次要告警': item.minorCount,
        '提示告警': item.infoCount,
        '健康评分': item.healthScore,
        '健康状态': item.healthStatus,
      }));
      const ws = XLSX.utils.json_to_sheet(inspectionExportData);
      XLSX.utils.book_append_sheet(wb, ws, '网元巡检报告');
    }

    XLSX.writeFile(wb, `OTN_${reportType === 'summary' ? '告警汇总' : '网元巡检'}_${dayjs().format('YYYYMMDD')}.xlsx`);
  };

  /** 导出PDF（使用浏览器打印功能） */
  const handleExportPdf = () => {
    window.print();
  };

  const PIE_COLORS = ['#f44336', '#ff9800', '#ffc107', '#2196f3', '#4caf50', '#9c27b0'];

  /** 获取时间范围文字 */
  const getPeriodLabel = () => {
    switch (reportPeriod) {
      case 'week': return '近一周';
      case 'month': return '近一月';
      case 'quarter': return '近一季度';
    }
  };

  return (
    <Box>
      {/* 工具栏 */}
      <Card sx={{ backgroundColor: '#1a2332', p: 2, mb: 2 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
            <FormControl size="small" sx={{ minWidth: 140 }}>
              <InputLabel>报表类型</InputLabel>
              <Select
                value={reportType}
                label="报表类型"
                onChange={(e) => setReportType(e.target.value as 'summary' | 'inspection')}
              >
                <MenuItem value="summary">告警汇总报表</MenuItem>
                <MenuItem value="inspection">网元巡检报告</MenuItem>
              </Select>
            </FormControl>
            <FormControl size="small" sx={{ minWidth: 120 }}>
              <InputLabel>统计周期</InputLabel>
              <Select
                value={reportPeriod}
                label="统计周期"
                onChange={(e) => setReportPeriod(e.target.value as 'week' | 'month' | 'quarter')}
              >
                <MenuItem value="week">近一周</MenuItem>
                <MenuItem value="month">近一月</MenuItem>
                <MenuItem value="quarter">近一季度</MenuItem>
              </Select>
            </FormControl>
          </Box>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button
              variant="outlined"
              startIcon={<DownloadIcon />}
              onClick={handleExportExcel}
              sx={{ color: '#4caf50', borderColor: '#4caf50' }}
            >
              导出Excel
            </Button>
            <Button
              variant="outlined"
              startIcon={<PictureAsPdfIcon />}
              onClick={handleExportPdf}
              sx={{ color: '#f44336', borderColor: '#f44336' }}
            >
              导出PDF
            </Button>
          </Box>
        </Box>
      </Card>

      {reportType === 'summary' ? (
        /** 告警汇总报表 */
        <Box>
          {/* 标题 */}
          <Card sx={{ backgroundColor: '#1a2332', p: 3, mb: 2 }}>
            <Typography variant="h5" sx={{ fontWeight: 700, mb: 1 }}>
              OTN历史告警汇总报表
            </Typography>
            <Typography variant="body2" sx={{ color: '#9e9e9e' }}>
              统计周期：{getPeriodLabel()} | 生成时间：{dayjs().format('YYYY-MM-DD HH:mm:ss')} | 一干400G OTN网络
            </Typography>
          </Card>

          {/* 概览统计 */}
          <Grid container spacing={2} sx={{ mb: 2 }}>
            <Grid item xs={6} md={3}>
              <Card sx={{ backgroundColor: '#1a2332', p: 2, textAlign: 'center' }}>
                <Typography variant="body2" sx={{ color: '#9e9e9e' }}>告警总数</Typography>
                <Typography variant="h4" sx={{ fontWeight: 700 }}>{summaryStats.total}</Typography>
              </Card>
            </Grid>
            <Grid item xs={6} md={3}>
              <Card sx={{ backgroundColor: '#1a2332', p: 2, textAlign: 'center' }}>
                <Typography variant="body2" sx={{ color: '#9e9e9e' }}>活动告警</Typography>
                <Typography variant="h4" sx={{ fontWeight: 700, color: '#f44336' }}>{summaryStats.activeAlarms}</Typography>
              </Card>
            </Grid>
            <Grid item xs={6} md={3}>
              <Card sx={{ backgroundColor: '#1a2332', p: 2, textAlign: 'center' }}>
                <Typography variant="body2" sx={{ color: '#9e9e9e' }}>已清除告警</Typography>
                <Typography variant="h4" sx={{ fontWeight: 700, color: '#4caf50' }}>{summaryStats.clearedAlarms}</Typography>
              </Card>
            </Grid>
            <Grid item xs={6} md={3}>
              <Card sx={{ backgroundColor: '#1a2332', p: 2, textAlign: 'center' }}>
                <Typography variant="body2" sx={{ color: '#9e9e9e' }}>告警清除率</Typography>
                <Typography variant="h4" sx={{ fontWeight: 700, color: '#2196f3' }}>{summaryStats.clearanceRate}%</Typography>
              </Card>
            </Grid>
          </Grid>

          {/* 图表 */}
          <Grid container spacing={2} sx={{ mb: 2 }}>
            <Grid item xs={12} md={6}>
              <Card sx={{ backgroundColor: '#1a2332', p: 2, height: 300 }}>
                <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>告警级别分布</Typography>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={levelChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#2d3d50" />
                    <XAxis dataKey="name" stroke="#9e9e9e" fontSize={12} />
                    <YAxis stroke="#9e9e9e" fontSize={12} />
                    <Tooltip contentStyle={{ backgroundColor: '#1a2332', border: '1px solid #2d3d50', borderRadius: 8, color: '#e0e0e0' }} />
                    <Legend />
                    <Bar dataKey="活动中" fill="#ff9800" radius={[2, 2, 0, 0]} />
                    <Bar dataKey="已清除" fill="#4caf50" radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </Card>
            </Grid>
            <Grid item xs={12} md={6}>
              <Card sx={{ backgroundColor: '#1a2332', p: 2, height: 300 }}>
                <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>各省份告警分布</Typography>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie data={provinceChartData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                      {provinceChartData.map((_entry, index) => (
                        <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: '#1a2332', border: '1px solid #2d3d50', borderRadius: 8, color: '#e0e0e0' }} />
                  </PieChart>
                </ResponsiveContainer>
              </Card>
            </Grid>
          </Grid>

          {/* 级别明细表 */}
          <Card sx={{ backgroundColor: '#1a2332', p: 2, mb: 2 }}>
            <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>告警级别明细</Typography>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>告警级别</TableCell>
                  <TableCell align="center">总数</TableCell>
                  <TableCell align="center">活动中</TableCell>
                  <TableCell align="center">已清除</TableCell>
                  <TableCell align="center">清除率</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {(['紧急', '主要', '次要', '提示'] as AlarmLevel[]).map((level) => {
                  const s = summaryStats.levelStats[level];
                  const rate = s.total > 0 ? ((s.cleared / s.total) * 100).toFixed(1) : '0.0';
                  return (
                    <TableRow key={level}>
                      <TableCell>
                        <Chip
                          label={level}
                          size="small"
                          sx={{
                            backgroundColor: `${ALARM_LEVEL_COLORS[level]}22`,
                            color: ALARM_LEVEL_COLORS[level],
                            fontWeight: 600,
                            fontSize: 12,
                          }}
                        />
                      </TableCell>
                      <TableCell align="center">{s.total}</TableCell>
                      <TableCell align="center" sx={{ color: '#f44336' }}>{s.active}</TableCell>
                      <TableCell align="center" sx={{ color: '#4caf50' }}>{s.cleared}</TableCell>
                      <TableCell align="center">{rate}%</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </Card>

          {/* 按设备类型统计 */}
          <Card sx={{ backgroundColor: '#1a2332', p: 2 }}>
            <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>设备类型告警统计</Typography>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>设备类型</TableCell>
                  <TableCell align="center">告警总数</TableCell>
                  <TableCell align="center">紧急告警</TableCell>
                  <TableCell align="center">占比</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {neTypeStats.map((item) => (
                  <TableRow key={item.type}>
                    <TableCell>{item.type}</TableCell>
                    <TableCell align="center">{item.count}</TableCell>
                    <TableCell align="center" sx={{ color: item.critical > 0 ? '#f44336' : 'inherit' }}>
                      {item.critical}
                    </TableCell>
                    <TableCell align="center">
                      {summaryStats.total > 0 ? ((item.count / summaryStats.total) * 100).toFixed(1) : '0.0'}%
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </Box>
      ) : (
        /** 网元巡检报告 */
        <Box>
          {/* 标题 */}
          <Card sx={{ backgroundColor: '#1a2332', p: 3, mb: 2 }}>
            <Typography variant="h5" sx={{ fontWeight: 700, mb: 1 }}>
              OTN网元巡检报告
            </Typography>
            <Typography variant="body2" sx={{ color: '#9e9e9e' }}>
              统计周期：{getPeriodLabel()} | 生成时间：{dayjs().format('YYYY-MM-DD HH:mm:ss')} | 一干400G OTN网络
            </Typography>
          </Card>

          {/* 巡检概览 */}
          <Grid container spacing={2} sx={{ mb: 2 }}>
            <Grid item xs={6} md={2}>
              <Card sx={{ backgroundColor: '#1a2332', p: 2, textAlign: 'center' }}>
                <Typography variant="body2" sx={{ color: '#9e9e9e' }}>巡检网元数</Typography>
                <Typography variant="h5" sx={{ fontWeight: 700 }}>{networkElements.length}</Typography>
              </Card>
            </Grid>
            <Grid item xs={6} md={2}>
              <Card sx={{ backgroundColor: '#1a2332', p: 2, textAlign: 'center' }}>
                <Typography variant="body2" sx={{ color: '#9e9e9e' }}>在线网元</Typography>
                <Typography variant="h5" sx={{ fontWeight: 700, color: '#4caf50' }}>
                  {networkElements.filter((ne) => ne.onlineStatus === '在线').length}
                </Typography>
              </Card>
            </Grid>
            <Grid item xs={6} md={2}>
              <Card sx={{ backgroundColor: '#1a2332', p: 2, textAlign: 'center' }}>
                <Typography variant="body2" sx={{ color: '#9e9e9e' }}>离线网元</Typography>
                <Typography variant="h5" sx={{ fontWeight: 700, color: '#f44336' }}>
                  {networkElements.filter((ne) => ne.onlineStatus !== '在线').length}
                </Typography>
              </Card>
            </Grid>
            <Grid item xs={6} md={2}>
              <Card sx={{ backgroundColor: '#1a2332', p: 2, textAlign: 'center' }}>
                <Typography variant="body2" sx={{ color: '#9e9e9e' }}>健康度优秀</Typography>
                <Typography variant="h5" sx={{ fontWeight: 700, color: '#4caf50' }}>
                  {inspectionData.filter((d) => d.healthScore >= 90).length}
                </Typography>
              </Card>
            </Grid>
            <Grid item xs={6} md={2}>
              <Card sx={{ backgroundColor: '#1a2332', p: 2, textAlign: 'center' }}>
                <Typography variant="body2" sx={{ color: '#9e9e9e' }}>需要关注</Typography>
                <Typography variant="h5" sx={{ fontWeight: 700, color: '#ff9800' }}>
                  {inspectionData.filter((d) => d.healthScore < 70).length}
                </Typography>
              </Card>
            </Grid>
            <Grid item xs={6} md={2}>
              <Card sx={{ backgroundColor: '#1a2332', p: 2, textAlign: 'center' }}>
                <Typography variant="body2" sx={{ color: '#9e9e9e' }}>平均健康度</Typography>
                <Typography variant="h5" sx={{ fontWeight: 700, color: '#2196f3' }}>
                  {inspectionData.length > 0
                    ? (inspectionData.reduce((s, d) => s + d.healthScore, 0) / inspectionData.length).toFixed(1)
                    : '0'}
                </Typography>
              </Card>
            </Grid>
          </Grid>

          {/* 网元巡检详情表 */}
          <Card sx={{ backgroundColor: '#1a2332', p: 2 }}>
            <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
              网元巡检详情（按健康度排序）
            </Typography>
            <TableContainer sx={{ maxHeight: 500 }}>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell>网元名称</TableCell>
                    <TableCell>类型</TableCell>
                    <TableCell>省份/城市</TableCell>
                    <TableCell align="center">IP地址</TableCell>
                    <TableCell align="center">状态</TableCell>
                    <TableCell align="center">活动告警</TableCell>
                    <TableCell align="center">紧急</TableCell>
                    <TableCell align="center">主要</TableCell>
                    <TableCell align="center">次要</TableCell>
                    <TableCell align="center">提示</TableCell>
                    <TableCell align="center">健康评分</TableCell>
                    <TableCell align="center">健康状态</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {inspectionData.map((item) => {
                    const scoreColor =
                      item.healthScore >= 90
                        ? '#4caf50'
                        : item.healthScore >= 70
                          ? '#ffc107'
                          : item.healthScore >= 50
                            ? '#ff9800'
                            : '#f44336';
                    return (
                      <TableRow
                        key={item.neName}
                        sx={{
                          borderLeft: `3px solid ${scoreColor}`,
                        }}
                      >
                        <TableCell sx={{ fontSize: 12 }}>
                          <Typography variant="body2" noWrap sx={{ fontSize: 12, maxWidth: 200 }}>
                            {item.neName.split('-').slice(2).join('-')}
                          </Typography>
                        </TableCell>
                        <TableCell sx={{ fontSize: 12 }}>{item.neType}</TableCell>
                        <TableCell sx={{ fontSize: 12 }}>{item.province.replace('省', '').replace('市', '')}/{item.city.replace('市', '').replace('区', '')}</TableCell>
                        <TableCell align="center" sx={{ fontSize: 12, color: '#9e9e9e' }}>{item.ipAddress}</TableCell>
                        <TableCell align="center">
                          <Chip
                            label={item.onlineStatus}
                            size="small"
                            color={item.onlineStatus === '在线' ? 'success' : 'error'}
                            sx={{ height: 18, fontSize: 10 }}
                          />
                        </TableCell>
                        <TableCell align="center" sx={{ fontSize: 12, fontWeight: 600 }}>
                          {item.activeAlarms}
                        </TableCell>
                        <TableCell align="center" sx={{ fontSize: 12, color: item.criticalCount > 0 ? '#f44336' : 'inherit' }}>
                          {item.criticalCount}
                        </TableCell>
                        <TableCell align="center" sx={{ fontSize: 12, color: item.majorCount > 0 ? '#ff9800' : 'inherit' }}>
                          {item.majorCount}
                        </TableCell>
                        <TableCell align="center" sx={{ fontSize: 12, color: item.minorCount > 0 ? '#ffc107' : 'inherit' }}>
                          {item.minorCount}
                        </TableCell>
                        <TableCell align="center" sx={{ fontSize: 12 }}>{item.infoCount}</TableCell>
                        <TableCell align="center" sx={{ fontSize: 13, fontWeight: 700, color: scoreColor }}>
                          {item.healthScore}
                        </TableCell>
                        <TableCell align="center">
                          <Chip
                            label={item.healthStatus}
                            size="small"
                            sx={{
                              height: 20,
                              fontSize: 11,
                              fontWeight: 600,
                              backgroundColor: `${scoreColor}22`,
                              color: scoreColor,
                            }}
                          />
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          </Card>
        </Box>
      )}
    </Box>
  );
};

export default Report;
