import React, { useMemo, useState } from 'react';
import {
  Box,
  Card,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  TableSortLabel,
  Chip,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
  Grid,
  InputAdornment,
  Button,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import SearchIcon from '@mui/icons-material/Search';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import useAppStore from '../store/useAppStore';
import type { AlarmLevel, AlarmType, AlarmStatus, AlarmRecord, TimeWindowMinutes } from '../types';
import { ALARM_LEVEL_COLORS, ALARM_LEVEL_ORDER } from '../types';
import { aggregate } from '../utils/alarmAggregator';
import AlarmTimeline from '../components/AlarmTimeline';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import dayjs from 'dayjs';

/** 排序方向 */
type Order = 'asc' | 'desc';

/** 可排序字段 */
type SortableField = 'alarmNo' | 'alarmLevel' | 'firstOccurTime' | 'alarmStatus';

/** 告警分析页面 */
const AlarmAnalysis: React.FC = () => {
  const {
    alarms,
    networkElements,
    aggregationViewMode,
    aggregationWindow,
    setAggregationViewMode,
    setAggregationWindow,
  } = useAppStore();

  // 筛选状态
  const [levelFilter, setLevelFilter] = useState<string>('全部');
  const [typeFilter, setTypeFilter] = useState<string>('全部');
  const [statusFilter, setStatusFilter] = useState<string>('全部');
  const [neFilter, setNeFilter] = useState<string>('全部');
  const [searchText, setSearchText] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // 排序状态
  const [orderBy, setOrderBy] = useState<SortableField>('firstOccurTime');
  const [order, setOrder] = useState<Order>('desc');

  // 分页状态
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  // 告警详情弹窗
  const [selectedAlarm, setSelectedAlarm] = useState<AlarmRecord | null>(null);

  /** 筛选后的告警列表 */
  const filteredAlarms = useMemo(() => {
    return alarms.filter((alarm) => {
      if (levelFilter !== '全部' && alarm.alarmLevel !== levelFilter) return false;
      if (typeFilter !== '全部' && alarm.alarmType !== typeFilter) return false;
      if (statusFilter !== '全部' && alarm.alarmStatus !== statusFilter) return false;
      if (neFilter !== '全部' && alarm.neName !== neFilter) return false;
      if (searchText) {
        const keyword = searchText.toLowerCase();
        const matchesSearch =
          alarm.alarmTitle.toLowerCase().includes(keyword) ||
          alarm.alarmName.toLowerCase().includes(keyword) ||
          alarm.neName.toLowerCase().includes(keyword) ||
          alarm.boardName.toLowerCase().includes(keyword) ||
          alarm.additionalInfo.toLowerCase().includes(keyword);
        if (!matchesSearch) return false;
      }
      if (startDate && dayjs(alarm.firstOccurTime).isBefore(dayjs(startDate))) return false;
      if (endDate && dayjs(alarm.firstOccurTime).isAfter(dayjs(endDate + ' 23:59:59'))) return false;
      return true;
    });
  }, [alarms, levelFilter, typeFilter, statusFilter, neFilter, searchText, startDate, endDate]);

  /** 排序后的告警列表 */
  const sortedAlarms = useMemo(() => {
    return [...filteredAlarms].sort((a, b) => {
      let comparison = 0;
      switch (orderBy) {
        case 'alarmNo':
          comparison = a.alarmNo - b.alarmNo;
          break;
        case 'alarmLevel':
          comparison = ALARM_LEVEL_ORDER[a.alarmLevel] - ALARM_LEVEL_ORDER[b.alarmLevel];
          break;
        case 'firstOccurTime':
          comparison = a.firstOccurTime.localeCompare(b.firstOccurTime);
          break;
        case 'alarmStatus':
          comparison = a.alarmStatus.localeCompare(b.alarmStatus);
          break;
      }
      return order === 'desc' ? -comparison : comparison;
    });
  }, [filteredAlarms, orderBy, order]);

  /** 当前页数据 */
  const pagedAlarms = useMemo(() => {
    return sortedAlarms.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);
  }, [sortedAlarms, page, rowsPerPage]);

  /** 处理排序 */
  const handleSort = (field: SortableField) => {
    if (orderBy === field) {
      setOrder(order === 'asc' ? 'desc' : 'asc');
    } else {
      setOrderBy(field);
      setOrder('desc');
    }
  };

  /** 重置筛选 */
  const handleResetFilters = () => {
    setLevelFilter('全部');
    setTypeFilter('全部');
    setStatusFilter('全部');
    setNeFilter('全部');
    setSearchText('');
    setStartDate('');
    setEndDate('');
  };

  /** 按级别统计 */
  const levelChartData = useMemo(() => {
    const data: { name: string; value: number; color: string }[] = [];
    const levels: AlarmLevel[] = ['紧急', '主要', '次要', '提示'];
    levels.forEach((level) => {
      const count = filteredAlarms.filter((a) => a.alarmLevel === level).length;
      data.push({ name: level, value: count, color: ALARM_LEVEL_COLORS[level] });
    });
    return data;
  }, [filteredAlarms]);

  /** 按省份统计 */
  const provinceChartData = useMemo(() => {
    const map: Record<string, number> = {};
    filteredAlarms.forEach((alarm) => {
      const province = alarm.province || '未知';
      // 简化省份名称用于图表显示
      const displayName = province.replace(/省|市|自治区|维吾尔|壮族|回族/g, '').replace(/\(.*\)/, '');
      map[displayName] = (map[displayName] || 0) + 1;
    });
    return Object.entries(map)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
  }, [filteredAlarms, networkElements]);

  /** 网元名称列表（去重） */
  const neNames = useMemo(() => {
    const set = new Set(alarms.map((a) => a.neName));
    return ['全部', ...Array.from(set).sort()];
  }, [alarms]);

  /** 聚合模式下生成的告警分组 */
  const aggregatedGroups = useMemo(() => {
    if (aggregationViewMode !== 'aggregated') return [];
    return aggregate(alarms, aggregationWindow);
  }, [alarms, aggregationViewMode, aggregationWindow]);

  return (
    <Box>
      {/* 统计图表 */}
      <Grid container spacing={2} sx={{ mb: 2 }}>
        <Grid item xs={12} md={6}>
          <Card sx={{ backgroundColor: '#1a2332', p: 2, height: 260 }}>
            <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
              告警级别分布（筛选结果）
            </Typography>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={levelChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={3}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}
                >
                  {levelChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1a2332',
                    border: '1px solid #2d3d50',
                    borderRadius: 8,
                    color: '#e0e0e0',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </Grid>
        <Grid item xs={12} md={6}>
          <Card sx={{ backgroundColor: '#1a2332', p: 2, height: 260 }}>
            <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
              各省份告警统计（筛选结果）
            </Typography>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={provinceChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2d3d50" />
                <XAxis dataKey="name" stroke="#9e9e9e" fontSize={12} />
                <YAxis stroke="#9e9e9e" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1a2332',
                    border: '1px solid #2d3d50',
                    borderRadius: 8,
                    color: '#e0e0e0',
                  }}
                />
                <Bar dataKey="value" fill="#2196f3" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </Grid>
      </Grid>

      {/* 聚合/明细视图切换 */}
      <Card sx={{ backgroundColor: '#1a2332', p: 1.5, mb: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 1 }}>
          <ToggleButtonGroup
            value={aggregationViewMode}
            exclusive
            onChange={(_e, val) => {
              if (val !== null) setAggregationViewMode(val);
            }}
            size="small"
            sx={{
              '& .MuiToggleButton-root': {
                color: '#9e9e9e',
                borderColor: '#2d3d50',
                px: 2,
                fontSize: 12,
                '&.Mui-selected': {
                  color: '#2196f3',
                  backgroundColor: '#2196f315',
                  fontWeight: 600,
                },
              },
            }}
          >
            <ToggleButton value="aggregated">聚合视图</ToggleButton>
            <ToggleButton value="detail">明细视图</ToggleButton>
          </ToggleButtonGroup>

          {aggregationViewMode === 'aggregated' && (
            <FormControl size="small" sx={{ minWidth: 120 }}>
              <InputLabel sx={{ fontSize: 12 }}>时间窗口</InputLabel>
              <Select
                value={aggregationWindow}
                label="时间窗口"
                onChange={(e) => setAggregationWindow(e.target.value as TimeWindowMinutes)}
                sx={{ fontSize: 12 }}
              >
                <MenuItem value={5}>5 分钟</MenuItem>
                <MenuItem value={15}>15 分钟</MenuItem>
                <MenuItem value={30}>30 分钟</MenuItem>
                <MenuItem value={60}>60 分钟</MenuItem>
              </Select>
            </FormControl>
          )}
        </Box>
      </Card>

      {/* 聚合视图：告警时间线 */}
      {aggregationViewMode === 'aggregated' && (
        <Box sx={{ mb: 2 }}>
          <AlarmTimeline groups={aggregatedGroups} />
        </Box>
      )}

      {/* 明细视图：筛选工具栏 + 表格 */}
      {aggregationViewMode === 'detail' && (
        <>
          {/* 筛选工具栏 */}
          <Card sx={{ backgroundColor: '#1a2332', p: 2, mb: 2 }}>
            <Grid container spacing={1.5} alignItems="center">
              <Grid item xs={12} md={2.5}>
                <TextField
                  size="small"
                  placeholder="搜索告警/网元/单板..."
                  value={searchText}
                  onChange={(e) => setSearchText(e.target.value)}
                  fullWidth
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon sx={{ color: '#9e9e9e', fontSize: 18 }} />
                      </InputAdornment>
                    ),
                  }}
                />
              </Grid>
              <Grid item xs={6} md={1.8}>
                <FormControl size="small" fullWidth>
                  <InputLabel>告警级别</InputLabel>
                  <Select value={levelFilter} label="告警级别" onChange={(e) => setLevelFilter(e.target.value)}>
                    <MenuItem value="全部">全部</MenuItem>
                    <MenuItem value="紧急">紧急</MenuItem>
                    <MenuItem value="主要">主要</MenuItem>
                    <MenuItem value="次要">次要</MenuItem>
                    <MenuItem value="提示">提示</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={6} md={1.8}>
                <FormControl size="small" fullWidth>
                  <InputLabel>告警类型</InputLabel>
                  <Select value={typeFilter} label="告警类型" onChange={(e) => setTypeFilter(e.target.value)}>
                    <MenuItem value="全部">全部</MenuItem>
                    <MenuItem value="通信告警">通信告警</MenuItem>
                    <MenuItem value="设备告警">设备告警</MenuItem>
                    <MenuItem value="处理错误告警">处理错误告警</MenuItem>
                    <MenuItem value="环境告警">环境告警</MenuItem>
                    <MenuItem value="服务质量告警">服务质量告警</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={6} md={1.8}>
                <FormControl size="small" fullWidth>
                  <InputLabel>告警状态</InputLabel>
                  <Select value={statusFilter} label="告警状态" onChange={(e) => setStatusFilter(e.target.value)}>
                    <MenuItem value="全部">全部</MenuItem>
                    <MenuItem value="未确认未清除">未确认未清除</MenuItem>
                    <MenuItem value="已确认未清除">已确认未清除</MenuItem>
                    <MenuItem value="已确认已清除">已确认已清除</MenuItem>
                    <MenuItem value="未确认">未确认</MenuItem>
                    <MenuItem value="自动确认">自动确认</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={6} md={1.8}>
                <FormControl size="small" fullWidth>
                  <InputLabel>网元</InputLabel>
                  <Select value={neFilter} label="网元" onChange={(e) => setNeFilter(e.target.value)}>
                    {neNames.slice(0, 30).map((name) => (
                      <MenuItem key={name} value={name}>
                        {name === '全部' ? '全部' : name.split('-').slice(2).join('-')}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={6} md={1.2}>
                <TextField
                  size="small"
                  type="date"
                  label="开始日期"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                />
              </Grid>
              <Grid item xs={6} md={1.2}>
                <TextField
                  size="small"
                  type="date"
                  label="结束日期"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                />
              </Grid>
              <Grid item xs={12} md={0.5}>
                <Button size="small" onClick={handleResetFilters} sx={{ color: '#9e9e9e', fontSize: 12 }}>
                  重置
                </Button>
              </Grid>
            </Grid>
            <Typography variant="caption" sx={{ color: '#9e9e9e', mt: 1, display: 'block' }}>
              共 {filteredAlarms.length} 条告警
            </Typography>
          </Card>

          {/* 告警列表表格 */}
          <Card sx={{ backgroundColor: '#1a2332' }}>
            <TableContainer sx={{ maxHeight: 500 }}>
              <Table stickyHeader size="small">
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ width: 50 }}>
                      <TableSortLabel
                        active={orderBy === 'alarmNo'}
                        direction={orderBy === 'alarmNo' ? order : 'desc'}
                        onClick={() => handleSort('alarmNo')}
                      >
                        序号
                      </TableSortLabel>
                    </TableCell>
                    <TableCell sx={{ width: 80 }}>
                      <TableSortLabel
                        active={orderBy === 'alarmLevel'}
                        direction={orderBy === 'alarmLevel' ? order : 'desc'}
                        onClick={() => handleSort('alarmLevel')}
                      >
                        级别
                      </TableSortLabel>
                    </TableCell>
                    <TableCell>告警标题</TableCell>
                    <TableCell>告警名称</TableCell>
                    <TableCell>网元名称</TableCell>
                    <TableCell>省份</TableCell>
                    <TableCell>槽位/盘/端口</TableCell>
                    <TableCell>告警类型</TableCell>
                    <TableCell sx={{ width: 120 }}>
                      <TableSortLabel
                        active={orderBy === 'alarmStatus'}
                        direction={orderBy === 'alarmStatus' ? order : 'desc'}
                        onClick={() => handleSort('alarmStatus')}
                      >
                        告警状态
                      </TableSortLabel>
                    </TableCell>
                    <TableCell sx={{ width: 150 }}>
                      <TableSortLabel
                        active={orderBy === 'firstOccurTime'}
                        direction={orderBy === 'firstOccurTime' ? order : 'desc'}
                        onClick={() => handleSort('firstOccurTime')}
                      >
                        首次发生时间
                      </TableSortLabel>
                    </TableCell>
                    <TableCell sx={{ width: 80 }}>持续时长</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {pagedAlarms.map((alarm) => (
                    <TableRow
                      key={alarm.id}
                      hover
                      onClick={() => setSelectedAlarm(alarm)}
                      sx={{
                        cursor: 'pointer',
                        '&:hover': { backgroundColor: '#243447 !important' },
                        borderLeft: `3px solid ${ALARM_LEVEL_COLORS[alarm.alarmLevel]}`,
                      }}
                    >
                      <TableCell>{alarm.alarmNo}</TableCell>
                      <TableCell>
                        <Chip
                          label={alarm.alarmLevel}
                          size="small"
                          sx={{
                            backgroundColor: `${ALARM_LEVEL_COLORS[alarm.alarmLevel]}22`,
                            color: ALARM_LEVEL_COLORS[alarm.alarmLevel],
                            fontWeight: 600,
                            fontSize: 11,
                            height: 20,
                            minWidth: 48,
                          }}
                        />
                      </TableCell>
                      <TableCell sx={{ fontSize: 13 }}>{alarm.alarmTitle}</TableCell>
                      <TableCell sx={{ fontSize: 13, color: '#9e9e9e' }}>{alarm.alarmName}</TableCell>
                      <TableCell sx={{ fontSize: 12, maxWidth: 180 }} title={alarm.neName}>
                        <Typography variant="body2" noWrap sx={{ fontSize: 12 }}>
                          {alarm.neName.split('-').slice(2).join('-')}
                        </Typography>
                      </TableCell>
                      <TableCell sx={{ fontSize: 12, color: '#90caf9' }}>
                        {alarm.province || '未知'}
                      </TableCell>
                      <TableCell sx={{ fontSize: 12 }}>
                        {alarm.slotNo}/{alarm.boardName}/{alarm.portNo || '-'}
                      </TableCell>
                      <TableCell sx={{ fontSize: 12, color: '#9e9e9e' }}>{alarm.alarmType}</TableCell>
                      <TableCell>
                        <Chip
                          label={alarm.alarmStatus}
                          size="small"
                          variant="outlined"
                          sx={{
                            fontSize: 10,
                            height: 18,
                            color:
                              alarm.alarmStatus === '未确认未清除' || alarm.alarmStatus === '未确认'
                                ? '#f44336'
                                : alarm.alarmStatus === '已确认未清除'
                                  ? '#ff9800'
                                  : '#4caf50',
                            borderColor:
                              alarm.alarmStatus === '未确认未清除' || alarm.alarmStatus === '未确认'
                                ? '#f44336'
                                : alarm.alarmStatus === '已确认未清除'
                                  ? '#ff9800'
                                  : '#4caf50',
                          }}
                        />
                      </TableCell>
                      <TableCell sx={{ fontSize: 12 }}>
                        {dayjs(alarm.firstOccurTime).format('YYYY-MM-DD HH:mm')}
                      </TableCell>
                      <TableCell sx={{ fontSize: 12, color: '#9e9e9e' }}>{alarm.duration}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            <TablePagination
              rowsPerPageOptions={[5, 10, 25, 50]}
              component="div"
              count={filteredAlarms.length}
              rowsPerPage={rowsPerPage}
              page={page}
              onPageChange={(_, newPage) => setPage(newPage)}
              onRowsPerPageChange={(e) => {
                setRowsPerPage(parseInt(e.target.value, 10));
                setPage(0);
              }}
              sx={{ color: '#9e9e9e', borderTop: '1px solid #2d3d50' }}
            />
          </Card>
        </>
      )}

      {/* 告警详情弹窗 */}
      <Dialog
        open={!!selectedAlarm}
        onClose={() => setSelectedAlarm(null)}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          sx: { backgroundColor: '#1a2332', border: '1px solid #2d3d50' },
        }}
      >
        <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
            告警详情
          </Typography>
          <IconButton onClick={() => setSelectedAlarm(null)} size="small">
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent>
          {selectedAlarm && (
            <Box>
              <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
                <Chip
                  label={selectedAlarm.alarmLevel}
                  sx={{
                    backgroundColor: `${ALARM_LEVEL_COLORS[selectedAlarm.alarmLevel]}22`,
                    color: ALARM_LEVEL_COLORS[selectedAlarm.alarmLevel],
                    fontWeight: 600,
                  }}
                />
                <Chip label={selectedAlarm.alarmType} variant="outlined" sx={{ color: '#9e9e9e' }} />
                <Chip
                  label={selectedAlarm.alarmStatus}
                  variant="outlined"
                  sx={{ color: '#9e9e9e' }}
                />
              </Box>

              {[
                ['告警标题', selectedAlarm.alarmTitle],
                ['告警名称', selectedAlarm.alarmName],
                ['网元名称', selectedAlarm.neName],
                ['所属省份', selectedAlarm.province || '未知'],
                ['网元IP', selectedAlarm.neIp],
                ['槽位号', selectedAlarm.slotNo],
                ['盘名称', selectedAlarm.boardName],
                ['端口号', selectedAlarm.portNo || '-'],
                ['首次发生时间', selectedAlarm.firstOccurTime],
                ['最近发生时间', selectedAlarm.lastOccurTime],
                ['告警清除时间', selectedAlarm.clearTime || '-'],
                ['告警持续时长', selectedAlarm.duration],
                ['确认操作者', selectedAlarm.confirmOperator || '-'],
                ['确认时间', selectedAlarm.confirmTime || '-'],
                ['清除操作者', selectedAlarm.clearOperator || '-'],
                ['附加信息', selectedAlarm.additionalInfo || '-'],
                ['告警源', selectedAlarm.alarmSource],
              ].map(([label, value]) => (
                <Box key={label} sx={{ display: 'flex', py: 0.5, borderBottom: '1px solid #2d3d5033' }}>
                  <Typography variant="body2" sx={{ color: '#9e9e9e', width: 120, flexShrink: 0 }}>
                    {label}
                  </Typography>
                  <Typography variant="body2" sx={{ flex: 1 }}>{value}</Typography>
                </Box>
              ))}
            </Box>
          )}
        </DialogContent>
      </Dialog>
    </Box>
  );
};

export default AlarmAnalysis;
