import React, { useMemo } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  Chip,
  List,
  ListItem,
  ListItemText,
  Divider,
  LinearProgress,
} from '@mui/material';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  AreaChart,
  Area,
} from 'recharts';
import WarningIcon from '@mui/icons-material/Warning';
import ErrorIcon from '@mui/icons-material/Error';
import InfoIcon from '@mui/icons-material/Info';
import ReportProblemIcon from '@mui/icons-material/ReportProblem';
import useAppStore from '../store/useAppStore';
import type { AlarmLevel } from '../types';
import { ALARM_LEVEL_COLORS, ALARM_LEVEL_ORDER } from '../types';
import AlarmStormCard from '../components/AlarmStormCard';
import dayjs from 'dayjs';

/** 告警级别统计卡片组件 */
const AlarmStatCard: React.FC<{
  level: AlarmLevel;
  count: number;
  icon: React.ReactNode;
  trend: string;
}> = ({ level, count, icon, trend }) => {
  const color = ALARM_LEVEL_COLORS[level];
  return (
    <Card
      sx={{
        backgroundColor: '#1a2332',
        border: `1px solid ${color}33`,
        borderRadius: 2,
        height: '100%',
        transition: 'transform 0.2s, box-shadow 0.2s',
        '&:hover': {
          transform: 'translateY(-2px)',
          boxShadow: `0 4px 20px ${color}22`,
        },
      }}
    >
      <CardContent sx={{ p: 2.5 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <Box>
            <Typography variant="body2" sx={{ color: '#9e9e9e', mb: 0.5 }}>
              {level}告警
            </Typography>
            <Typography variant="h4" sx={{ color, fontWeight: 700 }}>
              {count}
            </Typography>
          </Box>
          <Box
            sx={{
              width: 48,
              height: 48,
              borderRadius: 2,
              backgroundColor: `${color}15`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color,
            }}
          >
            {icon}
          </Box>
        </Box>
        <Typography variant="caption" sx={{ color: '#9e9e9e', mt: 1, display: 'block' }}>
          {trend}
        </Typography>
      </CardContent>
    </Card>
  );
};

/** 单次遍历统计结果的类型 */
interface DashboardStats {
  levelCounts: Record<string, number>;
  typeStats: { name: string; value: number }[];
  trendData: { date: string; 紧急: number; 主要: number; 次要: number; 提示: number }[];
  recentAlarms: import('../types').AlarmRecord[];
  neHealthRanking: { name: string; count: number; critical: number }[];
  provinceStats: [string, { total: number; critical: number; major: number; minor: number; info: number }][];
  unresolvedCount: number;
}

/** 仪表盘页面 */
const Dashboard: React.FC = () => {
  const { alarms, networkElements } = useAppStore();

  /** 单次遍历计算所有统计数据 */
  const stats: DashboardStats = useMemo(() => {
    // 级别统计
    const levelCounts: Record<string, number> = { '紧急': 0, '主要': 0, '次要': 0, '提示': 0 };

    // 类型统计
    const typeCounts: Record<string, number> = {};

    // 按日趋势
    const dayMap: Record<string, { date: string; 紧急: number; 主要: number; 次要: number; 提示: number }> = {};

    // 网元健康度
    const neAlarmCounts: Record<string, { name: string; count: number; critical: number }> = {};

    // 省份统计
    const provMap: Record<string, { total: number; critical: number; major: number; minor: number; info: number }> = {};

    // 未解决告警计数
    let unresolvedCount = 0;

    // 最近告警 Top 10（用固定大小列表避免全量排序）
    const recent: import('../types').AlarmRecord[] = [];

    for (let i = 0; i < alarms.length; i++) {
      const a = alarms[i];

      // 1. 级别统计
      levelCounts[a.alarmLevel] = (levelCounts[a.alarmLevel] || 0) + 1;

      // 2. 类型统计
      typeCounts[a.alarmType] = (typeCounts[a.alarmType] || 0) + 1;

      // 3. 按日趋势
      const day = dayjs(a.firstOccurTime).format('MM-DD');
      if (!dayMap[day]) {
        dayMap[day] = { date: day, '紧急': 0, '主要': 0, '次要': 0, '提示': 0 };
      }
      dayMap[day][a.alarmLevel] += 1;

      // 4. 网元健康度
      if (!neAlarmCounts[a.neName]) {
        neAlarmCounts[a.neName] = { name: a.neName, count: 0, critical: 0 };
      }
      neAlarmCounts[a.neName].count += 1;
      if (a.alarmLevel === '紧急') {
        neAlarmCounts[a.neName].critical += 1;
      }

      // 5. 省份统计
      const p = a.province || '未知';
      if (!provMap[p]) {
        provMap[p] = { total: 0, critical: 0, major: 0, minor: 0, info: 0 };
      }
      provMap[p].total++;
      if (a.alarmLevel === '紧急') provMap[p].critical++;
      else if (a.alarmLevel === '主要') provMap[p].major++;
      else if (a.alarmLevel === '次要') provMap[p].minor++;
      else provMap[p].info++;

      // 6. 未解决告警计数
      if (a.alarmStatus !== '已确认已清除') {
        unresolvedCount++;
      }

      // 7. 最近告警 Top 10（无需全量排序，维护一个最多10项的列表）
      recent.push(a);
      if (recent.length > 10) {
        let oldestIdx = 0;
        for (let j = 1; j < recent.length; j++) {
          if (recent[j].firstOccurTime < recent[oldestIdx].firstOccurTime) {
            oldestIdx = j;
          }
        }
        recent.splice(oldestIdx, 1);
      }
    }

    // 最近告警降序排列（最多10项，排序成本可忽略）
    recent.sort((a, b) => b.firstOccurTime.localeCompare(a.firstOccurTime));

    // 整理类型分布
    const typeStats = Object.entries(typeCounts).map(([name, value]) => ({ name, value }));

    // 趋势数据按日期排序
    const trendData = Object.values(dayMap).sort((a, b) => a.date.localeCompare(b.date));

    // 网元健康度排名（仅对网元条目排序，条目数远小于告警数）
    const neHealthRanking = Object.values(neAlarmCounts)
      .sort((a, b) => {
        if (b.critical !== a.critical) return b.critical - a.critical;
        return b.count - a.count;
      })
      .slice(0, 8);

    // 省份统计排序
    const provinceStats = Object.entries(provMap).sort((a, b) => b[1].total - a[1].total);

    return {
      levelCounts,
      typeStats,
      trendData,
      recentAlarms: recent,
      neHealthRanking,
      provinceStats,
      unresolvedCount,
    };
  }, [alarms]);

  const totalAlarms = alarms.length;
  const onlineNEs = networkElements.filter((ne) => ne.onlineStatus === '在线').length;

  const PIE_COLORS = ['#f44336', '#ff9800', '#ffc107', '#2196f3', '#4caf50'];

  return (
    <Box>
      {/* 顶部概览统计 */}
      <Grid container spacing={2} sx={{ mb: 2 }}>
        <Grid item xs={12} md={3}>
          <AlarmStatCard
            level="紧急"
            count={stats.levelCounts['紧急']}
            icon={<ErrorIcon />}
            trend={stats.levelCounts['紧急'] > 0 ? '需要立即处理' : '暂无紧急告警'}
          />
        </Grid>
        <Grid item xs={12} md={3}>
          <AlarmStatCard
            level="主要"
            count={stats.levelCounts['主要']}
            icon={<ReportProblemIcon />}
            trend={stats.levelCounts['主要'] > 0 ? '建议尽快处理' : '暂无主要告警'}
          />
        </Grid>
        <Grid item xs={12} md={3}>
          <AlarmStatCard
            level="次要"
            count={stats.levelCounts['次要']}
            icon={<WarningIcon />}
            trend={stats.levelCounts['次要'] > 0 ? '可安排处理' : '暂无次要告警'}
          />
        </Grid>
        <Grid item xs={12} md={3}>
          <AlarmStatCard
            level="提示"
            count={stats.levelCounts['提示']}
            icon={<InfoIcon />}
            trend={stats.levelCounts['提示'] > 0 ? '建议关注' : '暂无提示告警'}
          />
        </Grid>
      </Grid>

      {/* 概览数据条 */}
      <Grid container spacing={2} sx={{ mb: 2 }}>
        <Grid item xs={12} md={4}>
          <Card sx={{ backgroundColor: '#1a2332', p: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Typography variant="body2" sx={{ color: '#9e9e9e' }}>告警总数</Typography>
              <Typography variant="h5" sx={{ fontWeight: 700 }}>{totalAlarms}</Typography>
            </Box>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={{ backgroundColor: '#1a2332', p: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Typography variant="body2" sx={{ color: '#9e9e9e' }}>未解决告警</Typography>
              <Typography variant="h5" sx={{ fontWeight: 700, color: '#f44336' }}>{stats.unresolvedCount}</Typography>
            </Box>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={{ backgroundColor: '#1a2332', p: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Typography variant="body2" sx={{ color: '#9e9e9e' }}>在线网元</Typography>
              <Typography variant="h5" sx={{ fontWeight: 700, color: '#4caf50' }}>
                {onlineNEs}/{networkElements.length}
              </Typography>
            </Box>
          </Card>
        </Grid>
      </Grid>

      {/* 图表区域 */}
      <Grid container spacing={2} sx={{ mb: 2 }}>
        {/* 告警趋势时间线图 */}
        <Grid item xs={12} md={8}>
          <Card sx={{ backgroundColor: '#1a2332', p: 2, height: 380 }}>
            <Typography variant="subtitle1" sx={{ mb: 2, fontWeight: 600 }}>
              告警趋势（按日）
            </Typography>
            <ResponsiveContainer width="100%" height={310}>
              <AreaChart data={stats.trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2d3d50" />
                <XAxis dataKey="date" stroke="#9e9e9e" fontSize={12} />
                <YAxis stroke="#9e9e9e" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1a2332',
                    border: '1px solid #2d3d50',
                    borderRadius: 8,
                    color: '#e0e0e0',
                  }}
                />
                <Legend />
                <Area type="monotone" dataKey="紧急" stackId="1" stroke="#f44336" fill="#f4433633" />
                <Area type="monotone" dataKey="主要" stackId="1" stroke="#ff9800" fill="#ff980033" />
                <Area type="monotone" dataKey="次要" stackId="1" stroke="#ffc107" fill="#ffc10733" />
                <Area type="monotone" dataKey="提示" stackId="1" stroke="#2196f3" fill="#2196f333" />
              </AreaChart>
            </ResponsiveContainer>
          </Card>
        </Grid>

        {/* 告警类型分布饼图 */}
        <Grid item xs={12} md={4}>
          <Card sx={{ backgroundColor: '#1a2332', p: 2, height: 380 }}>
            <Typography variant="subtitle1" sx={{ mb: 2, fontWeight: 600 }}>
              告警类型分布
            </Typography>
            <ResponsiveContainer width="100%" height={310}>
              <PieChart>
                <Pie
                  data={stats.typeStats}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={3}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {stats.typeStats.map((_entry, index) => (
                    <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1a2332',
                    border: '1px solid #2d3d50',
                    borderRadius: 8,
                    color: '#e0e0e0',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </Grid>
      </Grid>

      {/* 告警风暴 Top10 */}
      <Grid container spacing={2} sx={{ mb: 2 }}>
        <Grid item xs={12}>
          <AlarmStormCard />
        </Grid>
      </Grid>

      {/* 列表区域 */}
      <Grid container spacing={2}>
        {/* 最近告警列表 */}
        <Grid item xs={12} md={6}>
          <Card sx={{ backgroundColor: '#1a2332', p: 2, height: 400, overflow: 'auto' }}>
            <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 600 }}>
              最近告警（Top 10）
            </Typography>
            <List dense>
              {stats.recentAlarms.map((alarm, index) => (
                <React.Fragment key={alarm.id}>
                  <ListItem sx={{ px: 0, py: 0.5 }}>
                    <Chip
                      label={alarm.alarmLevel}
                      size="small"
                      sx={{
                        mr: 1.5,
                        backgroundColor: `${ALARM_LEVEL_COLORS[alarm.alarmLevel]}22`,
                        color: ALARM_LEVEL_COLORS[alarm.alarmLevel],
                        fontWeight: 600,
                        fontSize: 11,
                        minWidth: 48,
                      }}
                    />
                    <ListItemText
                      primary={alarm.alarmTitle}
                      secondary={`${alarm.neName.split('-').slice(2).join('-')} | ${dayjs(alarm.firstOccurTime).format('MM-DD HH:mm')}`}
                      primaryTypographyProps={{ fontSize: 13, noWrap: true }}
                      secondaryTypographyProps={{ fontSize: 11, color: '#9e9e9e', noWrap: true }}
                    />
                  </ListItem>
                  {index < stats.recentAlarms.length - 1 && <Divider sx={{ borderColor: '#2d3d5033' }} />}
                </React.Fragment>
              ))}
            </List>
          </Card>
        </Grid>

        {/* 网元健康度排名 */}
        <Grid item xs={12} md={6}>
          <Card sx={{ backgroundColor: '#1a2332', p: 2, height: 400, overflow: 'auto' }}>
            <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 600 }}>
              网元健康度排名（告警数）
            </Typography>
            <List dense>
              {stats.neHealthRanking.map((ne, index) => {
                const healthPercent = Math.max(0, 100 - ne.count * 10);
                const barColor = ne.critical > 0
                  ? '#f44336'
                  : ne.count > 3
                    ? '#ff9800'
                    : '#4caf50';
                return (
                  <React.Fragment key={ne.name}>
                    <ListItem sx={{ px: 0, py: 0.5 }}>
                      <ListItemText
                        primary={
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Typography variant="body2" sx={{ fontWeight: 600, minWidth: 20 }}>
                              {index + 1}
                            </Typography>
                            <Typography variant="body2" noWrap sx={{ flex: 1, fontSize: 13 }}>
                              {ne.name.split('-').slice(2).join('-')}
                            </Typography>
                            <Chip
                              label={`${ne.count}条`}
                              size="small"
                              sx={{
                                backgroundColor: `${barColor}22`,
                                color: barColor,
                                fontWeight: 600,
                                fontSize: 11,
                              }}
                            />
                            {ne.critical > 0 && (
                              <Chip
                                label={`${ne.critical}紧急`}
                                size="small"
                                color="error"
                                variant="outlined"
                                sx={{ fontSize: 11, height: 20 }}
                              />
                            )}
                          </Box>
                        }
                        secondary={
                          <LinearProgress
                            variant="determinate"
                            value={healthPercent}
                            sx={{
                              mt: 0.5,
                              height: 4,
                              borderRadius: 2,
                              backgroundColor: '#2d3d50',
                              '& .MuiLinearProgress-bar': {
                                backgroundColor: barColor,
                                borderRadius: 2,
                              },
                            }}
                          />
                        }
                        primaryTypographyProps={{ component: 'div' }}
                        secondaryTypographyProps={{ component: 'div' }}
                      />
                    </ListItem>
                    {index < stats.neHealthRanking.length - 1 && <Divider sx={{ borderColor: '#2d3d5033' }} />}
                  </React.Fragment>
                );
              })}
            </List>
          </Card>
        </Grid>

        {/* 省份告警统计 */}
        <Grid item xs={12} md={6}>
          <Card sx={{ backgroundColor: '#1a2332', p: 2, height: 400, overflow: 'auto' }}>
            <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 600 }}>
              各省份历史告警统计
            </Typography>
            <List dense>
              {stats.provinceStats.map(([prov, provStat], idx) => (
                <React.Fragment key={prov}>
                  <ListItem sx={{ py: 0.3, px: 1 }}>
                    <ListItemText
                      primary={
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Typography variant="body2" sx={{ fontWeight: 600, minWidth: 20 }}>
                            {idx + 1}
                          </Typography>
                          <Typography variant="body2" noWrap sx={{ flex: 1, fontSize: 13 }}>
                            {prov}
                          </Typography>
                          <Chip label={`${provStat.total}条`} size="small" sx={{ backgroundColor: '#2d3d5044', color: '#b0bec5', fontWeight: 600, fontSize: 11 }} />
                          {provStat.critical > 0 && <Chip label={`${provStat.critical}紧急`} size="small" color="error" variant="outlined" sx={{ fontSize: 11, height: 20 }} />}
                          {provStat.major > 0 && <Chip label={`${provStat.major}主要`} size="small" sx={{ backgroundColor: '#ff980022', color: '#ff9800', fontSize: 11, height: 20 }} />}
                        </Box>
                      }
                      secondary={
                        <Box sx={{ display: 'flex', gap: 0.5, mt: 0.5, height: 6, borderRadius: 3, overflow: 'hidden', backgroundColor: '#2d3d50' }}>
                          {provStat.critical > 0 && <Box sx={{ flex: provStat.critical, backgroundColor: '#f44336', borderRadius: 3 }} />}
                          {provStat.major > 0 && <Box sx={{ flex: provStat.major, backgroundColor: '#ff9800', borderRadius: 3 }} />}
                          {provStat.minor > 0 && <Box sx={{ flex: provStat.minor, backgroundColor: '#ffc107', borderRadius: 3 }} />}
                          {provStat.info > 0 && <Box sx={{ flex: provStat.info, backgroundColor: '#2196f3', borderRadius: 3 }} />}
                        </Box>
                      }
                      primaryTypographyProps={{ component: 'div' }}
                      secondaryTypographyProps={{ component: 'div' }}
                    />
                  </ListItem>
                  {idx < stats.provinceStats.length - 1 && <Divider sx={{ borderColor: '#2d3d5033' }} />}
                </React.Fragment>
              ))}
            </List>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;
