import React, { useMemo, useState, useCallback } from 'react';
import {
  ReactFlow,
  Controls,
  MiniMap,
  Background,
  useNodesState,
  useEdgesState,
  type Node,
  type Edge,
  Handle,
  Position,
  type NodeProps,
  BackgroundVariant,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import {
  Box,
  Card,
  Typography,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Divider,
  Tooltip,
  Button,
  Breadcrumbs,
  Link,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import CloseIcon from '@mui/icons-material/Close';
import useAppStore from '../store/useAppStore';
import type { AlarmLevel, NeType } from '../types';
import { ALARM_LEVEL_COLORS } from '../types';
import { mockTopologyLinks } from '../data/mockData';

// ──────────── 工具函数 ────────────

/** 网元节点最高告警级别 */
function getNeHighestAlarm(
  neName: string,
  alarms: { neName: string; alarmLevel: AlarmLevel; alarmStatus: string }[]
): AlarmLevel | null {
  const levelOrder: Record<AlarmLevel, number> = { 紧急: 4, 主要: 3, 次要: 2, 提示: 1 };
  const neAlarms = alarms.filter((a) => a.neName === neName && a.alarmStatus !== '已确认已清除');
  if (neAlarms.length === 0) return null;
  return neAlarms.reduce<AlarmLevel>((highest, a) => {
    return levelOrder[a.alarmLevel] > levelOrder[highest] ? a.alarmLevel : highest;
  }, neAlarms[0].alarmLevel);
}

/** 网元节点颜色 */
function getNeColor(highestLevel: AlarmLevel | null): string {
  if (!highestLevel) return '#4caf50';
  return ALARM_LEVEL_COLORS[highestLevel];
}

/** 网元类型图标映射 */
function getNeTypeLabel(neType: NeType): string {
  switch (neType) {
    case 'FONST 6000 N32': return 'EXC';
    case 'FONST COTP_POTN': return 'OTM';
    case 'FONST COTP M': return 'OA';
    default: return neType;
  }
}

/** 告警统计 */
interface ProvinceAlarmStats {
  total: number;
  urgent: number;
  major: number;
  minor: number;
  info: number;
  highestLevel: AlarmLevel | null;
}

/** 聚合省份告警统计 */
function getProvinceAlarmStats(
  province: string,
  alarms: { neName: string; alarmLevel: AlarmLevel; alarmStatus: string; province: string }[]
): ProvinceAlarmStats {
  // 通过 province 字段匹配（告警数据中有省份信息）
  // 支持格式：云南省 / 云南省(YN) / 新疆维吾尔自治区 / 新疆维吾尔自治区(XJ)
  const provinceAlarms = alarms.filter((a) => {
    const ap = a.province || '';
    if (!ap) return false;
    // 完全匹配
    if (ap === province) return true;
    // 前缀匹配（云南省(YN) startsWith 云南省）
    if (ap.startsWith(province) || province.startsWith(ap)) return true;
    // 去掉代码后的核心名匹配
    const apCore = ap.replace(/\([A-Z]+\)$/, '');
    const provCore = province.replace(/\([A-Z]+\)$/, '');
    if (apCore === provCore) return true;
    // 关键字匹配：提取省份核心名（去掉"省"、"市"、"自治区"等后缀）
    const stripSuffix = (s: string) => s.replace(/\([A-Z]+\)$/, '').replace(/(省|市|壮族自治区|回族自治区|维吾尔自治区|自治区)$/, '');
    if (stripSuffix(ap) === stripSuffix(province)) return true;
    return false;
  });
  const activeAlarms = provinceAlarms.filter((a) => a.alarmStatus !== '已确认已清除');

  const stats: ProvinceAlarmStats = { total: activeAlarms.length, urgent: 0, major: 0, minor: 0, info: 0, highestLevel: null };
  const levelOrder: Record<AlarmLevel, number> = { 紧急: 4, 主要: 3, 次要: 2, 提示: 1 };

  for (const a of activeAlarms) {
    switch (a.alarmLevel) {
      case '紧急': stats.urgent++; break;
      case '主要': stats.major++; break;
      case '次要': stats.minor++; break;
      case '提示': stats.info++; break;
    }
    if (!stats.highestLevel || levelOrder[a.alarmLevel] > levelOrder[stats.highestLevel]) {
      stats.highestLevel = a.alarmLevel;
    }
  }
  return stats;
}

/** 省份最高告警级别 → 边框颜色 */
function getProvinceBorderColor(stats: ProvinceAlarmStats): string {
  return getNeColor(stats.highestLevel);
}

// ──────────── 省份坐标布局 ────────────

/** 全国 34 个省级行政区坐标布局
 *  坐标系：从左到右=从西到东，从上到下=从北到南
 *  东北 → 华北 → 华东 → 华中 → 华南 → 西南 → 西北 → 港澳台
 */
const PROVINCE_COORDS: Record<string, { x: number; y: number }> = {
  // ── 东北 ──
  '黑龙江省(HL)':       { x: 1300, y: 100 },
  '吉林省(JL)':         { x: 1270, y: 180 },
  '辽宁省(LN)':         { x: 1240, y: 260 },
  '黑龙江省':           { x: 1300, y: 100 },
  '吉林省':             { x: 1270, y: 180 },
  '辽宁省':             { x: 1240, y: 260 },
  // ── 华北 ──
  '北京市(BJ)':         { x: 1150, y: 220 },
  '天津市(TJ)':         { x: 1180, y: 240 },
  '河北省(HE)':         { x: 1130, y: 260 },
  '山西省(SX)':         { x: 1080, y: 280 },
  '内蒙古自治区(NM)':   { x: 1020, y: 150 },
  '北京市':             { x: 1150, y: 220 },
  '天津市':             { x: 1180, y: 240 },
  '河北省':             { x: 1130, y: 260 },
  '山西省':             { x: 1080, y: 280 },
  '内蒙古自治区':       { x: 1020, y: 150 },
  // ── 华东 ──
  '山东省(SD)':         { x: 1180, y: 330 },
  '江苏省(JS)':         { x: 1220, y: 360 },
  '上海市(SH)':         { x: 1250, y: 370 },
  '浙江省(ZJ)':         { x: 1220, y: 420 },
  '安徽省(AH)':         { x: 1160, y: 390 },
  '福建省(FJ)':         { x: 1200, y: 480 },
  '江西省(JX)':         { x: 1140, y: 460 },
  '山东省':             { x: 1180, y: 330 },
  '江苏省':             { x: 1220, y: 360 },
  '上海市':             { x: 1250, y: 370 },
  '浙江省':             { x: 1220, y: 420 },
  '安徽省':             { x: 1160, y: 390 },
  '福建省':             { x: 1200, y: 480 },
  '江西省':             { x: 1140, y: 460 },
  // ── 华中 ──
  '河南省(HA)':         { x: 1100, y: 350 },
  '湖北省(HB)':         { x: 1070, y: 420 },
  '湖南省(HN)':         { x: 1070, y: 500 },
  '河南省':             { x: 1100, y: 350 },
  '湖北省':             { x: 1070, y: 420 },
  '湖南省':             { x: 1070, y: 500 },
  // ── 华南 ──
  '广东省(GD)':         { x: 1140, y: 560 },
  '广西壮族自治区(GX)': { x: 1050, y: 610 },
  '海南省(HI)':         { x: 1110, y: 650 },
  '广东省':             { x: 1140, y: 560 },
  '广西壮族自治区':     { x: 1050, y: 610 },
  '海南省':             { x: 1110, y: 650 },
  // ── 西南 ──
  '重庆市(CQ)':         { x: 1000, y: 470 },
  '四川省(SC)':         { x: 920,  y: 440 },
  '贵州省(GZ)':         { x: 980,  y: 550 },
  '云南省(YN)':         { x: 850,  y: 610 },
  '重庆市':             { x: 1000, y: 470 },
  '四川省':             { x: 920,  y: 440 },
  '贵州省':             { x: 980,  y: 550 },
  '云南省':             { x: 850,  y: 610 },
  // ── 西北 ──
  '陕西省(SN)':                 { x: 1000, y: 340 },
  '甘肃省(GS)':                 { x: 850,  y: 270 },
  '青海省(QH)':                 { x: 750,  y: 320 },
  '宁夏回族自治区(NX)':         { x: 920,  y: 280 },
  '新疆维吾尔自治区(XJ)':       { x: 400,  y: 190 },
  '陕西省':                     { x: 1000, y: 340 },
  '甘肃省':                     { x: 850,  y: 270 },
  '青海省':                     { x: 750,  y: 320 },
  '宁夏回族自治区':             { x: 920,  y: 280 },
  '新疆维吾尔自治区':           { x: 400,  y: 190 },
  // ── 港澳台 ──
  '香港特别行政区(HK)': { x: 1170, y: 580 },
  '澳门特别行政区(MC)': { x: 1150, y: 590 },
  '台湾省(TW)':         { x: 1250, y: 510 },
  '香港特别行政区':     { x: 1170, y: 580 },
  '澳门特别行政区':     { x: 1150, y: 590 },
  '台湾省':             { x: 1250, y: 510 },
};

/** 获取省份坐标（支持多种名称格式） */
function getProvinceCoord(province: string): { x: number; y: number } {
  if (PROVINCE_COORDS[province]) return PROVINCE_COORDS[province];
  // 尝试去掉括号中的代码部分匹配
  const shortName = province.replace(/\([A-Z]+\)$/, '');
  if (PROVINCE_COORDS[shortName]) return PROVINCE_COORDS[shortName];
  // 尝试带代码匹配
  const codeMatch = province.match(/([^\(]+)\(([A-Z]+)\)$/);
  if (codeMatch) {
    const withCode = `${codeMatch[1]}(${codeMatch[2]})`;
    if (PROVINCE_COORDS[withCode]) return PROVINCE_COORDS[withCode];
  }
  return { x: 800, y: 400 }; // 默认位置
}

/** 获取省份短显示名（去掉括号代码，用于UI显示） */
function getProvinceDisplayName(province: string): string {
  return province.replace(/\([A-Z]+\)$/, '');
}

/** 全国 34 个省级行政区（按地理解序：东北→华北→华东→华中→华南→西南→西北→港澳台） */
const ALL_PROVINCES = [
  // 东北
  '黑龙江省', '吉林省', '辽宁省',
  // 华北
  '北京市', '天津市', '河北省', '山西省', '内蒙古自治区',
  // 华东
  '山东省', '江苏省', '上海市', '浙江省', '安徽省', '福建省', '江西省',
  // 华中
  '河南省', '湖北省', '湖南省',
  // 华南
  '广东省', '广西壮族自治区', '海南省',
  // 西南
  '重庆市', '四川省', '贵州省', '云南省',
  // 西北
  '陕西省', '甘肃省', '青海省', '宁夏回族自治区', '新疆维吾尔自治区',
  // 港澳台
  '香港特别行政区', '澳门特别行政区', '台湾省',
];

/** 未知省份自动布局偏移 */
const AUTO_LAYOUT_POSITIONS = [
  { x: 850, y: 100 }, { x: 850, y: 250 }, { x: 850, y: 400 },
  { x: 850, y: 550 }, { x: 850, y: 700 },
  { x: 50, y: 400 }, { x: 50, y: 550 },
];

/** 省份内网元布局偏移 */
function getNeOffset(neType: NeType, index: number): { dx: number; dy: number } {
  switch (neType) {
    case 'FONST 6000 N32': return { dx: index * 180, dy: 0 };
    case 'FONST COTP_POTN': return { dx: index * 180, dy: 100 };
    case 'FONST COTP M': return { dx: index * 180, dy: 200 };
    default: return { dx: index * 180, dy: 0 };
  }
}

// ──────────── 自定义节点组件 ────────────

/** 省份节点组件（省级总览） */
const ProvinceNode: React.FC<NodeProps> = ({ data }) => {
  const d = data as {
    label: string;
    neCount: number;
    alarmStats: ProvinceAlarmStats;
    isActive: boolean;
  };

  // ── 不活跃节点（无网元数据）──
  if (!d.isActive) {
    return (
      <Box
        sx={{
          padding: '16px 24px',
          borderRadius: 3,
          backgroundColor: '#0f1a2a',
          border: '2px dashed #2d3d50',
          minWidth: 180,
          textAlign: 'center',
          opacity: 0.5,
          cursor: 'default',
          position: 'relative',
        }}
      >
        <Handle type="target" position={Position.Left} style={{ background: '#2d3d50', width: 8, height: 8 }} />
        <Handle type="source" position={Position.Right} style={{ background: '#2d3d50', width: 8, height: 8 }} />
        <Handle type="target" position={Position.Top} style={{ background: '#2d3d50', width: 8, height: 8 }} />
        <Handle type="source" position={Position.Bottom} style={{ background: '#2d3d50', width: 8, height: 8 }} />
        <Typography variant="subtitle1" sx={{ fontWeight: 700, color: '#555', fontSize: 16, mb: 0.5 }}>
          {d.label}
        </Typography>
        <Typography variant="caption" sx={{ color: '#444', fontSize: 11 }}>
          无网元数据
        </Typography>
      </Box>
    );
  }

  const borderColor = getProvinceBorderColor(d.alarmStats);
  const hasAlarm = d.alarmStats.total > 0;

  return (
    <Tooltip
      title={`${d.label} | ${d.neCount}个网元 | 告警:${d.alarmStats.total}`}
      arrow
      placement="top"
    >
      <Box
        sx={{
          padding: '16px 24px',
          borderRadius: 3,
          backgroundColor: '#1a2332',
          border: `3px solid ${borderColor}`,
          minWidth: 180,
          textAlign: 'center',
          position: 'relative',
          boxShadow: hasAlarm ? `0 0 20px ${borderColor}66` : '0 0 8px #3d506844',
          cursor: 'pointer',
          transition: 'all 0.2s',
          '&:hover': {
            boxShadow: hasAlarm ? `0 0 30px ${borderColor}88` : '0 0 16px #3d506888',
            transform: 'scale(1.05)',
          },
        }}
      >
        <Handle type="target" position={Position.Left} style={{ background: '#3d5068', width: 8, height: 8 }} />
        <Handle type="source" position={Position.Right} style={{ background: '#3d5068', width: 8, height: 8 }} />
        <Handle type="target" position={Position.Top} style={{ background: '#3d5068', width: 8, height: 8 }} />
        <Handle type="source" position={Position.Bottom} style={{ background: '#3d5068', width: 8, height: 8 }} />

        {/* 省份名 */}
        <Typography
          variant="subtitle1"
          sx={{ fontWeight: 700, color: '#e0e0e0', fontSize: 16, mb: 0.5 }}
        >
          {d.label}
        </Typography>

        {/* 网元数 */}
        <Typography variant="caption" sx={{ color: '#9e9e9e', fontSize: 11 }}>
          {d.neCount}个网元
        </Typography>

        {/* 告警统计条 */}
        {hasAlarm && (
          <Box sx={{ mt: 1, display: 'flex', justifyContent: 'center', gap: 0.5, flexWrap: 'wrap' }}>
            {d.alarmStats.urgent > 0 && (
              <Chip label={`紧急 ${d.alarmStats.urgent}`} size="small" sx={{ height: 18, fontSize: 9, backgroundColor: '#f4433622', color: '#f44336', fontWeight: 600 }} />
            )}
            {d.alarmStats.major > 0 && (
              <Chip label={`主要 ${d.alarmStats.major}`} size="small" sx={{ height: 18, fontSize: 9, backgroundColor: '#ff980022', color: '#ff9800', fontWeight: 600 }} />
            )}
            {d.alarmStats.minor > 0 && (
              <Chip label={`次要 ${d.alarmStats.minor}`} size="small" sx={{ height: 18, fontSize: 9, backgroundColor: '#ffc10722', color: '#ffc107', fontWeight: 600 }} />
            )}
            {d.alarmStats.info > 0 && (
              <Chip label={`提示 ${d.alarmStats.info}`} size="small" sx={{ height: 18, fontSize: 9, backgroundColor: '#2196f322', color: '#2196f3', fontWeight: 600 }} />
            )}
          </Box>
        )}

        {/* 总告警数 */}
        {hasAlarm && (
          <Typography variant="caption" sx={{ color: borderColor, fontSize: 12, fontWeight: 700, mt: 0.5, display: 'block' }}>
            共{d.alarmStats.total}条告警
          </Typography>
        )}

        {!hasAlarm && (
          <Typography variant="caption" sx={{ color: '#4caf50', fontSize: 11, mt: 0.5, display: 'block' }}>
            无活动告警
          </Typography>
        )}

        {/* 点击提示 */}
        <Typography variant="caption" sx={{ color: '#666', fontSize: 9, mt: 0.5, display: 'block' }}>
          点击查看详情 →
        </Typography>
      </Box>
    </Tooltip>
  );
};

/** 网元节点组件（省份详情） */
const NeNode: React.FC<NodeProps> = ({ data }) => {
  const nodeData = data as {
    label: string;
    neType: string;
    highestLevel: AlarmLevel | null;
    alarmCount: number;
    province: string;
    city: string;
    onlineStatus: string;
  };

  const color = getNeColor(nodeData.highestLevel);
  const isOffline = nodeData.onlineStatus === '离线';

  return (
    <Tooltip
      title={`${nodeData.label} | ${nodeData.province}${nodeData.city} | ${nodeData.neType} | 告警:${nodeData.alarmCount}`}
      arrow
      placement="top"
    >
      <Box
        sx={{
          padding: '8px 12px',
          borderRadius: 2,
          backgroundColor: '#1a2332',
          border: `2px solid ${color}`,
          minWidth: 120,
          textAlign: 'center',
          position: 'relative',
          boxShadow: `0 0 12px ${color}44`,
          opacity: isOffline ? 0.6 : 1,
          cursor: 'pointer',
        }}
      >
        <Handle type="target" position={Position.Left} style={{ background: '#3d5068', width: 6, height: 6 }} />
        <Handle type="source" position={Position.Right} style={{ background: '#3d5068', width: 6, height: 6 }} />
        <Handle type="target" position={Position.Top} style={{ background: '#3d5068', width: 6, height: 6 }} />
        <Handle type="source" position={Position.Bottom} style={{ background: '#3d5068', width: 6, height: 6 }} />

        {nodeData.highestLevel && (
          <Box sx={{ position: 'absolute', top: -6, right: -6, width: 12, height: 12, borderRadius: '50%', backgroundColor: color, border: '2px solid #1a2332' }} />
        )}

        <Chip
          label={nodeData.neType}
          size="small"
          sx={{ position: 'absolute', top: -10, left: 4, height: 16, fontSize: 10, fontWeight: 700, backgroundColor: `${color}22`, color }}
        />

        {isOffline && (
          <Chip label="离线" size="small" sx={{ position: 'absolute', bottom: -10, right: 4, height: 16, fontSize: 10, backgroundColor: '#f4433622', color: '#f44336' }} />
        )}

        <Typography variant="caption" sx={{ display: 'block', fontWeight: 600, color: '#e0e0e0', fontSize: 11, lineHeight: 1.2, mt: 0.5, maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {nodeData.label}
        </Typography>
        {nodeData.alarmCount > 0 && (
          <Typography variant="caption" sx={{ color, fontSize: 10, fontWeight: 600 }}>
            {nodeData.alarmCount}条告警
          </Typography>
        )}
      </Box>
    </Tooltip>
  );
};

/** 节点类型映射 */
const nodeTypes = { provinceNode: ProvinceNode, neNode: NeNode };

// ──────────── 主页面组件 ────────────

const Topology: React.FC = () => {
  const { networkElements, alarms } = useAppStore();
  const [selectedNe, setSelectedNe] = useState<string | null>(null);

  // 两级视图状态
  const [viewLevel, setViewLevel] = useState<'province' | 'detail'>('province');
  const [selectedProvince, setSelectedProvince] = useState<string | null>(null);

  /** 省份 → 网元映射 */
  const neByProvince = useMemo(() => {
    const map: Record<string, typeof networkElements> = {};
    for (const ne of networkElements) {
      const shortProvince = ne.province.replace(/\([A-Z]+\)$/, '');
      if (!map[shortProvince]) map[shortProvince] = [];
      map[shortProvince].push(ne);
    }
    return map;
  }, [networkElements]);

  // ──────────── 省级总览节点 ────────────

  const provinceNodes = useMemo((): Node[] => {
    return ALL_PROVINCES.map((province) => {
      const coord = getProvinceCoord(province);
      const neList = neByProvince[province] || [];
      const alarmStats = getProvinceAlarmStats(province, alarms);
      const isActive = neList.length > 0;

      return {
        id: `province-${province}`,
        type: 'provinceNode',
        position: coord,
        data: {
          label: getProvinceDisplayName(province),
          neCount: neList.length,
          alarmStats,
          isActive,
        },
      };
    });
  }, [neByProvince, alarms]);

  // ──────────── 省级总览边（省份间连纤） ────────────

  const provinceEdges = useMemo((): Edge[] => {
    // 从拓扑链路推导省份间连接关系
    const provinceLinkMap: Record<string, { count: number; systems: Set<string> }> = {};

    for (const link of mockTopologyLinks) {
      const sourceNe = networkElements.find((ne) => ne.id === link.source);
      const targetNe = networkElements.find((ne) => ne.id === link.target);
      if (!sourceNe || !targetNe) continue;

      // 仅跨省份的链路才在省级总览中显示
      if (sourceNe.province === targetNe.province) continue;

      const key = [sourceNe.province, targetNe.province].sort().join('⟷');
      if (!provinceLinkMap[key]) {
        provinceLinkMap[key] = { count: 0, systems: new Set() };
      }
      provinceLinkMap[key].count++;
      provinceLinkMap[key].systems.add(link.system);
    }

    return Object.entries(provinceLinkMap).map(([key, val], i) => {
      const [p1, p2] = key.split('⟷');
      // 规范化省份名（去掉代码后缀），与 provinceNodes 的 id 保持一致
      const p1Short = p1.replace(/\([A-Z]+\)$/, '');
      const p2Short = p2.replace(/\([A-Z]+\)$/, '');
      return {
        id: `province-edge-${i}`,
        source: `province-${p1Short}`,
        target: `province-${p2Short}`,
        label: `${val.count}条链路`,
        animated: true,
        style: { stroke: '#5c8aff', strokeWidth: 3 },
        labelStyle: { fill: '#9e9e9e', fontSize: 11, fontWeight: 600 },
        labelBgStyle: { fill: '#0a1929', fillOpacity: 0.9 },
        labelBgPadding: [6, 3] as [number, number],
        type: 'smoothstep',
      };
    });
  }, [networkElements]);

  // ──────────── 省份详情节点 ────────────

  const detailNodes = useMemo((): Node[] => {
    if (!selectedProvince) return [];
    const neList = neByProvince[selectedProvince] || [];

    const neCountByType: Record<string, number> = {};
    return neList.map((ne) => {
      if (!neCountByType[ne.neType]) neCountByType[ne.neType] = 0;
      const typeIndex = neCountByType[ne.neType];
      neCountByType[ne.neType]++;

      const base = getProvinceCoord(ne.province);
      const offset = getNeOffset(ne.neType, typeIndex);
      const highestLevel = getNeHighestAlarm(ne.neName, alarms);
      const alarmCount = alarms.filter((a) => a.neName === ne.neName && a.alarmStatus !== '已确认已清除').length;

      const shortName = ne.neName.split('-').slice(2).join('-');
      const typeLabel = getNeTypeLabel(ne.neType);

      return {
        id: ne.id,
        type: 'neNode',
        position: { x: base.x + offset.dx, y: base.y + offset.dy },
        data: {
          label: shortName,
          neType: typeLabel,
          highestLevel,
          alarmCount,
          province: ne.province,
          city: ne.city,
          onlineStatus: ne.onlineStatus,
        },
      };
    });
  }, [selectedProvince, neByProvince, alarms]);

  // ──────────── 省份详情边 ────────────

  const detailEdges = useMemo((): Edge[] => {
    if (!selectedProvince) return [];
    const neIds = new Set((neByProvince[selectedProvince] || []).map((ne) => ne.id));

    // 包含：省份内链路 + 跨省份链路（连接到省份边界节点）
    return mockTopologyLinks
      .filter((link) => {
        const srcIn = neIds.has(link.source);
        const tgtIn = neIds.has(link.target);
        // 至少一端在本省
        return srcIn || tgtIn;
      })
      .map((link) => {
        const srcIn = neIds.has(link.source);
        const tgtIn = neIds.has(link.target);
        const isCrossProvince = !(srcIn && tgtIn);

        return {
          id: link.id,
          source: link.source,
          target: link.target,
          label: link.label,
          animated: !isCrossProvince,
          style: isCrossProvince
            ? { stroke: '#ff9800', strokeWidth: 2, strokeDasharray: '8 4' }
            : { stroke: '#3d5068', strokeWidth: 2 },
          labelStyle: { fill: isCrossProvince ? '#ff9800' : '#9e9e9e', fontSize: 10 },
          labelBgStyle: { fill: '#0a1929', fillOpacity: 0.8 },
          type: 'smoothstep',
        };
      });
  }, [selectedProvince, neByProvince]);

  // ──────────── ReactFlow 状态 ────────────

  const [provNodes, , onProvNodesChange] = useNodesState(provinceNodes);
  const [provEdges, , onProvEdgesChange] = useEdgesState(provinceEdges);
  const [detNodes, , onDetNodesChange] = useNodesState(detailNodes);
  const [detEdges, , onDetEdgesChange] = useEdgesState(detailEdges);

  // ──────────── 点击事件 ────────────

  /** 省级总览 - 点击省份节点 → 下钻 */
  const onProvinceNodeClick = useCallback((_: React.MouseEvent, node: Node) => {
    const nodeData = node.data as { isActive?: boolean };
    if (!nodeData.isActive) return; // 不活跃节点不进行下钻
    const provinceName = node.id.replace('province-', '');
    setSelectedProvince(provinceName);
    setViewLevel('detail');
  }, []);

  /** 省份详情 - 点击网元节点 → 弹窗 */
  const onDetailNodeClick = useCallback((_: React.MouseEvent, node: Node) => {
    setSelectedNe(node.id);
  }, []);

  /** 返回省级总览 */
  const goBackToProvince = useCallback(() => {
    setViewLevel('province');
    setSelectedProvince(null);
    setSelectedNe(null);
  }, []);

  // ──────────── 选中网元的告警详情 ────────────

  const selectedNeAlarms = useMemo(() => {
    if (!selectedNe) return [];
    const ne = networkElements.find((n) => n.id === selectedNe);
    if (!ne) return [];
    return alarms.filter((a) => a.neName === ne.neName);
  }, [selectedNe, networkElements, alarms]);

  const selectedNeInfo = useMemo(() => {
    if (!selectedNe) return null;
    return networkElements.find((n) => n.id === selectedNe) || null;
  }, [selectedNe, networkElements]);

  // ──────────── 当前视图的节点/边 ────────────

  const currentNodes = viewLevel === 'province' ? provNodes : detNodes;
  const currentEdges = viewLevel === 'province' ? provEdges : detEdges;
  const onNodesChange = viewLevel === 'province' ? onProvNodesChange : onDetNodesChange;
  const onEdgesChange = viewLevel === 'province' ? onProvEdgesChange : onDetEdgesChange;
  const onNodeClick = viewLevel === 'province' ? onProvinceNodeClick : onDetailNodeClick;
  const currentNodeTypes: Record<string, React.ComponentType<any>> = viewLevel === 'province'
    ? { provinceNode: ProvinceNode }
    : { neNode: NeNode };

  return (
    <Box sx={{ display: 'flex', height: 'calc(100vh - 112px)', gap: 2 }}>
      {/* 拓扑图区域 */}
      <Card sx={{ flex: 1, backgroundColor: '#1a2332', overflow: 'hidden', position: 'relative' }}>
        {/* 面包屑导航 */}
        <Box sx={{ position: 'absolute', top: 10, left: 10, zIndex: 10, display: 'flex', alignItems: 'center', gap: 1 }}>
          {viewLevel === 'detail' && selectedProvince && (
            <Button
              size="small"
              startIcon={<ArrowBackIcon />}
              onClick={goBackToProvince}
              sx={{ color: '#9e9e9e', borderColor: '#2d3d50', '&:hover': { borderColor: '#5c8aff', color: '#5c8aff' } }}
              variant="outlined"
            >
              返回总览
            </Button>
          )}
          <Breadcrumbs separator={<NavigateNextIcon fontSize="small" />} sx={{ color: '#9e9e9e' }}>
            <Link
              underline="hover"
              color={viewLevel === 'province' ? 'primary' : 'inherit'}
              sx={{ cursor: 'pointer', fontSize: 13, fontWeight: viewLevel === 'province' ? 600 : 400 }}
              onClick={goBackToProvince}
            >
              省级总览
            </Link>
            {viewLevel === 'detail' && selectedProvince && (
              <Typography sx={{ fontSize: 13, fontWeight: 600, color: '#e0e0e0' }}>
                {getProvinceDisplayName(selectedProvince)}
              </Typography>
            )}
          </Breadcrumbs>
        </Box>

        {/* 省份信息卡片（详情模式） */}
        {viewLevel === 'detail' && selectedProvince && (
          <Box sx={{ position: 'absolute', top: 50, left: 10, zIndex: 10, backgroundColor: '#1a2332ee', borderRadius: 1, p: 1.5, maxWidth: 280 }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 600, color: '#e0e0e0', mb: 0.5 }}>
              {getProvinceDisplayName(selectedProvince)}
            </Typography>
            <Typography variant="caption" sx={{ color: '#9e9e9e' }}>
              网元数: {(neByProvince[selectedProvince] || []).length} |
              告警: {getProvinceAlarmStats(selectedProvince, alarms).total}条
            </Typography>
            <Typography variant="caption" sx={{ color: '#666', display: 'block', mt: 0.5 }}>
              橙色虚线 = 跨省链路
            </Typography>
          </Box>
        )}

        {/* 图例 */}
        <Box
          sx={{
            position: 'absolute',
            bottom: 10,
            left: 10,
            zIndex: 10,
            backgroundColor: '#1a2332ee',
            borderRadius: 1,
            p: 1.5,
            display: 'flex',
            gap: 1.5,
            flexWrap: 'wrap',
          }}
        >
          {viewLevel === 'province' ? (
            [
              { label: '紧急告警', color: '#f44336' },
              { label: '主要告警', color: '#ff9800' },
              { label: '次要告警', color: '#ffc107' },
              { label: '提示告警', color: '#2196f3' },
              { label: '无告警', color: '#4caf50' },
              { label: '省际链路', color: '#5c8aff' },
            ].map((item) => (
              <Box key={item.label} sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Box sx={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: item.color }} />
                <Typography variant="caption" sx={{ color: '#9e9e9e', fontSize: 11 }}>{item.label}</Typography>
              </Box>
            ))
          ) : (
            [
              { label: '紧急', color: '#f44336' },
              { label: '主要', color: '#ff9800' },
              { label: '次要', color: '#ffc107' },
              { label: '提示', color: '#2196f3' },
              { label: '正常', color: '#4caf50' },
              { label: '省际链路', color: '#ff9800', dash: true },
            ].map((item) => (
              <Box key={item.label} sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                {item.dash ? (
                  <Box sx={{ width: 16, height: 0, borderTop: `2px dashed ${item.color}` }} />
                ) : (
                  <Box sx={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: item.color }} />
                )}
                <Typography variant="caption" sx={{ color: '#9e9e9e', fontSize: 11 }}>{item.label}</Typography>
              </Box>
            ))
          )}
        </Box>

        <ReactFlow
          nodes={currentNodes}
          edges={currentEdges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onNodeClick={onNodeClick}
          nodeTypes={currentNodeTypes}
          defaultViewport={{ x: 0, y: 0, zoom: 0.55 }}
          fitView
          minZoom={0.2}
          maxZoom={3}
          defaultEdgeOptions={{ type: 'smoothstep' }}
          key={viewLevel === 'province' ? 'province' : `detail-${selectedProvince}`}
        >
          <Controls />
          <MiniMap
            nodeColor={(node) => {
              if (viewLevel === 'province') {
                const d = node.data as { alarmStats?: ProvinceAlarmStats };
                return d.alarmStats ? getProvinceBorderColor(d.alarmStats) : '#4caf50';
              }
              const d = node.data as { highestLevel: AlarmLevel | null };
              return getNeColor(d.highestLevel);
            }}
            maskColor="#0a192999"
          />
          <Background variant={BackgroundVariant.Dots} gap={16} size={1} color="#2d3d50" />
        </ReactFlow>
      </Card>

      {/* 网元告警详情弹窗（仅详情模式下点击网元时弹出） */}
      <Dialog
        open={!!selectedNe && viewLevel === 'detail'}
        onClose={() => setSelectedNe(null)}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          sx: { backgroundColor: '#1a2332', border: '1px solid #2d3d50' },
        }}
      >
        <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
            网元告警详情
          </Typography>
          <IconButton onClick={() => setSelectedNe(null)} size="small">
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent>
          {selectedNeInfo && (
            <>
              <Box sx={{ mb: 2 }}>
                <Typography variant="body2" sx={{ color: '#9e9e9e' }}>网元名称</Typography>
                <Typography variant="body1" sx={{ fontWeight: 600 }}>{selectedNeInfo.neName}</Typography>
                <Box sx={{ display: 'flex', gap: 2, mt: 1 }}>
                  <Typography variant="body2" sx={{ color: '#9e9e9e' }}>
                    类型: {selectedNeInfo.neType}
                  </Typography>
                  <Typography variant="body2" sx={{ color: '#9e9e9e' }}>
                    IP: {selectedNeInfo.ipAddress}
                  </Typography>
                  <Chip
                    label={selectedNeInfo.onlineStatus}
                    size="small"
                    color={selectedNeInfo.onlineStatus === '在线' ? 'success' : 'error'}
                    sx={{ height: 20, fontSize: 11 }}
                  />
                </Box>
              </Box>
              <Divider sx={{ borderColor: '#2d3d50', mb: 1 }} />
              <Typography variant="subtitle2" sx={{ mb: 1 }}>
                告警列表（{selectedNeAlarms.length}条）
              </Typography>
              {selectedNeAlarms.length === 0 ? (
                <Typography variant="body2" sx={{ color: '#4caf50', textAlign: 'center', py: 2 }}>
                  该网元无活动告警
                </Typography>
              ) : (
                <List dense>
                  {selectedNeAlarms.map((alarm) => (
                    <ListItem key={alarm.id} sx={{ px: 0 }}>
                      <Chip
                        label={alarm.alarmLevel}
                        size="small"
                        sx={{
                          mr: 1,
                          backgroundColor: `${ALARM_LEVEL_COLORS[alarm.alarmLevel]}22`,
                          color: ALARM_LEVEL_COLORS[alarm.alarmLevel],
                          fontWeight: 600,
                          fontSize: 11,
                          minWidth: 48,
                        }}
                      />
                      <ListItemText
                        primary={alarm.alarmTitle}
                        secondary={`${alarm.boardName} 槽位${alarm.slotNo} | ${alarm.alarmStatus}`}
                        primaryTypographyProps={{ fontSize: 13 }}
                        secondaryTypographyProps={{ fontSize: 11, color: '#9e9e9e' }}
                      />
                    </ListItem>
                  ))}
                </List>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </Box>
  );
};

export default Topology;
