import React, { useMemo, useState, useCallback, useEffect } from 'react';
import {
  ReactFlow,
  Controls,
  MiniMap,
  Background,
  useNodesState,
  useEdgesState,
  type Node,
  type Edge,
  Handle,
  Position,
  type NodeProps,
  BackgroundVariant,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import {
  Box,
  Card,
  Typography,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Divider,
  Tooltip,
  Button,
  Breadcrumbs,
  Link,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import CloseIcon from '@mui/icons-material/Close';
import useAppStore from '../store/useAppStore';
import type { AlarmLevel, NeType } from '../types';
import { ALARM_LEVEL_COLORS } from '../types';
import { mockTopologyLinks } from '../data/mockData';
import PREFECTURE_CITIES from '../data/prefectureCities';

// ──────────── 工具函数 ────────────

/** 网元节点最高告警级别 */
function getNeHighestAlarm(
  neName: string,
  alarms: { neName: string; alarmLevel: AlarmLevel; alarmStatus: string }[]
): AlarmLevel | null {
  const levelOrder: Record<AlarmLevel, number> = { 紧急: 4, 主要: 3, 次要: 2, 提示: 1 };
  const neAlarms = alarms.filter((a) => a.neName === neName && a.alarmStatus !== '已确认已清除');
  if (neAlarms.length === 0) return null;
  return neAlarms.reduce<AlarmLevel>((highest, a) => {
    return levelOrder[a.alarmLevel] > levelOrder[highest] ? a.alarmLevel : highest;
  }, neAlarms[0].alarmLevel);
}

/** 网元节点颜色 */
function getNeColor(highestLevel: AlarmLevel | null): string {
  if (!highestLevel) return '#4caf50';
  return ALARM_LEVEL_COLORS[highestLevel];
}

/** 网元类型图标映射 */
function getNeTypeLabel(neType: NeType): string {
  switch (neType) {
    case 'FONST 6000 N32': return 'EXC';
    case 'FONST COTP_POTN': return 'OTM';
    case 'FONST COTP M': return 'OA';
    default: return neType;
  }
}

/** 告警统计 */
interface ProvinceAlarmStats {
  total: number;
  urgent: number;
  major: number;
  minor: number;
  info: number;
  highestLevel: AlarmLevel | null;
}

/** 聚合省份告警统计 */
function getProvinceAlarmStats(
  province: string,
  alarms: { neName: string; alarmLevel: AlarmLevel; alarmStatus: string; province: string }[]
): ProvinceAlarmStats {
  // 通过 province 字段匹配（告警数据中有省份信息）
  // 支持格式：云南省 / 云南省(YN) / 新疆维吾尔自治区 / 新疆维吾尔自治区(XJ)
  const provinceAlarms = alarms.filter((a) => {
    const ap = a.province || '';
    if (!ap) return false;
    // 完全匹配
    if (ap === province) return true;
    // 前缀匹配（云南省(YN) startsWith 云南省）
    if (ap.startsWith(province) || province.startsWith(ap)) return true;
    // 去掉代码后的核心名匹配
    const apCore = ap.replace(/\([A-Z]+\)$/, '');
    const provCore = province.replace(/\([A-Z]+\)$/, '');
    if (apCore === provCore) return true;
    // 关键字匹配：提取省份核心名（去掉"省"、"市"、"自治区"等后缀）
    const stripSuffix = (s: string) => s.replace(/\([A-Z]+\)$/, '').replace(/(省|市|壮族自治区|回族自治区|维吾尔自治区|自治区)$/, '');
    if (stripSuffix(ap) === stripSuffix(province)) return true;
    return false;
  });
  const activeAlarms = provinceAlarms.filter((a) => a.alarmStatus !== '已确认已清除');

  const stats: ProvinceAlarmStats = { total: activeAlarms.length, urgent: 0, major: 0, minor: 0, info: 0, highestLevel: null };
  const levelOrder: Record<AlarmLevel, number> = { 紧急: 4, 主要: 3, 次要: 2, 提示: 1 };

  for (const a of activeAlarms) {
    switch (a.alarmLevel) {
      case '紧急': stats.urgent++; break;
      case '主要': stats.major++; break;
      case '次要': stats.minor++; break;
      case '提示': stats.info++; break;
    }
    if (!stats.highestLevel || levelOrder[a.alarmLevel] > levelOrder[stats.highestLevel]) {
      stats.highestLevel = a.alarmLevel;
    }
  }
  return stats;
}

/** 省份最高告警级别 → 边框颜色 */
function getProvinceBorderColor(stats: ProvinceAlarmStats): string {
  return getNeColor(stats.highestLevel);
}

// ──────────── 省份坐标布局 ────────────

/** 全国 34 个省级行政区坐标布局
 *  坐标系：从左到右=从西到东，从上到下=从北到南
 *  东北 → 华北 → 华东 → 华中 → 华南 → 西南 → 西北 → 港澳台
 */
const PROVINCE_COORDS: Record<string, { x: number; y: number }> = {
  // ── 东北 ──
  '黑龙江省(HL)':       { x: 1820, y: 150 },
  '吉林省(JL)':         { x: 1778, y: 270 },
  '辽宁省(LN)':         { x: 1736, y: 390 },
  '黑龙江省':           { x: 1820, y: 150 },
  '吉林省':             { x: 1778, y: 270 },
  '辽宁省':             { x: 1736, y: 390 },
  // ── 华北 ──
  '北京市(BJ)':         { x: 1610, y: 330 },
  '天津市(TJ)':         { x: 1652, y: 360 },
  '河北省(HE)':         { x: 1582, y: 390 },
  '山西省(SX)':         { x: 1512, y: 420 },
  '内蒙古自治区(NM)':   { x: 1428, y: 225 },
  '北京市':             { x: 1610, y: 330 },
  '天津市':             { x: 1652, y: 360 },
  '河北省':             { x: 1582, y: 390 },
  '山西省':             { x: 1512, y: 420 },
  '内蒙古自治区':       { x: 1428, y: 225 },
  // ── 华东 ──
  '山东省(SD)':         { x: 1652, y: 495 },
  '江苏省(JS)':         { x: 1708, y: 540 },
  '上海市(SH)':         { x: 1750, y: 555 },
  '浙江省(ZJ)':         { x: 1708, y: 630 },
  '安徽省(AH)':         { x: 1624, y: 585 },
  '福建省(FJ)':         { x: 1680, y: 720 },
  '江西省(JX)':         { x: 1596, y: 690 },
  '山东省':             { x: 1652, y: 495 },
  '江苏省':             { x: 1708, y: 540 },
  '上海市':             { x: 1750, y: 555 },
  '浙江省':             { x: 1708, y: 630 },
  '安徽省':             { x: 1624, y: 585 },
  '福建省':             { x: 1680, y: 720 },
  '江西省':             { x: 1596, y: 690 },
  // ── 华中 ──
  '河南省(HA)':         { x: 1540, y: 525 },
  '湖北省(HB)':         { x: 1498, y: 630 },
  '湖南省(HN)':         { x: 1498, y: 750 },
  '河南省':             { x: 1540, y: 525 },
  '湖北省':             { x: 1498, y: 630 },
  '湖南省':             { x: 1498, y: 750 },
  // ── 华南 ──
  '广东省(GD)':         { x: 1596, y: 840 },
  '广西壮族自治区(GX)': { x: 1470, y: 915 },
  '海南省(HI)':         { x: 1554, y: 975 },
  '广东省':             { x: 1596, y: 840 },
  '广西壮族自治区':     { x: 1470, y: 915 },
  '海南省':             { x: 1554, y: 975 },
  // ── 西南 ──
  '重庆市(CQ)':         { x: 1400, y: 705 },
  '四川省(SC)':         { x: 920,  y: 440 },
  '贵州省(GZ)':         { x: 980,  y: 550 },
  '云南省(YN)':         { x: 850,  y: 610 },
  '重庆市':             { x: 1400, y: 705 },
  '四川省':             { x: 920,  y: 440 },
  '贵州省':             { x: 980,  y: 550 },
  '云南省':             { x: 850,  y: 610 },
  // ── 西北 ──
  '陕西省(SN)':                 { x: 1400, y: 510 },
  '甘肃省(GS)':                 { x: 850,  y: 270 },
  '青海省(QH)':                 { x: 750,  y: 320 },
  '宁夏回族自治区(NX)':         { x: 920,  y: 280 },
  '新疆维吾尔自治区(XJ)':       { x: 400,  y: 190 },
  '陕西省':                     { x: 1400, y: 510 },
  '甘肃省':                     { x: 850,  y: 270 },
  '青海省':                     { x: 750,  y: 320 },
  '宁夏回族自治区':             { x: 920,  y: 280 },
  '新疆维吾尔自治区':           { x: 400,  y: 190 },
  // ── 港澳台 ──
  '香港特别行政区(HK)': { x: 1638, y: 870 },
  '澳门特别行政区(MC)': { x: 1610, y: 885 },
  '台湾省(TW)':         { x: 1750, y: 765 },
  '香港特别行政区':     { x: 1638, y: 870 },
  '澳门特别行政区':     { x: 1610, y: 885 },
  '台湾省':             { x: 1750, y: 765 },
};

/** 获取省份坐标（支持多种名称格式） */
function getProvinceCoord(province: string): { x: number; y: number } {
  if (PROVINCE_COORDS[province]) return PROVINCE_COORDS[province];
  // 尝试去掉括号中的代码部分匹配
  const shortName = province.replace(/\([A-Z]+\)$/, '');
  if (PROVINCE_COORDS[shortName]) return PROVINCE_COORDS[shortName];
  // 尝试带代码匹配
  const codeMatch = province.match(/([^\(]+)\(([A-Z]+)\)$/);
  if (codeMatch) {
    const withCode = `${codeMatch[1]}(${codeMatch[2]})`;
    if (PROVINCE_COORDS[withCode]) return PROVINCE_COORDS[withCode];
  }
  return { x: 1120, y: 600 }; // 默认位置
}

/** 获取省份短显示名（去掉括号代码，用于UI显示） */
function getProvinceDisplayName(province: string): string {
  return province.replace(/\([A-Z]+\)$/, '');
}

/** 全国 34 个省级行政区（按地理解序：东北→华北→华东→华中→华南→西南→西北→港澳台） */
const ALL_PROVINCES = [
  // 东北
  '黑龙江省', '吉林省', '辽宁省',
  // 华北
  '北京市', '天津市', '河北省', '山西省', '内蒙古自治区',
  // 华东
  '山东省', '江苏省', '上海市', '浙江省', '安徽省', '福建省', '江西省',
  // 华中
  '河南省', '湖北省', '湖南省',
  // 华南
  '广东省', '广西壮族自治区', '海南省',
  // 西南
  '重庆市', '四川省', '贵州省', '云南省',
  // 西北
  '陕西省', '甘肃省', '青海省', '宁夏回族自治区', '新疆维吾尔自治区',
  // 港澳台
  '香港特别行政区', '澳门特别行政区', '台湾省',
];

/** 未知省份自动布局偏移 */
const AUTO_LAYOUT_POSITIONS = [
  { x: 1666, y: 225 }, { x: 1666, y: 562 }, { x: 1666, y: 900 },
  { x: 1666, y: 1238 }, { x: 1666, y: 1575 },
  { x: 98, y: 900 }, { x: 98, y: 1238 },
];

/** 省份内网元布局偏移 */
function getNeOffset(neType: NeType, index: number): { dx: number; dy: number } {
  switch (neType) {
    case 'FONST 6000 N32': return { dx: index * 180, dy: 0 };
    case 'FONST COTP_POTN': return { dx: index * 180, dy: 100 };
    case 'FONST COTP M': return { dx: index * 180, dy: 200 };
    default: return { dx: index * 180, dy: 0 };
  }
}

// ──────────── 自定义节点组件 ────────────

/** 省份节点组件（省级总览） */
const ProvinceNode: React.FC<NodeProps> = ({ data }) => {
  const d = data as {
    label: string;
    neCount: number;
    alarmStats: ProvinceAlarmStats;
    isActive: boolean;
  };

  // ── 不活跃节点（无网元数据）──
  if (!d.isActive) {
    return (
      <Box
        sx={{
          padding: '3px 5px',
          borderRadius: 1,
          backgroundColor: '#0f1a2a',
          border: '1px dashed #2d3d50',
          minWidth: 50,
          textAlign: 'center',
          opacity: 0.5,
          cursor: 'default',
          position: 'relative',
        }}
      >
        <Handle type="target" position={Position.Left} style={{ background: '#2d3d50', width: 4, height: 4 }} />
        <Handle type="source" position={Position.Right} style={{ background: '#2d3d50', width: 4, height: 4 }} />
        <Handle type="target" position={Position.Top} style={{ background: '#2d3d50', width: 4, height: 4 }} />
        <Handle type="source" position={Position.Bottom} style={{ background: '#2d3d50', width: 4, height: 4 }} />
        <Typography variant="caption" sx={{ fontWeight: 600, color: '#555', fontSize: 9 }}>
          {d.label}
        </Typography>
      </Box>
    );
  }

  const borderColor = getProvinceBorderColor(d.alarmStats);
  const hasAlarm = d.alarmStats.total > 0;

  return (
    <Tooltip
      title={`${d.label} | ${d.neCount}个网元 | 告警:${d.alarmStats.total}`}
      arrow
      placement="top"
    >
      <Box
        sx={{
          padding: '6px 10px',
          borderRadius: 2,
          backgroundColor: '#1a2332',
          border: `1.5px solid ${borderColor}`,
          minWidth: 70,
          textAlign: 'center',
          position: 'relative',
          boxShadow: hasAlarm ? `0 0 12px ${borderColor}66` : '0 0 6px #3d506844',
          cursor: 'pointer',
          transition: 'all 0.2s',
          '&:hover': {
            boxShadow: hasAlarm ? `0 0 20px ${borderColor}88` : '0 0 10px #3d506888',
            transform: 'scale(1.1)',
          },
        }}
      >
        <Handle type="target" position={Position.Left} style={{ background: '#3d5068', width: 5, height: 5 }} />
        <Handle type="source" position={Position.Right} style={{ background: '#3d5068', width: 5, height: 5 }} />
        <Handle type="target" position={Position.Top} style={{ background: '#3d5068', width: 5, height: 5 }} />
        <Handle type="source" position={Position.Bottom} style={{ background: '#3d5068', width: 5, height: 5 }} />

        {/* 省份名 */}
        <Typography
          variant="subtitle2"
          sx={{ fontWeight: 700, color: '#e0e0e0', fontSize: 11, mb: 0.2 }}
        >
          {d.label}
        </Typography>

        {/* 网元数 */}
        {d.neCount > 0 && (
          <Typography variant="caption" sx={{ color: '#9e9e9e', fontSize: 9 }}>
            {d.neCount}个网元
          </Typography>
        )}

        {/* 告警统计条 - 单行紧凑 */}
        {hasAlarm && (
          <Box sx={{ mt: 0.2, display: 'flex', justifyContent: 'center', gap: 0.2, flexWrap: 'wrap' }}>
            {d.alarmStats.urgent > 0 && (
              <Chip label={`紧${d.alarmStats.urgent}`} size="small" sx={{ height: 14, fontSize: 7, backgroundColor: '#f4433622', color: '#f44336', fontWeight: 600, minWidth: 0 }} />
            )}
            {d.alarmStats.major > 0 && (
              <Chip label={`主${d.alarmStats.major}`} size="small" sx={{ height: 14, fontSize: 7, backgroundColor: '#ff980022', color: '#ff9800', fontWeight: 600, minWidth: 0 }} />
            )}
            {d.alarmStats.minor > 0 && (
              <Chip label={`次${d.alarmStats.minor}`} size="small" sx={{ height: 14, fontSize: 7, backgroundColor: '#ffc10722', color: '#ffc107', fontWeight: 600, minWidth: 0 }} />
            )}
            {d.alarmStats.info > 0 && (
              <Chip label={`提${d.alarmStats.info}`} size="small" sx={{ height: 14, fontSize: 7, backgroundColor: '#2196f322', color: '#2196f3', fontWeight: 600, minWidth: 0 }} />
            )}
            <Typography component="span" variant="caption" sx={{ color: borderColor, fontSize: 8, fontWeight: 600, ml: 0.3 }}>
              {d.alarmStats.total}条
            </Typography>
          </Box>
        )}

        {!hasAlarm && (
          <Typography variant="caption" sx={{ color: '#4caf50', fontSize: 9, display: 'block' }}>
            无告警
          </Typography>
        )}
      </Box>
    </Tooltip>
  );
};

/** 网元节点组件（省份详情） */
const NeNode: React.FC<NodeProps> = ({ data }) => {
  const nodeData = data as {
    label: string;
    neType: string;
    highestLevel: AlarmLevel | null;
    alarmCount: number;
    province: string;
    city: string;
    onlineStatus: string;
    alarmStats: { urgent: number; major: number; minor: number; info: number };
  };

  const color = getNeColor(nodeData.highestLevel);
  const isOffline = nodeData.onlineStatus === '离线';
  const hasAlarm = nodeData.alarmCount > 0;

  return (
    <Tooltip
      title={`${nodeData.label} | ${nodeData.province}${nodeData.city} | ${nodeData.neType} | 告警:${nodeData.alarmCount}`}
      arrow
      placement="top"
    >
      <Box
        sx={{
          padding: '6px 10px',
          borderRadius: 2,
          backgroundColor: '#1a2332',
          border: `2px solid ${color}`,
          minWidth: 80,
          textAlign: 'center',
          position: 'relative',
          boxShadow: `0 0 12px ${color}44`,
          opacity: isOffline ? 0.6 : 1,
          cursor: 'pointer',
        }}
      >
        <Handle type="target" position={Position.Left} style={{ background: '#3d5068', width: 6, height: 6 }} />
        <Handle type="source" position={Position.Right} style={{ background: '#3d5068', width: 6, height: 6 }} />
        <Handle type="target" position={Position.Top} style={{ background: '#3d5068', width: 6, height: 6 }} />
        <Handle type="source" position={Position.Bottom} style={{ background: '#3d5068', width: 6, height: 6 }} />

        {nodeData.highestLevel && (
          <Box sx={{ position: 'absolute', top: -4, right: -4, width: 10, height: 10, borderRadius: '50%', backgroundColor: color, border: '2px solid #1a2332' }} />
        )}

        <Chip
          label={nodeData.neType}
          size="small"
          sx={{ position: 'absolute', top: -10, left: 2, height: 14, fontSize: 9, fontWeight: 700, backgroundColor: `${color}22`, color }}
        />

        {isOffline && (
          <Chip label="离线" size="small" sx={{ position: 'absolute', bottom: -8, right: 2, height: 14, fontSize: 9, backgroundColor: '#f4433622', color: '#f44336' }} />
        )}

        <Typography variant="caption" sx={{ display: 'block', fontWeight: 600, color: '#e0e0e0', fontSize: 10, lineHeight: 1.2, mt: 0.5, maxWidth: 100, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {nodeData.label}
        </Typography>
        
        {hasAlarm && (
          <Box sx={{ mt: 0.3, display: 'flex', justifyContent: 'center', gap: 0.2, flexWrap: 'wrap' }}>
            {nodeData.alarmStats.urgent > 0 && (
              <Chip label={`紧${nodeData.alarmStats.urgent}`} size="small" sx={{ height: 14, fontSize: 7, backgroundColor: '#f4433622', color: '#f44336', fontWeight: 600, minWidth: 0 }} />
            )}
            {nodeData.alarmStats.major > 0 && (
              <Chip label={`主${nodeData.alarmStats.major}`} size="small" sx={{ height: 14, fontSize: 7, backgroundColor: '#ff980022', color: '#ff9800', fontWeight: 600, minWidth: 0 }} />
            )}
            {nodeData.alarmStats.minor > 0 && (
              <Chip label={`次${nodeData.alarmStats.minor}`} size="small" sx={{ height: 14, fontSize: 7, backgroundColor: '#ffc10722', color: '#ffc107', fontWeight: 600, minWidth: 0 }} />
            )}
            {nodeData.alarmStats.info > 0 && (
              <Chip label={`提${nodeData.alarmStats.info}`} size="small" sx={{ height: 14, fontSize: 7, backgroundColor: '#2196f322', color: '#2196f3', fontWeight: 600, minWidth: 0 }} />
            )}
          </Box>
        )}

        {hasAlarm && (
          <Typography variant="caption" sx={{ color, fontSize: 9, fontWeight: 600, display: 'block', mt: 0.2 }}>
            {nodeData.alarmCount}条
          </Typography>
        )}
      </Box>
    </Tooltip>
  );
};

/** 城市节点组件（省份内二级拓扑）— 复用省份节点样式 */
const CityNode: React.FC<NodeProps> = (props) => <ProvinceNode {...props} />;

const nodeTypes = { provinceNode: ProvinceNode, neNode: NeNode, cityNode: CityNode };

// ──────────── 主页面组件 ────────────

const Topology: React.FC = () => {
  const { networkElements, alarms } = useAppStore();
  const [selectedNe, setSelectedNe] = useState<string | null>(null);

  // 三级视图状态：province → city → ne
  const [viewLevel, setViewLevel] = useState<'province' | 'city' | 'ne'>('province');
  const [selectedProvince, setSelectedProvince] = useState<string | null>(null);
  const [selectedCity, setSelectedCity] = useState<string | null>(null);

  /** 城市名规范化：将 NE 数据中的城市名映射到标准地市名（PREFECTURE_CITIES 中的名称） */
  const normalizeCityName = useCallback((city: string, province: string): string => {
    const CITY_ALIAS: Record<string, Record<string, string>> = {
      '云南省': {
        '大理市': '大理白族自治州',
        '宜良': '昆明市',
        '楚雄市': '楚雄彝族自治州',
      },
      '湖南省': {
        '吉首市': '湘西土家族苗族自治州',
      },
    };
    return CITY_ALIAS[province]?.[city] || city;
  }, []);

  /** 获取城市告警统计 */
  const getCityAlarmStats = useCallback((city: string, province: string): ProvinceAlarmStats => {
    const provNEList = networkElements.filter((ne) => ne.province.includes(province.replace(/\([A-Z]+\)$/, '')));
    const cityNes = provNEList.filter((ne) => normalizeCityName(ne.city || '未知', province) === city);
    const cityNeNames = new Set(cityNes.map((ne) => ne.neName));
    const cityAlarms = alarms.filter((a) => cityNeNames.has(a.neName) && a.alarmStatus !== '已确认已清除');

    const stats: ProvinceAlarmStats = { total: cityAlarms.length, urgent: 0, major: 0, minor: 0, info: 0, highestLevel: null };
    const levelOrder: Record<AlarmLevel, number> = { 紧急: 4, 主要: 3, 次要: 2, 提示: 1 };

    for (const a of cityAlarms) {
      switch (a.alarmLevel) {
        case '紧急': stats.urgent++; break;
        case '主要': stats.major++; break;
        case '次要': stats.minor++; break;
        case '提示': stats.info++; break;
      }
      if (!stats.highestLevel || levelOrder[a.alarmLevel] > levelOrder[stats.highestLevel]) {
        stats.highestLevel = a.alarmLevel;
      }
    }
    return stats;
  }, [networkElements, alarms, normalizeCityName]);

  /** 省份 → 网元映射 */
  const neByProvince = useMemo(() => {
    const map: Record<string, typeof networkElements> = {};
    for (const ne of networkElements) {
      const shortProvince = ne.province.replace(/\([A-Z]+\)$/, '');
      if (!map[shortProvince]) map[shortProvince] = [];
      map[shortProvince].push(ne);
    }
    return map;
  }, [networkElements]);

  // ──────────── 省级总览节点 ────────────

  const provinceNodes = useMemo((): Node[] => {
    return ALL_PROVINCES.map((province) => {
      const coord = getProvinceCoord(province);
      const neList = neByProvince[province] || [];
      const alarmStats = getProvinceAlarmStats(province, alarms);
      const isActive = neList.length > 0;

      return {
        id: `province-${province}`,
        type: 'provinceNode',
        position: coord,
        data: {
          label: getProvinceDisplayName(province),
          neCount: neList.length,
          alarmStats,
          isActive,
        },
      };
    });
  }, [neByProvince, alarms]);

  // ──────────── 省级总览边（省份间连纤） ────────────

  const provinceEdges = useMemo((): Edge[] => {
    // 从拓扑链路推导省份间连接关系
    const provinceLinkMap: Record<string, { count: number; systems: Set<string> }> = {};

    for (const link of mockTopologyLinks) {
      const sourceNe = networkElements.find((ne) => ne.id === link.source);
      const targetNe = networkElements.find((ne) => ne.id === link.target);
      if (!sourceNe || !targetNe) continue;

      // 仅跨省份的链路才在省级总览中显示
      if (sourceNe.province === targetNe.province) continue;

      const key = [sourceNe.province, targetNe.province].sort().join('⟷');
      if (!provinceLinkMap[key]) {
        provinceLinkMap[key] = { count: 0, systems: new Set() };
      }
      provinceLinkMap[key].count++;
      provinceLinkMap[key].systems.add(link.system);
    }

    return Object.entries(provinceLinkMap).map(([key, val], i) => {
      const [p1, p2] = key.split('⟷');
      // 规范化省份名（去掉代码后缀），与 provinceNodes 的 id 保持一致
      const p1Short = p1.replace(/\([A-Z]+\)$/, '');
      const p2Short = p2.replace(/\([A-Z]+\)$/, '');
      return {
        id: `province-edge-${i}`,
        source: `province-${p1Short}`,
        target: `province-${p2Short}`,
        label: `${val.count}条链路`,
        animated: true,
        style: { stroke: '#5c8aff', strokeWidth: 3 },
        labelStyle: { fill: '#9e9e9e', fontSize: 11, fontWeight: 600 },
        labelBgStyle: { fill: '#0a1929', fillOpacity: 0.9 },
        labelBgPadding: [6, 3] as [number, number],
        type: 'smoothstep',
      };
    });
  }, [networkElements]);

  // ──────────── 省份详情节点（按城市分组） ────────────

  /** 获取该省份中所有城市（来自预定义列表 + NE数据补充） */
  const citiesInProvince = useMemo((): string[] => {
    if (!selectedProvince) return [];
    // 优先使用预定义的完整地市列表
    const predefined = PREFECTURE_CITIES[selectedProvince];
    if (predefined && predefined.length > 0) return predefined;
    // 回退：从 NE 数据中提取
    const neList = neByProvince[selectedProvince] || [];
    return [...new Set(neList.map((ne) => ne.city))].filter(Boolean);
  }, [selectedProvince, neByProvince]);

  /** 城市 → 该城市所有的网元ID 映射（城市名已归一化到 PREFECTURE_CITIES 标准名称） */
  const neIdsByCity = useMemo((): Record<string, string[]> => {
    if (!selectedProvince) return {};
    const neList = neByProvince[selectedProvince] || [];
    const map: Record<string, string[]> = {};
    for (const ne of neList) {
      const city = normalizeCityName(ne.city || '未知', selectedProvince);
      if (!map[city]) map[city] = [];
      map[city].push(ne.id);
    }
    return map;
  }, [selectedProvince, neByProvince, normalizeCityName]);

  /** 城市节点布局偏移 */
  function getCityOffset(index: number, total: number): { dx: number; dy: number } {
    const cols = Math.min(4, total);
    const col = index % cols;
    const row = Math.floor(index / cols);
    const spacingX = 160;
    const spacingY = 100;
    const startX = -((cols - 1) * spacingX) / 2;
    return { dx: startX + col * spacingX, dy: row * spacingY };
  }

  /** 二级拓扑：城市节点（显示该省所有地市，有网元的点亮，无网元的灰选） */
  const cityNodes = useMemo((): Node[] => {
    if (!selectedProvince) return [];
    const cities = citiesInProvince;
    const base = getProvinceCoord(selectedProvince);
    const provNEList = neByProvince[selectedProvince] || [];

    return cities.map((city, index) => {
      const neIds = neIdsByCity[city] || [];
      const neCount = neIds.length;
      const isActive = neCount > 0;

      let alarmStats: ProvinceAlarmStats = { total: 0, urgent: 0, major: 0, minor: 0, info: 0, highestLevel: null };
      if (isActive) {
        alarmStats = getCityAlarmStats(city, selectedProvince);
      }

      const offset = getCityOffset(index, cities.length);

      return {
        id: `city-${city}`,
        type: 'cityNode',
        position: { x: base.x + offset.dx, y: base.y + offset.dy },
        data: {
          label: city,
          neCount,
          alarmStats,
          isActive,
        },
      };
    });
  }, [selectedProvince, citiesInProvince, neIdsByCity, getCityAlarmStats, neByProvince]);

  /** 城市级别边（将网元级链路映射为城市间连线） */
  const cityEdges = useMemo((): Edge[] => {
    if (!selectedProvince) return [];
    // 建立 NE ID → 城市名的反向映射
    const neToCity: Record<string, string> = {};
    for (const [city, ids] of Object.entries(neIdsByCity)) {
      for (const id of ids) {
        neToCity[id] = city;
      }
    }

    // 遍历拓扑链路，建立城市间连接（去重）
    const neIds = new Set(Object.values(neIdsByCity).flat());
    const cityLinkMap: Record<string, { count: number; isCrossProvince: boolean }> = {};

    for (const link of mockTopologyLinks) {
      const srcIn = neIds.has(link.source);
      const tgtIn = neIds.has(link.target);
      if (!srcIn && !tgtIn) continue; // 两端都不在本省

      const srcCity = neToCity[link.source];
      const tgtCity = neToCity[link.target];
      if (!srcCity || !tgtCity || srcCity === tgtCity) continue;

      const key = [srcCity, tgtCity].sort().join('⟷');
      if (!cityLinkMap[key]) {
        cityLinkMap[key] = { count: 0, isCrossProvince: !(srcIn && tgtIn) };
      }
      cityLinkMap[key].count++;
    }

    return Object.entries(cityLinkMap).map(([key, val], i) => {
      const [c1, c2] = key.split('⟷');
      return {
        id: `city-edge-${i}`,
        source: `city-${c1}`,
        target: `city-${c2}`,
        label: `${val.count}条`,
        animated: !val.isCrossProvince,
        style: val.isCrossProvince
          ? { stroke: '#ff9800', strokeWidth: 2, strokeDasharray: '6 3' }
          : { stroke: '#3d5068', strokeWidth: 2 },
        labelStyle: { fill: val.isCrossProvince ? '#ff9800' : '#9e9e9e', fontSize: 10 },
        labelBgStyle: { fill: '#0a1929', fillOpacity: 0.8 },
        type: 'smoothstep',
      };
    });
  }, [selectedProvince, neIdsByCity]);

  /** 三级拓扑：选中城市内的网元节点 */
  const neDetailNodes = useMemo((): Node[] => {
    if (!selectedCity || !selectedProvince) return [];
    const neIdsList = neIdsByCity[selectedCity] || [];
    const neList = neIdsList.map((id) => networkElements.find((n) => n.id === id)).filter(Boolean) as typeof networkElements;

    const base = getProvinceCoord(selectedProvince);
    return neList.map((ne, index) => {
      const highestLevel = getNeHighestAlarm(ne.neName, alarms);
      const neAlarms = alarms.filter((a) => a.neName === ne.neName && a.alarmStatus !== '已确认已清除');
      const alarmCount = neAlarms.length;
      const alarmStats = { urgent: 0, major: 0, minor: 0, info: 0 };
      for (const a of neAlarms) {
        if (a.alarmLevel === '紧急') alarmStats.urgent++;
        else if (a.alarmLevel === '主要') alarmStats.major++;
        else if (a.alarmLevel === '次要') alarmStats.minor++;
        else if (a.alarmLevel === '提示') alarmStats.info++;
      }

      const shortName = ne.neName.split('-').slice(2).join('-');
      const typeLabel = getNeTypeLabel(ne.neType);

      return {
        id: ne.id,
        type: 'neNode',
        position: { x: base.x + (index % 3) * 200, y: base.y + Math.floor(index / 3) * 120 },
        data: {
          label: shortName,
          neType: typeLabel,
          highestLevel,
          alarmCount,
          alarmStats,
          province: ne.province,
          city: ne.city,
          onlineStatus: ne.onlineStatus,
        },
      };
    });
  }, [selectedCity, selectedProvince, neIdsByCity, networkElements, alarms]);

  const neDetailEdges = useMemo((): Edge[] => {
    if (!selectedCity || !selectedProvince) return [];
    const neIdsList = new Set(neIdsByCity[selectedCity] || []);
    return mockTopologyLinks
      .filter((link) => neIdsList.has(link.source) || neIdsList.has(link.target))
      .map((link) => ({
        id: link.id,
        source: link.source,
        target: link.target,
        label: link.label,
        animated: true,
        style: { stroke: '#3d5068', strokeWidth: 2 },
        labelStyle: { fill: '#9e9e9e', fontSize: 10 },
        labelBgStyle: { fill: '#0a1929', fillOpacity: 0.8 },
        type: 'smoothstep',
      }));
  }, [selectedCity, selectedProvince, neIdsByCity]);

  // ──────────── ReactFlow 状态 ────────────

  const [provNodes, setProvNodes, onProvNodesChange] = useNodesState(provinceNodes);
  const [provEdges, setProvEdges, onProvEdgesChange] = useEdgesState(provinceEdges);
  const [cityNodesState, setCityNodes, onCityNodesChange] = useNodesState(cityNodes);
  const [cityEdgesState, setCityEdges, onCityEdgesChange] = useEdgesState(cityEdges);
  const [neDetNodes, setNeDetNodes, onNeDetNodesChange] = useNodesState(neDetailNodes);
  const [neDetEdges, setNeDetEdges, onNeDetEdgesChange] = useEdgesState(neDetailEdges);

  // ── 同步 useMemo 计算的节点/边到 useNodesState/useEdgesState ──
  // 当 selectedProvince/selectedCity 变化时，cityNodes/cityEdges/neDetailNodes/neDetailEdges 重新计算，
  // 但 useNodesState 只保留初始值，必须手动同步
  useEffect(() => { setCityNodes(cityNodes); }, [cityNodes, setCityNodes]);
  useEffect(() => { setCityEdges(cityEdges); }, [cityEdges, setCityEdges]);
  useEffect(() => { setNeDetNodes(neDetailNodes); }, [neDetailNodes, setNeDetNodes]);
  useEffect(() => { setNeDetEdges(neDetailEdges); }, [neDetailEdges, setNeDetEdges]);

  // ──────────── 点击事件 ────────────

  /** 省级总览 - 点击省份节点 → 下钻到城市 */
  const onProvinceNodeClick = useCallback((_: React.MouseEvent, node: Node) => {
    const nodeData = node.data as { isActive?: boolean };
    if (!nodeData.isActive) return;
    const provinceName = node.id.replace('province-', '');
    setSelectedProvince(provinceName);
    setViewLevel('city');
  }, []);

  /** 城市节点点击 → 下钻到网元 */
  const onCityNodeClick = useCallback((_: React.MouseEvent, node: Node) => {
    const nodeData = node.data as { isActive?: boolean };
    if (!nodeData.isActive) return;
    const cityName = node.id.replace('city-', '');
    setSelectedCity(cityName);
    setViewLevel('ne');
  }, []);

  /** 网元节点点击 → 弹窗显示告警详情 */
  const onNeNodeClick = useCallback((_: React.MouseEvent, node: Node) => {
    setSelectedNe(node.id);
  }, []);

  /** 返回上一级 */
  const goBack = useCallback(() => {
    if (viewLevel === 'ne') {
      setViewLevel('city');
      setSelectedCity(null);
      setSelectedNe(null);
    } else if (viewLevel === 'city') {
      setViewLevel('province');
      setSelectedProvince(null);
      setSelectedCity(null);
      setSelectedNe(null);
    }
  }, [viewLevel]);

  // ──────────── 选中网元的告警详情 ────────────

  const selectedNeAlarms = useMemo(() => {
    if (!selectedNe) return [];
    const ne = networkElements.find((n) => n.id === selectedNe);
    if (!ne) return [];
    return alarms.filter((a) => a.neName === ne.neName);
  }, [selectedNe, networkElements, alarms]);

  const selectedNeInfo = useMemo(() => {
    if (!selectedNe) return null;
    return networkElements.find((n) => n.id === selectedNe) || null;
  }, [selectedNe, networkElements]);

  // ──────────── 当前视图的节点/边 ────────────

  const currentNodes = viewLevel === 'province' ? provNodes : viewLevel === 'city' ? cityNodesState : neDetNodes;
  const currentEdges = viewLevel === 'province' ? provEdges : viewLevel === 'city' ? cityEdgesState : neDetEdges;
  const currentNodesChange = viewLevel === 'province' ? onProvNodesChange : viewLevel === 'city' ? onCityNodesChange : onNeDetNodesChange;
  const currentEdgesChange = viewLevel === 'province' ? onProvEdgesChange : viewLevel === 'city' ? onCityEdgesChange : onNeDetEdgesChange;

  const onNodeClick = viewLevel === 'province' ? onProvinceNodeClick : viewLevel === 'city' ? onCityNodeClick : onNeNodeClick;
  const currentNodeTypes: Record<string, React.ComponentType<any>> = viewLevel === 'province'
    ? { provinceNode: ProvinceNode }
    : viewLevel === 'city'
      ? { cityNode: CityNode }
      : { neNode: NeNode };

  return (
    <Box sx={{ display: 'flex', height: 'calc(100vh - 112px)', gap: 2 }}>
      {/* 拓扑图区域 */}
      <Card sx={{ flex: 1, backgroundColor: '#1a2332', overflow: 'hidden', position: 'relative' }}>
        {/* 面包屑导航 */}
        <Box sx={{ position: 'absolute', top: 10, left: 10, zIndex: 10, display: 'flex', alignItems: 'center', gap: 1 }}>
          {viewLevel !== 'province' && (
            <Button
              size="small"
              startIcon={<ArrowBackIcon />}
              onClick={goBack}
              sx={{ color: '#9e9e9e', borderColor: '#2d3d50', '&:hover': { borderColor: '#5c8aff', color: '#5c8aff' } }}
              variant="outlined"
            >
              返回
            </Button>
          )}
          <Breadcrumbs separator={<NavigateNextIcon fontSize="small" />} sx={{ color: '#9e9e9e' }}>
            <Link
              underline="hover"
              color={viewLevel === 'province' ? 'primary' : 'inherit'}
              sx={{ cursor: 'pointer', fontSize: 13, fontWeight: viewLevel === 'province' ? 600 : 400 }}
              onClick={() => { setViewLevel('province'); setSelectedProvince(null); setSelectedCity(null); setSelectedNe(null); }}
            >
              省级总览
            </Link>
            {(viewLevel === 'city' || viewLevel === 'ne') && selectedProvince && (
              <Link
                underline="hover"
                color={viewLevel === 'city' ? 'primary' : 'inherit'}
                sx={{ cursor: 'pointer', fontSize: 13, fontWeight: viewLevel === 'city' ? 600 : 400 }}
                onClick={() => { setViewLevel('city'); setSelectedCity(null); setSelectedNe(null); }}
              >
                {getProvinceDisplayName(selectedProvince)}
              </Link>
            )}
            {viewLevel === 'ne' && selectedCity && (
              <Typography sx={{ fontSize: 13, fontWeight: 600, color: '#e0e0e0' }}>
                {selectedCity}
              </Typography>
            )}
          </Breadcrumbs>
        </Box>

        {/* 省份/城市信息卡片 */}
        {viewLevel === 'city' && selectedProvince && (
          <Box sx={{ position: 'absolute', top: 50, left: 10, zIndex: 10, backgroundColor: '#1a2332ee', borderRadius: 1, p: 1.5, maxWidth: 280 }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 600, color: '#e0e0e0', mb: 0.5 }}>
              {getProvinceDisplayName(selectedProvince)} - 地市分布
            </Typography>
            <Typography variant="caption" sx={{ color: '#9e9e9e' }}>
              有网元地市: {citiesInProvince.length}个 |
              告警: {getProvinceAlarmStats(selectedProvince, alarms).total}条
            </Typography>
          </Box>
        )}

        {/* 图例 */}
        <Box
          sx={{
            position: 'absolute',
            bottom: 10,
            left: 10,
            zIndex: 10,
            backgroundColor: '#1a2332ee',
            borderRadius: 1,
            p: 1.5,
            display: 'flex',
            gap: 1.5,
            flexWrap: 'wrap',
          }}
        >
          {viewLevel === 'province' ? (
            [
              { label: '紧急告警', color: '#f44336' },
              { label: '主要告警', color: '#ff9800' },
              { label: '次要告警', color: '#ffc107' },
              { label: '提示告警', color: '#2196f3' },
              { label: '无告警', color: '#4caf50' },
              { label: '省际链路', color: '#5c8aff' },
            ].map((item) => (
              <Box key={item.label} sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Box sx={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: item.color }} />
                <Typography variant="caption" sx={{ color: '#9e9e9e', fontSize: 11 }}>{item.label}</Typography>
              </Box>
            ))
          ) : (
            [
              { label: '紧急', color: '#f44336' },
              { label: '主要', color: '#ff9800' },
              { label: '次要', color: '#ffc107' },
              { label: '提示', color: '#2196f3' },
              { label: '正常', color: '#4caf50' },
              { label: '省际链路', color: '#ff9800', dash: true },
            ].map((item) => (
              <Box key={item.label} sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                {item.dash ? (
                  <Box sx={{ width: 16, height: 0, borderTop: `2px dashed ${item.color}` }} />
                ) : (
                  <Box sx={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: item.color }} />
                )}
                <Typography variant="caption" sx={{ color: '#9e9e9e', fontSize: 11 }}>{item.label}</Typography>
              </Box>
            ))
          )}
        </Box>

        <ReactFlow
          nodes={currentNodes}
          edges={currentEdges}
          onNodesChange={currentNodesChange}
          onEdgesChange={currentEdgesChange}
          onNodeClick={onNodeClick}
          nodeTypes={currentNodeTypes}
          defaultViewport={{ x: 0, y: 0, zoom: 0.55 }}
          fitView
          minZoom={0.2}
          maxZoom={3}
          defaultEdgeOptions={{ type: 'smoothstep' }}
          key={viewLevel === 'province' ? 'province' : `detail-${selectedProvince}`}
        >
          <Controls />
          <MiniMap
            nodeColor={(node) => {
              if (viewLevel === 'province') {
                const d = node.data as { alarmStats?: ProvinceAlarmStats };
                return d.alarmStats ? getProvinceBorderColor(d.alarmStats) : '#4caf50';
              }
              const d = node.data as { highestLevel: AlarmLevel | null };
              return getNeColor(d.highestLevel);
            }}
            maskColor="#0a192999"
          />
          <Background variant={BackgroundVariant.Dots} gap={16} size={1} color="#2d3d50" />
        </ReactFlow>
      </Card>

      {/* 网元告警详情弹窗（仅详情模式下点击网元时弹出） */}
      <Dialog
        open={!!selectedNe && viewLevel === 'ne'}
        onClose={() => setSelectedNe(null)}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          sx: { backgroundColor: '#1a2332', border: '1px solid #2d3d50' },
        }}
      >
        <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
            网元告警详情
          </Typography>
          <IconButton onClick={() => setSelectedNe(null)} size="small">
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent>
          {selectedNeInfo && (
            <>
              <Box sx={{ mb: 2 }}>
                <Typography variant="body2" sx={{ color: '#9e9e9e' }}>网元名称</Typography>
                <Typography variant="body1" sx={{ fontWeight: 600 }}>{selectedNeInfo.neName}</Typography>
                <Box sx={{ display: 'flex', gap: 2, mt: 1 }}>
                  <Typography variant="body2" sx={{ color: '#9e9e9e' }}>
                    类型: {selectedNeInfo.neType}
                  </Typography>
                  <Typography variant="body2" sx={{ color: '#9e9e9e' }}>
                    IP: {selectedNeInfo.ipAddress}
                  </Typography>
                  <Chip
                    label={selectedNeInfo.onlineStatus}
                    size="small"
                    color={selectedNeInfo.onlineStatus === '在线' ? 'success' : 'error'}
                    sx={{ height: 20, fontSize: 11 }}
                  />
                </Box>
              </Box>
              <Divider sx={{ borderColor: '#2d3d50', mb: 1 }} />
              <Typography variant="subtitle2" sx={{ mb: 1 }}>
                告警列表（{selectedNeAlarms.length}条）
              </Typography>
              {selectedNeAlarms.length === 0 ? (
                <Typography variant="body2" sx={{ color: '#4caf50', textAlign: 'center', py: 2 }}>
                  该网元无活动告警
                </Typography>
              ) : (
                <List dense>
                  {selectedNeAlarms.map((alarm) => (
                    <ListItem key={alarm.id} sx={{ px: 0 }}>
                      <Chip
                        label={alarm.alarmLevel}
                        size="small"
                        sx={{
                          mr: 1,
                          backgroundColor: `${ALARM_LEVEL_COLORS[alarm.alarmLevel]}22`,
                          color: ALARM_LEVEL_COLORS[alarm.alarmLevel],
                          fontWeight: 600,
                          fontSize: 11,
                          minWidth: 48,
                        }}
                      />
                      <ListItemText
                        primary={alarm.alarmTitle}
                        secondary={`${alarm.boardName} 槽位${alarm.slotNo} | ${alarm.alarmStatus}`}
                        primaryTypographyProps={{ fontSize: 13 }}
                        secondaryTypographyProps={{ fontSize: 11, color: '#9e9e9e' }}
                      />
                    </ListItem>
                  ))}
                </List>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </Box>
  );
};

export default Topology;
