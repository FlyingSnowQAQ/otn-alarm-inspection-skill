export { fibrehomeAdapter } from './fibrehome-adapter';
