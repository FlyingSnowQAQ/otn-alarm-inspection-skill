import type { DataSourceAdapter, FieldMapping, ImportResult } from '../core/adapter';
import type { CoreAlarm, CoreNE, ProvinceCoord } from '../core/types';
import { NE_PROVINCE_MAP } from '../data/neProvinceMap';
import { NE_SYSTEM_MAP, SYSTEM_NE_MAP } from '../data/neSystemMap';

// ====== 字段映射表（从 Import.tsx 迁移过来） ======

const ALARM_FIELD_AUTO_MAP: Record<string, string[]> = {
  alarmNo: ['告警序号', '序号', 'No'],
  alarmName: ['告警标题', '标题', '告警名称', '名称'],
  neName: ['网元名称', '网元'],
  neIp: ['网元IP', 'IP地址', 'IP'],
  slotNo: ['槽位号', '槽位'],
  boardName: ['盘名称', '单板', '板名'],
  portNo: ['端口号', '端口'],
  category: ['告警类型', '类型'],
  status: ['告警状态', '告警确认状态', '确认状态'],
  firstOccurTime: ['首次发生时间', '首次发生', '告警发生时间', '发生时间'],
  lastOccurTime: ['最近发生时间', '最近发生'],
  clearTime: ['告警清除时间', '清除时间', '告警消失时间', '消失时间'],
  duration: ['告警持续时长', '持续时长'],
  additionalInfo: ['附加信息', '备注', '告警原因', '原因'],
  source: ['告警源', '来源'],
};

const NE_FIELD_AUTO_MAP: Record<string, string[]> = {
  neName: ['网元名称', '网络设备名称', 'NE名称', '网元名'],
  neId: ['网元ID', 'NE ID', 'NE编号', '设备编号'],
  neType: ['网元类型', '设备型号', '类型', '设备类型', '产品型号'],
  region: ['所属区域', '区域', '片区', '大区'],
  city: ['所属城市', '城市', '地市', '所在地市'],
  logicalDomain: ['逻辑域', '域', '所属域'],
  emuType: ['EMU类型', 'EMU盘类型', '机框类型'],
  ipAddress: ['网元IP', 'IP地址', 'IP', '管理IP'],
  onlineDate: ['入网日期', '入网时间', '投产日期', '上线日期'],
  softwareVersion: ['软件版本', '版本', '版本号'],
};

// ====== 级别/类型/状态 映射 ======

const SEVERITY_MAP: Record<string, CoreAlarm['severity']> = {
  '紧急': 'critical', '紧急告警': 'critical',
  '主要': 'major', '主要告警': 'major',
  '次要': 'minor', '次要告警': 'minor',
  '提示': 'warning', '提示告警': 'warning',
};

const STATUS_MAP: Record<string, CoreAlarm['status']> = {
  '未确认未清除': 'active',
  '未确认': 'active',
  '已确认未清除': 'acknowledged',
  '已确认': 'acknowledged',
  '自动确认': 'acknowledged',
  '手动确认': 'acknowledged',
  '已确认已清除': 'cleared',
};

// ====== 省份坐标（从 Topology.tsx 的 PROVINCE_COORDS 迁移） ======

const PROVINCE_COORDS: Record<string, { x: number; y: number }> = {
  // 东北
  '黑龙江省': { x: 1300, y: 100 }, '吉林省': { x: 1270, y: 180 }, '辽宁省': { x: 1240, y: 260 },
  // 华北
  '北京市': { x: 1150, y: 220 }, '天津市': { x: 1180, y: 240 },
  '河北省': { x: 1130, y: 260 }, '山西省': { x: 1080, y: 280 },
  '内蒙古自治区': { x: 1020, y: 150 },
  // 华东
  '山东省': { x: 1180, y: 330 }, '江苏省': { x: 1220, y: 360 },
  '上海市': { x: 1250, y: 370 }, '浙江省': { x: 1220, y: 420 },
  '安徽省': { x: 1160, y: 390 }, '福建省': { x: 1200, y: 480 },
  '江西省': { x: 1140, y: 460 },
  // 华中
  '河南省': { x: 1100, y: 350 }, '湖北省': { x: 1070, y: 420 },
  '湖南省': { x: 1070, y: 500 },
  // 华南
  '广东省': { x: 1140, y: 560 }, '广西壮族自治区': { x: 1050, y: 610 },
  '海南省': { x: 1110, y: 650 },
  // 西南
  '重庆市': { x: 1000, y: 470 }, '四川省': { x: 920, y: 440 },
  '贵州省': { x: 980, y: 550 }, '云南省': { x: 850, y: 610 },
  // 西北
  '陕西省': { x: 1000, y: 340 }, '甘肃省': { x: 850, y: 270 },
  '青海省': { x: 750, y: 320 }, '宁夏回族自治区': { x: 920, y: 280 },
  '新疆维吾尔自治区': { x: 400, y: 190 },
  // 港澳台
  '香港特别行政区': { x: 1170, y: 580 }, '澳门特别行政区': { x: 1150, y: 590 },
  '台湾省': { x: 1250, y: 510 },
};

/** 从网元名称提取省份代码 */
const PROVINCE_CODE_MAP: Record<string, string> = {
  'YN': '云南省', 'GZ': '贵州省', 'SC': '四川省', 'CQ': '重庆市',
  'QH': '青海省', 'SN': '陕西省', 'XJ': '新疆维吾尔自治区',
  'GS': '甘肃省', 'NX': '宁夏回族自治区', 'GX': '广西壮族自治区',
  'XZ': '西藏自治区', 'HE': '河北省', 'TJ': '天津市',
  'HL': '黑龙江省', 'BJ': '北京市', 'LN': '辽宁省',
  'NM': '内蒙古自治区', 'JL': '吉林省', 'SX': '山西省',
  'HB': '湖北省', 'HN': '湖南省', 'HA': '河南省', 'GD': '广东省',
};

// ====== 烽火适配器实现 ======

export const fibrehomeAdapter: DataSourceAdapter = {
  vendor: 'fibrehome',
  name: '烽火通信 FONST 网管报表',
  version: '1.0',

  autoDetectMapping(headers: string[], type: 'alarm' | 'ne'): FieldMapping[] {
    const fieldMap = type === 'ne' ? NE_FIELD_AUTO_MAP : ALARM_FIELD_AUTO_MAP;
    return headers.map((header) => {
      for (const [field, keywords] of Object.entries(fieldMap)) {
        if (keywords.some((kw) => header.includes(kw))) {
          return { sourceColumn: header, targetField: field };
        }
      }
      return { sourceColumn: header, targetField: '' };
    });
  },

  parseAlarms(rows: string[][], mapping: FieldMapping[]): ImportResult<CoreAlarm> {
    const fieldToIndex: Record<string, number> = {};
    mapping.forEach((m, i) => { if (m.targetField) fieldToIndex[m.targetField] = i; });

    const getVal = (field: string, row: string[]): string =>
      fieldToIndex[field] !== undefined ? String(row[fieldToIndex[field]] || '').trim() : '';

    const records: CoreAlarm[] = [];
    const errors: { row: number; message: string }[] = [];

    rows.forEach((row, i) => {
      try {
        const neNameVal = getVal('neName', row);
        if (!neNameVal) { errors.push({ row: i, message: '网元名称为空' }); return; }

        const rawLevel = getVal('alarmLevel', row);
        const rawStatus = getVal('status', row) || getVal('alarmStatus', row);

        const alarm: CoreAlarm = {
          id: `core-${Date.now()}-${i}`,
          alarmName: getVal('alarmName', row),
          neName: neNameVal,
          severity: SEVERITY_MAP[rawLevel] || 'major',
          firstOccurTime: getVal('firstOccurTime', row),
          lastOccurTime: getVal('lastOccurTime', row) || getVal('firstOccurTime', row),
          clearTime: getVal('clearTime', row) || undefined,
          status: STATUS_MAP[rawStatus] || 'active',
          neIp: getVal('neIp', row) || undefined,
          slotNo: getVal('slotNo', row) || undefined,
          boardName: getVal('boardName', row) || undefined,
          portNo: getVal('portNo', row) || undefined,
          duration: getVal('duration', row) || undefined,
          source: getVal('source', row) || undefined,
          category: getVal('category', row) || undefined,
          additionalInfo: getVal('additionalInfo', row) || undefined,
          province: this.resolveProvince?.(neNameVal) || '',
          extensions: {},
        };
        records.push(alarm);
      } catch {
        errors.push({ row: i, message: '解析异常' });
      }
    });

    return {
      records,
      errors,
      stats: { total: rows.length, success: records.length, failed: errors.length },
    };
  },

  parseNetworkElements(rows: string[][], mapping: FieldMapping[]): ImportResult<CoreNE> {
    const fieldToIndex: Record<string, number> = {};
    mapping.forEach((m, i) => { if (m.targetField) fieldToIndex[m.targetField] = i; });

    const getVal = (field: string, row: string[]): string =>
      fieldToIndex[field] !== undefined ? String(row[fieldToIndex[field]] || '').trim() : '';

    const records: CoreNE[] = [];
    const errors: { row: number; message: string }[] = [];

    rows.forEach((row, i) => {
      try {
        const neNameVal = getVal('neName', row);
        if (!neNameVal) { errors.push({ row: i, message: '网元名称为空' }); return; }

        const regionVal = getVal('region', row);
        let provinceVal = '';
        let cityVal = '';
        if (regionVal) {
          const parts = regionVal.split('-');
          if (parts.length >= 1) provinceVal = parts[0].trim();
          if (parts.length >= 2) cityVal = parts[1].trim();
        }

        const onlineStatusRaw = getVal('onlineStatus', row);
        const onlineStatus: CoreNE['onlineStatus'] =
          (onlineStatusRaw === '在线' || onlineStatusRaw === '在线态') ? 'online' : 'offline';

        const ne: CoreNE = {
          id: `core-ne-${Date.now()}-${i}`,
          neName: neNameVal,
          neType: getVal('neType', row) || 'FONST',
          region: provinceVal || undefined,
          city: cityVal || undefined,
          ipAddress: getVal('ipAddress', row) || undefined,
          onlineStatus,
          onlineDate: getVal('onlineDate', row) || undefined,
          softwareVersion: getVal('softwareVersion', row) || undefined,
          transportSystems: this.resolveTransportSystems?.(neNameVal) || undefined,
          extensions: {},
        };
        records.push(ne);
      } catch {
        errors.push({ row: i, message: '解析异常' });
      }
    });

    return {
      records,
      errors,
      stats: { total: rows.length, success: records.length, failed: errors.length },
    };
  },

  getProvinces(): ProvinceCoord[] {
    const provinceCodeReverse: Record<string, string> = {};
    for (const [code, name] of Object.entries(PROVINCE_CODE_MAP)) {
      provinceCodeReverse[name] = code;
    }
    return Object.entries(PROVINCE_COORDS).map(([name, coord]) => ({
      name,
      shortCode: provinceCodeReverse[name] || '',
      coordX: coord.x,
      coordY: coord.y,
    }));
  },

  resolveProvince(neName: string): string | undefined {
    // 1. 先查 NE_PROVINCE_MAP
    if (NE_PROVINCE_MAP[neName]) {
      const raw = NE_PROVINCE_MAP[neName];
      // 去掉括号代码
      return raw.replace(/\([A-Z]+\)$/, '');
    }
    // 2. 从名称提取省份代码
    const match = neName.match(/^N-\d+-(YN|GZ|SC|CQ|QH|SN|XJ|GS|NX|GX|XZ|HE|TJ|HL|BJ|LN|NM|JL|SX|HB|HN|HA|GD)/);
    if (match) return PROVINCE_CODE_MAP[match[1]];
    return undefined;
  },

  resolveTransportSystems(neName: string): string[] | undefined {
    const result = NE_SYSTEM_MAP[neName];
    return result ? [...result] : undefined;
  },
};
