/** 告警级别枚举 */
export type AlarmLevel = '紧急' | '主要' | '次要' | '提示';

/** 告警类型枚举 */
export type AlarmType = '通信告警' | '设备告警' | '处理错误告警' | '环境告警' | '服务质量告警';

/** 告警状态枚举 */
export type AlarmStatus = '未确认未清除' | '已确认未清除' | '已确认已清除' | '未确认' | '自动确认';

/** 告警逻辑分类 */
export type AlarmLogicCategory = '通信' | '设备' | '维护';

/** 告警逻辑子类 */
export type AlarmLogicSubCategory = '通道' | '端口' | '硬件' | '数据配置' | '操作告警' | '性能';

/** 网元类型 */
export type NeType = 'FONST 6000 N32' | 'FONST COTP_POTN' | 'FONST COTP M';

/** 网元在线状态 */
export type NeOnlineStatus = '在线' | '离线' | '未知';

/** 维护状态 */
export type MaintenanceStatus = '正常' | '维护中' | '停用';

/** 网元数据接口 */
export interface NetworkElement {
  id: string;
  logicalDomain: string;
  neName: string;
  neId: string;
  neType: NeType;
  region: string;
  province: string;
  city: string;
  emuType: string;
  ipAddress: string;
  onlineDate: string;
  userLabel: string;
  sn: string;
  maintenanceStatus: MaintenanceStatus;
  switchNo1: string;
  switchNo2: string;
  onlineStatus: NeOnlineStatus;
  softwareVersion: string;
  friendlyName: string;
  createTime: string;
  createUser: string;
  physicalLocation: string;
  remark: string;
  transportSystem: string;
  isSuperRing: boolean;
  isSuperLongLink: boolean;
  ringType: string;
  equivalentCoefficient: number;
  crossCapacity: number;
  channelType: string;
}

/** 告警数据接口 */
export interface AlarmRecord {
  id: string;
  alarmNo: number;
  alarmTitle: string;
  alarmName: string;
  alarmLevel: AlarmLevel;
  neName: string;
  province: string;
  neIp: string;
  slotNo: string;
  boardName: string;
  portNo: string;
  alarmType: AlarmType;
  alarmStatus: AlarmStatus;
  firstOccurTime: string;
  lastOccurTime: string;
  clearTime: string;
  duration: string;
  confirmOperator: string;
  ruisikangConfirmTime: string;
  confirmTime: string;
  clearOperator: string;
  ruisikangClearTime: string;
  additionalInfo: string;
  alarmSource: string;
}

/** 告警类型定义接口 */
export interface AlarmTypeDefinition {
  id: string;
  vendor: string;
  alarmObjectType: string;
  alarmTitle: string;
  alarmStandardName: string;
  vendorAlarmLevel: AlarmLevel;
  alarmType: string;
  equipmentBoard: string;
  nmAlarmLevel: AlarmLevel;
  alarmExplanation: string;
  alarmLogicCategory: AlarmLogicCategory;
  alarmLogicSubCategory: AlarmLogicSubCategory;
  equipmentImpact: string;
  businessImpact: string;
}

/** 页面路由 */
export type PageRoute = 'dashboard' | 'topology' | 'analysis' | 'import' | 'report' | 'projects' | 'inspection-report';

// ==============================
// V1.1 新增类型
// ==============================

/** 项目元数据 */
export interface ProjectMeta {
  id: string;            // UUID
  name: string;          // 项目名称
  createdAt: string;     // ISO 8601
  updatedAt: string;     // ISO 8601
  alarmCount: number;    // 当前告警总数
  neCount: number;       // 当前网元总数
  dataSizeBytes: number; // 数据占用字节数（近似）
}

/** 告警风暴严重程度 */
export type AlarmStormSeverity = 'storm' | 'cluster' | 'scattered';

/** 告警聚合组 */
export interface AlarmGroup {
  id: string;
  neName: string;
  boardName: string;
  slotNo: string;
  windowStart: string;
  windowEnd: string;
  alarms: AlarmRecord[];
  rootCauseAlarm: AlarmRecord;
  rootCauseScore: number;
  severity: AlarmStormSeverity;
  derivedCount: number;
  /** 告警传播链描述（如: 输入光丢失(紧急) → 帧丢失(紧急) → 告警指示(紧急)） */
  propagationChain?: string;
  /** 不同衍生告警标题的种类数 */
  uniqueDerivedTypes?: number;
  /** 拓扑分析摘要（如: 【传输系统影响】昆明-曲靖-宣威400G系统 共 3 个站点受影响） */
  topologySummary?: string;
}

/** 聚合视图模式 */
export type AggregationViewMode = 'aggregated' | 'detail';

/** 时间窗口选项 */
export type TimeWindowMinutes = 5 | 15 | 30 | 60;

/** 报告元数据 */
export interface ReportMeta {
  title: string;
  period: string;
  author: string;
  department: string;
  reportDate: string;
}

/** 报告章节数据 */
export interface ReportData {
  meta: ReportMeta;
  summaryStats: {
    totalAlarms: number;
    activeAlarms: number;
    clearedAlarms: number;
    clearanceRate: string;
    totalNEs: number;
    onlineNEs: number;
  };
  levelDistribution: { level: AlarmLevel; total: number; active: number; cleared: number }[];
  provinceDistribution: { name: string; value: number }[];
  alarmTrend: { date: string; 紧急: number; 主要: number; 次要: number; 提示: number }[];
  topStormNEs: AlarmGroup[];
  topAlarmNEs: { neName: string; count: number; critical: number }[];
  conclusions: string;
}

/** 告警级别颜色映射 */
export const ALARM_LEVEL_COLORS: Record<AlarmLevel, string> = {
  '紧急': '#f44336',
  '主要': '#ff9800',
  '次要': '#ffc107',
  '提示': '#2196f3',
};

/** 告警级别数值映射（用于排序） */
export const ALARM_LEVEL_ORDER: Record<AlarmLevel, number> = {
  '紧急': 4,
  '主要': 3,
  '次要': 2,
  '提示': 1,
};

/** 告警级别对应MUI颜色 */
export const ALARM_LEVEL_MUI_COLOR: Record<AlarmLevel, 'error' | 'warning' | 'info' | 'success'> = {
  '紧急': 'error',
  '主要': 'warning',
  '次要': 'info',
  '提示': 'success',
};

/** 列映射配置 */
export interface ColumnMapping {
  sourceColumn: string;
  targetField: string;
}

/** 导入预览数据 */
export interface ImportPreview {
  headers: string[];
  rows: string[][];
  columnMappings: ColumnMapping[];
}

/** @deprecated 建议迁移至 src/core/types.ts 的 CoreAlarm */
export type _LegacyAlarm = AlarmRecord;
/** @deprecated 建议迁移至 src/core/types.ts 的 CoreNE */
export type _LegacyNE = NetworkElement;
