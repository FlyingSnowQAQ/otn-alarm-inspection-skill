import type { DataSourceAdapter } from './adapter';

/** 数据源注册表 — 全局单例 */
export class DataSourceRegistry {
  private static instance: DataSourceRegistry;
  private adapters: Map<string, DataSourceAdapter> = new Map();

  static getInstance(): DataSourceRegistry {
    if (!DataSourceRegistry.instance) {
      DataSourceRegistry.instance = new DataSourceRegistry();
    }
    return DataSourceRegistry.instance;
  }

  register(adapter: DataSourceAdapter): void {
    this.adapters.set(adapter.vendor, adapter);
  }

  getAdapter(vendor: string): DataSourceAdapter | undefined {
    return this.adapters.get(vendor);
  }

  getAllAdapters(): DataSourceAdapter[] {
    return Array.from(this.adapters.values());
  }

  unregister(vendor: string): void {
    this.adapters.delete(vendor);
  }
}
