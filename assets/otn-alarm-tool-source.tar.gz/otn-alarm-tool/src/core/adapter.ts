import type { CoreAlarm, CoreNE, ProvinceCoord } from './types';

/** 列映射 */
export interface FieldMapping {
  sourceColumn: string;
  targetField: string;
}

/** 导入结果 */
export interface ImportResult<T> {
  records: T[];
  errors: { row: number; message: string }[];
  stats: { total: number; success: number; failed: number };
}

/**
 * 数据源适配器接口
 * 每个厂商实现此接口
 */
export interface DataSourceAdapter {
  /** 厂商标识 */
  vendor: string;
  /** 适配器名称 */
  name: string;
  /** 适配器版本 */
  version: string;

  /** 从原始行数据解析为 CoreAlarm 数组 */
  parseAlarms(rows: string[][], mapping: FieldMapping[]): ImportResult<CoreAlarm>;

  /** 从原始行数据解析为 CoreNE 数组 */
  parseNetworkElements(rows: string[][], mapping: FieldMapping[]): ImportResult<CoreNE>;

  /** 智能识别列映射 */
  autoDetectMapping(headers: string[], type: 'alarm' | 'ne'): FieldMapping[];

  /** 获取省份坐标列表（用于拓扑图） */
  getProvinces(): ProvinceCoord[];

  /** 根据网元名称解析省份 */
  resolveProvince?(neName: string): string | undefined;

  /** 根据网元名称解析传输系统 */
  resolveTransportSystems?(neName: string): string[] | undefined;
}
