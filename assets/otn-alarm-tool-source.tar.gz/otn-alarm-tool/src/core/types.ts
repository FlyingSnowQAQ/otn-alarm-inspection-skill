/** 核心告警严重程度 */
export type CoreAlarmSeverity = 'critical' | 'major' | 'minor' | 'warning';

/** 核心告警生命周期状态 */
export type CoreAlarmStatus = 'active' | 'acknowledged' | 'cleared';

/** 核心告警记录 — 最小通用字段集 */
export interface CoreAlarm {
  id: string;
  alarmName: string;
  neName: string;
  severity: CoreAlarmSeverity;
  neIp?: string;
  slotNo?: string;
  boardName?: string;
  portNo?: string;
  firstOccurTime: string;
  lastOccurTime: string;
  clearTime?: string;
  status: CoreAlarmStatus;
  duration?: string;
  source?: string;
  category?: string;
  additionalInfo?: string;
  /** 厂商专有扩展字段 */
  extensions?: Record<string, unknown>;
  /** 省份（由导入时根据数据源上下文填充） */
  province?: string;
}

/** 核心网元数据 — 最小通用字段集 */
export interface CoreNE {
  id: string;
  neName: string;
  neType: string;
  region?: string;
  city?: string;
  ipAddress?: string;
  onlineStatus: 'online' | 'offline' | 'unknown';
  transportSystems?: string[];
  onlineDate?: string;
  softwareVersion?: string;
  /** 厂商专有扩展字段 */
  extensions?: Record<string, unknown>;
}

/** 地域坐标定义（用于拓扑图） */
export interface ProvinceCoord {
  name: string;
  shortCode?: string;
  coordX: number;
  coordY: number;
}
