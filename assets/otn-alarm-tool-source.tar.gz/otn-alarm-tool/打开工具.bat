@echo off
title OTN告警工具
cd /d "%~dp0"

echo ========================================
echo   OTN 告警可视化巡检工具
echo   正在启动...
echo ========================================

:: 方法1：先试双击打开HTML（如果浏览器支持）
start "" "dist\index.html"

:: 方法2：同时启动本地服务器（更可靠）
start /min node scripts\server.js

:: 等1秒让服务器启动
ping 127.0.0.1 -n 2 >nul

:: 打开服务器地址
start http://localhost:8899

echo.
echo 已打开工具，关掉这个窗口不会影响使用。
echo 用完双击「停止工具.bat」释放端口~
echo.
pause
