# OTN 历史告警可视化巡检工具 — 模块化架构重构设计

> 版本：v1.0  
> 日期：2026-06-17  
> 状态：草案

---

## 目录

1. [现状分析](#1-现状分析)
2. [核心数据类型设计](#2-核心数据类型设计)
3. [Adapter 接口定义](#3-adapter-接口定义)
4. [数据流变化](#4-数据流变化)
5. [文件新增/修改清单](#5-文件新增修改清单)
6. [实施步骤（3 阶段）](#6-实施步骤3-阶段)
7. [风险点与缓解措施](#7-风险点与缓解措施)

---

## 1. 现状分析

### 1.1 当前架构中的硬编码依赖

| # | 硬编码项 | 位置 | 影响 |
|---|---------|------|------|
| 1 | 列映射规则（告警字段→XLS列名） | `Import.tsx` L44-L67 | 只认烽火网管导出格式 |
| 2 | 列映射规则（网元字段→XLS列名） | `Import.tsx` L96-L115 | 同上 |
| 3 | 级别/类型/状态值映射表 | `Import.tsx` L140-L168 | 烽火特有的枚举值 |
| 4 | 省份坐标布局（PROVINCE_COORDS） | `Topology.tsx` L137-L212 | 只适用于中国省份地图 |
| 5 | NE→省份映射（2469 条） | `neProvinceMap.ts` | 烽火网元命名规则 |
| 6 | NE→传输系统映射（905 条） | `neSystemMap.ts` | 烽火一干系统 |
| 7 | NE 类型枚举（NeType） | `types/index.ts` L17-L18 | 只含 FONST 型号 |
| 8 | mockData | `mockData.ts` | 烽火格式数据 |
| 9 | 拓扑链路数据 | `mockData.ts`（mockTopologyLinks） | 烽火一干链路 |
| 10 | 告警类型定义 | `types/index.ts` L88-L103 | 含烽火专用字段 |

### 1.2 核心矛盾

**数据类型耦合**：`AlarmRecord` 携带 `ruisikangConfirmTime`、`ruisikangClearTime` 等厂商专有字段，而 `NeType` 只限于烽火的三种型号。  
**数据查询耦合**：`NE_PROVINCE_MAP`、`NE_SYSTEM_MAP` 是基于烽火 NE 命名规范的硬编码 Lookup Table。  
**展示逻辑耦合**：`PROVINCE_COORDS` 假设所有省份都是中国省级行政区。

---

## 2. 核心数据类型设计

### 2.1 设计原则

- **最小通用字段集**：只保留所有 OTN 厂商都能映射的字段
- **扩展字段容器**：厂商特有数据通过 `extensions`（`Record<string, unknown>`）携带
- **向下兼容**：新 Core 类型可以从旧类型无损转换

### 2.2 CoreAlarm — 核心告警

```typescript
// src/core/types.ts（新文件）

/** 严重程度枚举（跨厂商通用，4 级制） */
export type CoreAlarmSeverity = 'critical' | 'major' | 'minor' | 'warning';

/** 告警生命周期状态 */
export type CoreAlarmStatus = 'active' | 'acknowledged' | 'cleared';

/** 核心告警记录 — 最小通用字段集（15 字段） */
export interface CoreAlarm {
  /** 全局唯一 ID */
  id: string;

  // ── 辨识字段 ──
  /** 告警名称/标题（原文） */
  alarmName: string;
  /** 所属网元名称 */
  neName: string;
  /** 告警严重程度 */
  severity: CoreAlarmSeverity;

  // ── 定位字段 ──
  /** 网元 IP */
  neIp?: string;
  /** 槽位号 */
  slotNo?: string;
  /** 单盘名称 */
  boardName?: string;
  /** 端口号 */
  portNo?: string;

  // ── 时间字段 ──
  /** 首次发生时间（ISO 8601） */
  firstOccurTime: string;
  /** 最近发生时间 */
  lastOccurTime: string;
  /** 清除时间（cleared 状态时有值） */
  clearTime?: string;

  // ── 生命周期 ──
  /** 告警状态 */
  status: CoreAlarmStatus;
  /** 告警持续时长（原始字符串，如 "02:30:15"） */
  duration?: string;

  // ── 上下文 ──
  /** 告警源描述 */
  source?: string;
  /** 告警类型分类 */
  category?: string;
  /** 附加信息/备注 */
  additionalInfo?: string;

  // ── 扩展字段（厂商专有数据）──
  extensions?: Record<string, unknown>;
}
```

**对比：CoreAlarm（15 字段） vs AlarmRecord（26 字段）**

| AlarmRecord 字段 | CoreAlarm 字段 | 处理方式 |
|-----------------|---------------|---------|
| `alarmNo` | — | 移至 extensions |
| `alarmTitle` | `alarmName` | 合并 |
| `alarmName` | — | 合并入 `alarmName` |
| `alarmLevel` | `severity` | 4→4 映射（紧急→critical 等） |
| `neName` | `neName` | 保留 |
| `province` | — | 移除外层，由 DataSourceContext 提供 |
| `neIp` | `neIp` | 保留 |
| `slotNo` | `slotNo` | 保留 |
| `boardName` | `boardName` | 保留 |
| `portNo` | `portNo` | 保留 |
| `alarmType` | `category` | 语义映射 |
| `alarmStatus` | `status` | 5→3 压缩（见下文） |
| `firstOccurTime` | `firstOccurTime` | 保留 |
| `lastOccurTime` | `lastOccurTime` | 保留 |
| `clearTime` | `clearTime` | 保留 |
| `duration` | `duration` | 保留 |
| `confirmOperator` | — | 移至 extensions |
| `ruisikangConfirmTime` | — | 移至 extensions，改为通用字段名 `vendorExt.confirmTime` |
| `confirmTime` | — | 移至 extensions |
| `clearOperator` | — | 移至 extensions |
| `ruisikangClearTime` | — | 移至 extensions |
| `additionalInfo` | `additionalInfo` | 保留 |
| `alarmSource` | `source` | 重命名 |

**AlarmStatus → CoreAlarmStatus 映射规则**：

```
"未确认未清除" / "未确认"  →  "active"
"已确认未清除" / "自动确认" →  "acknowledged"
"已确认已清除"              →  "cleared"
```

### 2.3 CoreNE — 核心网元

```typescript
// src/core/types.ts（续）

/** 网元在线状态（跨厂商通用） */
export type CoreNeOnlineStatus = 'online' | 'offline' | 'unknown';

/** 核心网元数据 — 最小通用字段集（12 字段） */
export interface CoreNE {
  /** 全局唯一 ID */
  id: string;

  // ── 辨识字段 ──
  /** 网元名称 */
  neName: string;
  /** 网元类型/型号原文（如 "FONST 6000 N32", "OSN 9800"） */
  neType: string;

  // ── 位置字段 ──
  /** 省份/区域 */
  region?: string;
  /** 城市 */
  city?: string;
  /** 经纬度（可选，用于拓扑地理分布） */
  latitude?: number;
  longitude?: number;

  // ── 网络字段 ──
  /** 管理 IP */
  ipAddress?: string;
  /** 在线状态 */
  onlineStatus: CoreNeOnlineStatus;

  // ── 管理字段 ──
  /** 所属传输系统列表 */
  transportSystems?: string[];
  /** 入网日期 */
  onlineDate?: string;
  /** 软件版本 */
  softwareVersion?: string;

  // ── 扩展字段 ──
  extensions?: Record<string, unknown>;
}
```

**对比：CoreNE（12+字段） vs NetworkElement（29+字段）**

丢弃字段：`neId`、`emuType`、`userLabel`、`sn`、`maintenanceStatus`、`switchNo1/2`、`friendlyName`、`createTime/User`、`physicalLocation`、`remark`、`isSuperRing`、`isSuperLongLink`、`ringType`、`equivalentCoefficient`、`crossCapacity`、`channelType` — 全部移入 `extensions`。

### 2.4 数据源上下文

```typescript
// src/core/types.ts（续）

/** 数据源供应商标识 */
export type Vendor = 'fibrehome' | 'huawei' | 'zte' | 'coriant' | 'generic';

/** 数据源陈述（DataSourceManifest）—— 一个数据源实例的声明 */
export interface DataSourceManifest {
  /** 数据源唯一 ID */
  id: string;
  /** 数据源名称（用户自定义，如 "云南一干400G"） */
  name: string;
  /** 厂商标识 */
  vendor: Vendor;
  /** 适配器模块名（用于动态加载） */
  adapterModule: string;
  /** 适配器版本 */
  adapterVersion: string;
  /** 创建时间 */
  createdAt: string;
  /** 该数据源定义的省份列表（用于拓扑展示） */
  provinces?: DataSourceProvince[];
  /** 该数据源定义的传输系统列表 */
  transportSystems?: string[];
}

/** 数据源地域定义 */
export interface DataSourceProvince {
  name: string;         // 如 "云南省"
  shortCode?: string;   // 如 "YN"
  coordX: number;       // 拓扑图 X 坐标
  coordY: number;       // 拓扑图 Y 坐标
}
```

### 2.5 数据源配置存储（IndexedDB 扩展）

```typescript
// src/core/types.ts（续）

/** 用户保存的数据源配置 */
export interface DataSourceConfig {
  id: string;
  manifestId: string;
  name: string;
  vendor: Vendor;
  enabled: boolean;
  /** 列映射规则（导入时使用） */
  columnMapping: Record<string, string>;  // sourceColumn → targetField
  /** 值映射规则（如级别映射） */
  valueMapping?: {
    [field: string]: Record<string, string>;  // sourceValue → targetValue
  };
  createdAt: string;
  updatedAt: string;
}
```

---

## 3. Adapter 接口定义

### 3.1 核心接口

```typescript
// src/core/adapter.ts（新文件）

import type { CoreAlarm, CoreNE, DataSourceManifest, Vendor } from './types';

/** 列映射描述：源列名 → 目标 Core 字段 */
export interface FieldMapping {
  sourceColumn: string;
  targetField: string;
  /** 可选的值转换映射 */
  valueMap?: Record<string, string>;
}

/** 适配器能力声明 */
export interface AdapterCapabilities {
  /** 支持导入的数据类型 */
  supportedTypes: ('alarm' | 'ne')[];
  /** 是否支持动态列映射配置 */
  supportsCustomMapping: boolean;
  /** 是否支持文件拖拽导入 */
  supportsFileImport: boolean;
  /** 是否支持 API 导入 */
  supportsApiImport: boolean;
}

/** 适配器元数据 */
export interface AdapterMeta {
  vendor: Vendor;
  name: string;
  version: string;
  description: string;
  capabilities: AdapterCapabilities;
  /** 默认的告警列映射（当用户未自定义时使用） */
  defaultAlarmMapping?: FieldMapping[];
  /** 默认的网元列映射 */
  defaultNEMapping?: FieldMapping[];
}

/** 导入结果 */
export interface ImportResult<T> {
  records: T[];
  errors: ImportError[];
  stats: {
    total: number;
    success: number;
    failed: number;
  };
}

export interface ImportError {
  row: number;
  message: string;
  rawData?: string[];
}

/**
 * ======== 数据源适配器接口 ========
 *
 * 每个厂商/数据源实现此接口，注册后 App 通过 DataSourceRegistry 按需调用。
 */
export interface DataSourceAdapter {
  /** 适配器元数据 */
  meta: AdapterMeta;

  // ── 导入方法 ──

  /**
   * 从原始行数据转换为 CoreAlarm 数组
   * @param rows 解析后的 CSV/XLS 行数据（每行为字符串数组）
   * @param mapping 用户自定义/自动识别的列映射
   */
  parseAlarms(rows: string[][], mapping: FieldMapping[]): ImportResult<CoreAlarm>;

  /**
   * 从原始行数据转换为 CoreNE 数组
   */
  parseNetworkElements(rows: string[][], mapping: FieldMapping[]): ImportResult<CoreNE>;

  // ── 列映射（可选） ──

  /**
   * 智能识别列映射：从文件表头推断每列对应的 Core 字段
   * @param headers 文件表头（第一行）
   */
  autoDetectMapping(headers: string[]): FieldMapping[];

  // ── 数据源上下文（可选） ──

  /**
   * 获取数据源的省份定义
   * 用于拓扑视图中绘制地图布局
   */
  getProvinces?(): DataSourceProvince[];

  /**
   * 获取数据源的传输系统列表
   */
  getTransportSystems?(): string[];

  /**
   * 根据网元名称获取省份
   * 用于导入时自动填充 alarm.province
   */
  resolveProvince?(neName: string): string | undefined;

  /**
   * 根据网元名称获取传输系统列表
   */
  resolveTransportSystems?(neName: string): string[] | undefined;
}
```

### 3.2 数据源注册表

```typescript
// src/core/registry.ts（新文件）

import type { DataSourceAdapter, AdapterMeta } from './adapter';

/**
 * ======== 数据源注册表 ========
 *
 * 全局单例，管理所有已注册的适配器。
 * 内置适配器（烽火）在应用启动时自动注册。
 * 外部适配器由用户在界面上配置加载。
 */
export class DataSourceRegistry {
  private static instance: DataSourceRegistry;
  private adapters: Map<string, DataSourceAdapter> = new Map();

  static getInstance(): DataSourceRegistry { ... }

  /** 注册一个适配器 */
  register(adapter: DataSourceAdapter): void;

  /** 按 vendor 获取适配器 */
  getAdapter(vendor: string): DataSourceAdapter | undefined;

  /** 获取所有已注册的适配器元数据 */
  getAllMeta(): AdapterMeta[];

  /** 移除适配器 */
  unregister(vendor: string): void;

  /** 从远程 URL 加载外部适配器（动态导入） */
  async loadExternalAdapter(url: string): Promise<AdapterMeta>;
}
```

### 3.3 内置适配器示例：烽火

```typescript
// src/adapters/fibrehome-adapter.ts（新文件，从现有 Import.tsx 逻辑提取）

/**
 * 烽火 FONST 网管报表适配器
 *
 * 功能：
 * - 解析烽火告警查询报表 XLS 文件
 * - 解析烽火网元查询报表 XLS 文件
 * - NE_PROVINCE_MAP / NE_SYSTEM_MAP 作为内置 Lookup Table 保留在此适配器内
 * - PROVINCE_COORDS → 迁移到 getProvinces()
 */
export class FibreHomeAdapter implements DataSourceAdapter {
  meta: AdapterMeta = {
    vendor: 'fibrehome',
    name: '烽火通信 FONST 网管报表',
    version: '1.0',
    description: '支持烽火 FONST 6000/COTP 系列网管导出的告警查询报表和网元查询报表',
    capabilities: {
      supportedTypes: ['alarm', 'ne'],
      supportsCustomMapping: true,
      supportsFileImport: true,
      supportsApiImport: false,
    },
    defaultAlarmMapping: [
      { sourceColumn: '告警序号', targetField: 'alarmNo' },
      { sourceColumn: '告警标题', targetField: 'alarmName' },
      // ...（从 FIELD_AUTO_MAP 转化而来）
    ],
    defaultNEMapping: [
      { sourceColumn: '网元名称', targetField: 'neName' },
      // ...（从 NE_FIELD_AUTO_MAP 转化而来）
    ],
  };

  parseAlarms(rows: string[][], mapping: FieldMapping[]): ImportResult<CoreAlarm> { ... }
  parseNetworkElements(rows: string[][], mapping: FieldMapping[]): ImportResult<CoreNE> { ... }
  autoDetectMapping(headers: string[]): FieldMapping[] { ... }

  getProvinces(): DataSourceProvince[] {
    // 从当前的 PROVINCE_COORDS 转化而来
    return [
      { name: '黑龙江省', shortCode: 'HL', coordX: 1300, coordY: 100 },
      // ...全部 34 个省份
    ];
  }

  resolveProvince(neName: string): string | undefined {
    return NE_PROVINCE_MAP[neName] || getProvinceFromCode(neName);
  }

  resolveTransportSystems(neName: string): string[] | undefined {
    return NE_SYSTEM_MAP[neName];
  }
}
```

### 3.4 简化架构图

```
┌─────────────────────────────────────────────────────┐
│                    UI Layer                          │
│  Import.tsx  Topology.tsx  Dashboard.tsx ...         │
│  (通过 DataSourceAdapter + CoreAlarm/CoreNE 工作)    │
├─────────────────────────────────────────────────────┤
│                   Store Layer                        │
│  useAppStore.ts (已适配 CoreAlarm[] / CoreNE[])       │
├─────────────────┬───────────────────────────────────┤
│  Core Layer     │  DataSourceRegistry                │
│  core/types.ts  │  ┌──────────────────────────────┐  │
│  core/adapter.ts│  │ fibrehome (内置, 注册时加载) │  │
│  core/registry.ts│ │ huawei    (外部, 按需加载)    │  │
│                 │  │ zte       (外部, 用户配置)    │  │
│                 │  └──────────────────────────────┘  │
├─────────────────┴───────────────────────────────────┤
│                   Persistence Layer                  │
│  db/index.ts (IndexedDB — 存储 CoreAlarm[] / CoreNE[])│
└─────────────────────────────────────────────────────┘
```

---

## 4. 数据流变化

### 4.1 当前数据流（重构前）

```
用户选择 XLS 文件
    │
    ▼
Import.tsx 读取文件
    │
    ▼
FIELD_AUTO_MAP 硬编码列匹配
LEVEL_MAP / TYPE_MAP / STATUS_MAP 硬编码值映射
NE_PROVINCE_MAP 硬编码省份查询
    │
    ▼
new AlarmRecord({ ruisikangConfirmTime, ... })  ← 烽火格式
    │
    ▼
useAppStore.addAlarms(newAlarms)  ← 直接存储烽火特定类型
    │
    ▼
Topology.tsx 用 PROVINCE_COORDS 硬编码坐标布局
alarmAggregator.ts 用 NE_SYSTEM_MAP 硬编码查传输系统
```

### 4.2 新数据流（重构后）

```
用户选择 XLS 文件
    │
    ▼
Import.tsx → 读取文件 → 获取原始行数据 (string[][])
    │
    ▼
用户选择/配置「数据源」（如烽火、华为、中兴）
    │
    ▼
DataSourceRegistry.getAdapter('fibrehome')
    │
    ▼
列映射有两种方式：
  ├─ 自动匹配：adapter.autoDetectMapping(headers)
  └─ 用户手动调整（保存在 DataSourceConfig.columnMapping）
    │
    ▼
adapter.parseAlarms(rows, mapping)
    │
    ▼
ImportResult<CoreAlarm>  ← 标准化的核心类型
    │
    ▼
useAppStore.addCoreAlarms(newCoreAlarms)  ← 存储标准化数据
    │
    ▼
各页面通过 CoreAlarm / CoreNE 工作：
  ├─ Topology.tsx 通过 adapter.getProvinces() 获取坐标布局
  ├─ alarmAggregator.ts 通过 adapter.resolveTransportSystems() 查系统
  └─ Dashboard/Analysis 不关心厂商，直接用 CoreAlarm 字段
```

### 4.3 新旧对比总结

| 维度 | 当前架构 | 新架构 |
|------|---------|--------|
| 数据类型 | AlarmRecord（26 字段，含厂商专有） | CoreAlarm（15 通用 + extensions） |
| 厂商耦合 | 紧耦合（NeType 枚举限定烽火） | 松耦合（vendor 在运行时确定） |
| 列映射 | 硬编码在 Import.tsx | 适配器各自维护 |
| 省份坐标 | 全局硬编码 PROVINCE_COORDS | 适配器提供，每个数据源可自定义 |
| NE 映射表 | 全局硬编码 neProvinceMap/neSystemMap | 封装在适配器内部 |
| 新增厂商 | 需改源码 | 编写适配器 + 注册 |
| 拓扑展示 | 只能展示中国省份 | 适配器自定义坐标系/地域 |

---

## 5. 文件新增/修改清单

按实施顺序排列（行号可作为开发时的参考定位，但实现时以功能为准）：

### 第一阶段：核心层建立

| # | 操作 | 文件路径 | 说明 |
|---|------|---------|------|
| 1 | **新增** | `src/core/types.ts` | CoreAlarm、CoreNE、DataSourceManifest、DataSourceProvince 等类型定义 |
| 2 | **新增** | `src/core/adapter.ts` | DataSourceAdapter 接口、FieldMapping、ImportResult、ImportError、AdapterMeta |
| 3 | **新增** | `src/core/registry.ts` | DataSourceRegistry 单例（注册/获取/卸载适配器） |
| 4 | **新增** | `src/core/index.ts` | Barrel export |

### 第二阶段：内置适配器迁移 + 存储适配

| # | 操作 | 文件路径 | 说明 |
|---|------|---------|------|
| 5 | **新增** | `src/adapters/fibrehome-adapter.ts` | 烽火适配器（从 Import.tsx 提取逻辑 + neProvinceMap + neSystemMap + PROVINCE_COORDS） |
| 6 | **新增** | `src/adapters/index.ts` | Barrel export（内置适配器批量导出） |
| 7 | **修改** | `src/types/index.ts` | **不动现有类型**，在文件末尾追加 `/** @deprecated 建议迁移至 CoreAlarm */` 标记。NeType 枚举保留兼容，另加 `export type Vendor = ...` |
| 8 | **修改** | `src/store/useAppStore.ts` | 新增 `coreAlarms: CoreAlarm[]` 和 `coreNetworkElements: CoreNE[]` 状态，与旧状态共存。新增 `addCoreAlarms`、`setCoreAlarms`、`setCoreNetworkElements` actions |
| 9 | **修改** | `src/db/index.ts` | 新增 `coreAlarms` 和 `coreNetworkElements` 对象仓库（按 projectId 索引），与旧表共存 |
| 10 | **新增** | `src/core/store-hooks.ts` | 可选：封装从 Store 获取 Core 数据的 hooks，带类型安全的 selector |

### 第三阶段：页面迁移 + 外部适配器支持

| # | 操作 | 文件路径 | 说明 |
|---|------|---------|------|
| 11 | **新增** | `src/pages/DataSourceConfig.tsx` | 数据源配置页面（选择厂商、配置列映射、管理已注册数据源） |
| 12 | **修改** | `src/App.tsx` | 新增路由 `/data-sources`，启动时执行 `DataSourceRegistry.getInstance().register(new FibreHomeAdapter())` |
| 13 | **修改** | `src/pages/Import.tsx` | 接入 DataSourceAdapter。文件解析后交给适配器处理。`FIELD_AUTO_MAP` 等硬编码保留但标记 `@deprecated`，改为优先使用适配器的 `defaultAlarmMapping` |
| 14 | **修改** | `src/pages/Topology.tsx` | 省份坐标从 `adapter.getProvinces()` 获取。当没有活跃数据源时，fallback 到当前硬编码的 `PROVINCE_COORDS` |
| 15 | **修改** | `src/utils/alarmAggregator.ts` | 从 `mockTopologyLinks` 和 `NE_SYSTEM_MAP` 的硬编码依赖改为通过 DataSourceRegistry 获取 |
| 16 | **修改** | `src/pages/Dashboard.tsx` | 改为同时兼容旧 AlarmRecord 和新 CoreAlarm |
| 17 | **修改** | `src/pages/AlarmAnalysis.tsx` | 同上 |
| 18 | **修改** | `src/pages/Report.tsx` | 同上 |
| 19 | **修改** | `src/data/mockData.ts` | 新增 `mockCoreAlarms: CoreAlarm[]` 和 `mockCoreNEs: CoreNE[]`（兼容旧 mock 数据） |
| 20 | **清理** | `src/data/neProvinceMap.ts` | 保留不动（烽火适配器内部引用），但 `Import.tsx` 不再直接 import |
| 21 | **清理** | `src/data/neSystemMap.ts` | 同上 |

---

## 6. 实施步骤（3 阶段）

### 第 1 阶段：核心抽象层（预计 2-3 天）

**目标**：定义标准类型和接口，不动现有代码，验证设计可行性。

**交付物**：

- [ ] `src/core/types.ts` — 所有核心类型定义
- [ ] `src/core/adapter.ts` — Adapter 接口
- [ ] `src/core/registry.ts` — 注册表实现
- [ ] `src/core/index.ts` — 导出

**验证标准**：

1. 编写一个最小测试：手动构造一组 CoreAlarm，验证可序列化/反序列化无信息丢失
2. 验证 `CoreAlarm` 可以从 `AlarmRecord` 无损转换（写一个简单的转换函数作为测试，不在生产代码中）
3. 验证 `DataSourceRegistry` 注册/获取/卸载流程正确

**不影响现有功能**：旧代码完全不动，旧页面正常工作。

### 第 2 阶段：烽火适配器 + 层间适配（预计 3-4 天）

**目标**：提取现有烽火逻辑为适配器，Store 和 DB 支持双轨运行（新旧数据共存）。

**交付物**：

- [ ] `src/adapters/fibrehome-adapter.ts` — 烽火适配器
- [ ] `src/adapters/index.ts`
- [ ] Store 新增 `coreAlarms` / `coreNetworkElements` 状态
- [ ] DB 新增 `coreAlarms` / `coreNetworkElements` 对象仓库
- [ ] 应用启动时自动注册烽火适配器
- [ ] 编写从 `AlarmRecord` → `CoreAlarm` 的转换函数（`src/core/converters.ts`）

**验证标准**：

1. 导入一条烽火告警文件，走新管道（parseFile → FibreHomeAdapter.parseAlarms → CoreAlarm），确认字段转换正确
2. 新旧 store 中的报警数据保持同步（导入 CoreAlarm 时自动同步一份 AlarmRecord 用于旧页面）
3. 旧页面（Dashboard、Analysis、Report）仍可从旧 AlarmRecord 读取数据
4. 运行全部自动化测试（存量功能回归测试）

**注意事项**：

- 采用「写时双轨」策略：导入时同时写入 `coreAlarms` 和 `alarms`（通过适配器转换一次 + 旧路径走一次）。读时旧页面继续读 `alarms`，新页面读 `coreAlarms`
- 当确认所有页面都迁移后，移除旧的 `alarms` 存储

### 第 3 阶段：页面迁移 + 数据源管理 UI（预计 4-5 天）

**目标**：页面逐步切换为使用 Core 类型，新增数据源配置界面。

**交付物**：

- [ ] `src/pages/DataSourceConfig.tsx` — 数据源管理页面
- [ ] Import.tsx 接入 Adapter
- [ ] Topology.tsx 使用 `getProvinces()`
- [ ] 告警分析/报表页面逐步迁移
- [ ] 外部适配器动态加载机制（`registry.loadExternalAdapter(url)`）

**验证标准**：

1. 可以创建一个新数据源（如"华为测试数据源"），配置列映射，导入华为格式的模拟文件
2. 拓扑视图根据数据源的 `getProvinces()` 渲染省份布局
3. 导入的华为数据在 Dashboard/Analysis 中正确展示
4. 旧数据（已存在的烽火项目）不受影响

**可选的「第 4 阶段」**：

- 移除旧 AlarmRecord / NetworkElement 类型
- 删除 `mockData.ts` 中的旧 mock 数据（保留 Core 版本）
- 删除 `neProvinceMap.ts` / `neSystemMap.ts`（数据全在烽火适配器内部）
- 重构 `PROVINCE_COORDS`→ 烽火适配器 `getProvinces()`

---

## 7. 风险点与缓解措施

| # | 风险 | 概率 | 影响 | 缓解措施 |
|---|------|------|------|---------|
| 1 | **CoreAlarm 字段覆盖不全**：某些页面用到了 AlarmRecord 的专有字段（如 `ruisikangConfirmTime`） | 中 | 高 | Phase 2 同步写入新旧两份数据。页面迁移时检查是否有专有字段依赖。设定「extensions 兜底」策略 |
| 2 | **Store 双轨数据不一致**：coreAlarms 和 alarms 不同步 | 中 | 中 | 封装统一的 `addAlarms` 方法，确保写入时同时更新新旧数据。编写数据一致性检查（开发期断言） |
| 3 | **动态加载外部适配器的安全风险** | 低 | 高 | 限制外部适配器通过 URL 加载。考虑支持「静态注册」（npm 包 import）优先于「动态加载」。动态加载时做完整性校验 |
| 4 | **性能开销**：导入时同时经过旧路径和新路径转换 | 低 | 中 | Phase 2 双轨写入仅在迁移期存在。性能监控 + 添加 benchmark。单轨后性能优于旧实现 |
| 5 | **现有功能回归**：页面迁移过程中逻辑出错 | 中 | 高 | 每个页面迁移后做完整的功能测试用例覆盖。优先迁移 Import 和 Topology（这两个影响面最大） |
| 6 | **团队学习曲线**：Adapter 模式 + 动态注册对开发者不熟悉 | 低 | 中 | 提供详细的适配器开发模板（`src/adapters/_template.ts`），编写适配器开发指南 |
| 7 | **IndexedDB 数据兼容**：旧数据格式与新格式共存时 schema 冲突 | 中 | 中 | 使用不同的对象仓库名称（`coreAlarms` vs `alarms`）。IndexedDB 版本升级流程已有（`DB_VERSION` 控制） |
| 8 | **字段映射精度损失**：核心类型的枚举值压缩（如 AlarmStatus 5→3）导致信息丢失 | 中 | 中 | 原始值保留在 `extensions.originalStatus`。UI 展示时优先显示 extensions 中的原始值 |

---

## 附录 A：转换函数示例

```typescript
// src/core/converters.ts（Phase 2 编写）

/**
 * 将旧的 AlarmRecord 转换为 CoreAlarm
 *
 * 方针：所有可能存在信息损失的字段，原始值保留在 extensions 中。
 */
export function alarmRecordToCoreAlarm(old: AlarmRecord): CoreAlarm { ... }

/**
 * 将 CoreAlarm 展示为旧格式字段（用于尚未迁移的 UI 组件）
 */
export function coreAlarmToDisplay(core: CoreAlarm, adapter?: DataSourceAdapter): Record<string, string> { ... }
```

## 附录 B：目录结构最终形态

```
src/
├── core/                      # 新增：核心抽象层
│   ├── types.ts               #   CoreAlarm, CoreNE, DataSourceManifest
│   ├── adapter.ts             #   DataSourceAdapter 接口
│   ├── registry.ts            #   DataSourceRegistry
│   ├── converters.ts          #   AlarmRecord ↔ CoreAlarm 转换
│   ├── store-hooks.ts         #   可选：Store 选择器
│   └── index.ts
│
├── adapters/                  # 新增：适配器实现
│   ├── fibrehome-adapter.ts   #   烽火适配器（内置）
│   ├── _template.ts           #   适配器开发模板
│   └── index.ts
│
├── types/index.ts             # 修改：追加 @deprecated 标记，新增 Vendor 类型
├── store/useAppStore.ts       # 修改：新增 coreAlarms / coreNetworkElements
├── db/index.ts                # 修改：新增 coreAlarms / coreNetworkElements 仓库
├── pages/
│   ├── DataSourceConfig.tsx   # 新增：数据源配置页
│   ├── Import.tsx             # 修改：接入 Adapter
│   ├── Topology.tsx           # 修改：适配 getProvinces()
│   └── ...（其他页面逐步迁移）
└── data/
    ├── mockData.ts            # 修改：新增 mockCoreAlarms / mockCoreNEs
    ├── neProvinceMap.ts       # 不动（烽火适配器引用）
    └── neSystemMap.ts         # 不动（烽火适配器引用）
```
