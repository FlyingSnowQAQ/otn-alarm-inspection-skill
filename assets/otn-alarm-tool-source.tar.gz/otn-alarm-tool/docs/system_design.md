# OTN历史告警可视化巡检工具 V1.1 — 增量系统设计

> **架构师**: Bob (software-architect)
> **日期**: 2026-06-20
> **基线版本**: V1.0 (14个源文件, Vite+React+MUI+Zustand)

---

## Part A: 系统设计

### 1. 实现方案分析

#### 1.1 核心技术挑战

| 挑战 | 难度 | 说明 |
|------|------|------|
| IndexedDB 与 Zustand 状态同步 | M | 需要设计增量的持久化中间层，不破坏现有单向数据流 |
| 多项目管理（数据隔离） | M | 每个项目独立数据集，切换时内存与 IndexedDB 协调 |
| 告警聚合算法性能 | L | 2469网元 × 数万告警需要 O(n log n) 分组+窗口扫描 |
| PDF 导出与单文件打包兼容 | M | vite-plugin-singlefile 将所有资源内联，PDF 生成不能依赖外部 CDN |
| 图表→静态图片转换 | M | Recharts 渲染为 SVG，需在打印前转为 Canvas→PNG dataURL |

#### 1.2 框架与库选型

| 用途 | 选型 | 理由 |
|------|------|------|
| IndexedDB 封装 | **idb** (v8) | 仅 1.5KB，原生 Promise API，TypeScript 友好 |
| 图表截图 | **无额外依赖** | 原生 Canvas API 将 SVG 转 PNG，避免与 vite-plugin-singlefile 冲突 |
| PDF 导出 | **浏览器 window.print() + @media print** | 遵循 PRD 要求，零依赖，与单文件打包兼容 |
| 其他 | 复用 V1.0 全部依赖 | react, @mui/material, recharts, zustand, dayjs, xlsx, @xyflow/react |

#### 1.3 架构模式

保持 V1.0 的 **Zustand 单向数据流 + 页面组件模式**，增量引入三层：

```
┌─────────────────────────────────────────────┐
│                  Pages (UI)                   │
│  Projects / Dashboard / Analysis / Report    │
├─────────────────────────────────────────────┤
│              Zustand Store (状态)             │
│  + projectState / + aggregationParams        │
├─────────────────────────────────────────────┤
│           db/index.ts (持久化层)              │
│  IndexedDB CRUD: projects / alarms / NEs     │
└─────────────────────────────────────────────┘
```

**关键数据流变化**:
- **导入时**: Import.tsx → `addAlarms()` → Store 更新 → **自动触发** `db.saveAlarms(projectId, alarms)`
- **启动时**: `main.tsx` → `db.loadProjects()` → Store 初始化项目列表 → `db.loadProjectData(id)` → Store 填充数据
- **切换项目**: Store.saveCurrentProject() → Store.loadProject(newId) → 页面自动响应

### 2. 文件列表

#### 2.1 新增文件（8个）

```
otn-alarm-tool/
├── src/
│   ├── db/
│   │   └── index.ts                 # IndexedDB 封装（项目CRUD + 数据存取）
│   ├── pages/
│   │   ├── Projects.tsx             # 项目管理页面（列表/新建/切换/重命名/删除）
│   │   └── InspectionReport.tsx     # 巡检报告页面（6章节模板 + PDF导出）
│   ├── components/
│   │   ├── AlarmStormCard.tsx       # 仪表盘"告警风暴Top10"卡片
│   │   ├── AlarmTimeline.tsx        # 告警聚合时间线视图组件
│   │   └── ReportCover.tsx          # 报告封面组件
│   └── utils/
│       ├── alarmAggregator.ts       # 告警根因聚合算法
│       └── chartToImage.ts          # Recharts SVG → PNG DataURL 工具
└── src/
    └── report-print.css             # @media print 样式（报告PDF导出用）
```

#### 2.2 修改文件（7个）

```
src/types/index.ts          # 新增 Project、AlarmGroup、ReportMeta 等类型
src/store/useAppStore.ts    # 扩展 project 状态 + 聚合参数 + 持久化 actions
src/App.tsx                 # 新增 project / inspection-report 路由
src/components/Layout.tsx   # 导航菜单新增"项目管理"/"巡检报告"
src/pages/Dashboard.tsx     # 新增"告警风暴Top10网元"卡片区域
src/pages/AlarmAnalysis.tsx # 新增聚合/明细视图切换 + 时间窗口选择器
src/pages/Import.tsx        # 导入完成后自动保存至 IndexedDB
```

#### 2.3 关键依赖关系

```
db/index.ts          ← types/index.ts
store/useAppStore.ts ← db/index.ts, types/index.ts
alarmAggregator.ts   ← types/index.ts
chartToImage.ts      ← （纯工具，无内部依赖）
AlarmStormCard.tsx   ← store, alarmAggregator
AlarmTimeline.tsx    ← store, types
Projects.tsx         ← store, db
InspectionReport.tsx ← store, chartToImage, ReportCover
Dashboard.tsx        ← AlarmStormCard
AlarmAnalysis.tsx    ← AlarmTimeline, alarmAggregator, store
Import.tsx           ← store (persist), db
App.tsx              ← Projects, InspectionReport
Layout.tsx           ← types (PageRoute)
```

### 3. 数据结构和接口

#### 3.1 新增类型定义

```typescript
// ========== types/index.ts 新增部分 ==========

/** 项目元数据 */
export interface ProjectMeta {
  id: string;            // UUID
  name: string;          // 项目名称
  createdAt: string;     // ISO 8601
  updatedAt: string;     // ISO 8601
  alarmCount: number;    // 当前告警总数
  neCount: number;       // 当前网元总数
  dataSizeBytes: number; // 数据占用字节数（近似）
}

/** 告警聚合组（根因分析结果） */
export interface AlarmGroup {
  id: string;                    // 聚合组ID
  neName: string;                // 网元名称
  boardName: string;             // 单板名称
  slotNo: string;                // 槽位号
  windowStart: string;           // 时间窗口起始 ISO
  windowEnd: string;             // 时间窗口结束 ISO
  alarms: AlarmRecord[];         // 窗口内所有告警（按时间排序）
  rootCauseAlarm: AlarmRecord;   // 推断的根因告警
  rootCauseScore: number;        // 根因评分 (0-1)
  severity: AlarmStormSeverity;  // 风暴严重程度
  derivedCount: number;          // 衍生告警数量（不含根因）
}

/** 告警风暴严重程度 */
export type AlarmStormSeverity = 'storm' | 'cluster' | 'scattered';
// storm: ≥10条告警/窗口 → 严重风暴
// cluster: 5-9条 → 告警簇
// scattered: 2-4条 → 零星告警

/** 聚合视图模式 */
export type AggregationViewMode = 'aggregated' | 'detail';

/** 时间窗口选项（分钟） */
export type TimeWindowMinutes = 5 | 15 | 30 | 60;

/** 扩展后的页面路由 */
export type PageRoute =
  | 'dashboard'
  | 'topology'
  | 'analysis'
  | 'import'
  | 'report'
  | 'projects'            // 新增
  | 'inspection-report';   // 新增

/** 报告元数据 */
export interface ReportMeta {
  title: string;           // 报告标题
  period: string;          // 巡检周期描述
  author: string;          // 编制人
  department: string;      // 部门
  reportDate: string;      // 报告日期
}

/** 报告章节数据 */
export interface ReportData {
  meta: ReportMeta;
  summaryStats: {
    totalAlarms: number;
    activeAlarms: number;
    clearedAlarms: number;
    clearanceRate: string;
    totalNEs: number;
    onlineNEs: number;
  };
  levelDistribution: { level: AlarmLevel; total: number; active: number; cleared: number }[];
  provinceDistribution: { name: string; value: number }[];
  alarmTrend: { date: string; 紧急: number; 主要: number; 次要: number; 提示: number }[];
  topStormNEs: AlarmGroup[];           // Top10告警风暴网元
  topAlarmNEs: { neName: string; count: number; critical: number }[];
  conclusions: string;                  // 自动生成的结论文本
}

/** IndexedDB 数据库结构 */
export interface OTNDBSchema {
  projects: {
    key: string;
    value: ProjectMeta;
  };
  alarms: {
    key: string;
    value: AlarmRecord & { projectId: string };
    indexes: { 'by-project': string };
  };
  networkElements: {
    key: string;
    value: NetworkElement & { projectId: string };
    indexes: { 'by-project': string };
  };
  alarmTypeDefinitions: {
    key: string;
    value: AlarmTypeDefinition & { projectId: string };
    indexes: { 'by-project': string };
  };
}
```

#### 3.2 核心类图 (Mermaid)

```mermaid
classDiagram
    class ProjectMeta {
        +string id
        +string name
        +string createdAt
        +string updatedAt
        +number alarmCount
        +number neCount
        +number dataSizeBytes
    }

    class AlarmGroup {
        +string id
        +string neName
        +string boardName
        +string slotNo
        +string windowStart
        +string windowEnd
        +AlarmRecord[] alarms
        +AlarmRecord rootCauseAlarm
        +number rootCauseScore
        +AlarmStormSeverity severity
        +number derivedCount
    }

    class AlarmRecord {
        +string id
        +number alarmNo
        +string alarmTitle
        +AlarmLevel alarmLevel
        +string neName
        +string slotNo
        +string boardName
        +string firstOccurTime
        +string lastOccurTime
        ...24 fields total
    }

    class ReportMeta {
        +string title
        +string period
        +string author
        +string department
        +string reportDate
    }

    class ReportData {
        +ReportMeta meta
        +object summaryStats
        +object[] levelDistribution
        +object[] provinceDistribution
        +object[] alarmTrend
        +AlarmGroup[] topStormNEs
        +object[] topAlarmNEs
        +string conclusions
    }

    class OTNDatabase {
        +openDB() Promise~IDBPDatabase~
        +createProject(name) Promise~ProjectMeta~
        +getAllProjects() Promise~ProjectMeta[]~
        +renameProject(id, name) Promise~void~
        +deleteProject(id) Promise~void~
        +saveAlarms(projectId, alarms) Promise~void~
        +loadAlarms(projectId) Promise~AlarmRecord[]~
        +saveNetworkElements(projectId, elements) Promise~void~
        +loadNetworkElements(projectId) Promise~NetworkElement[]~
        +saveAlarmTypeDefinitions(projectId, defs) Promise~void~
        +loadAlarmTypeDefinitions(projectId) Promise~AlarmTypeDefinition[]~
        +getProjectDataSize(projectId) Promise~number~
        +exportProjectJSON(projectId) Promise~string~
        +importProjectJSON(json) Promise~ProjectMeta~
    }

    class AppStore {
        +ProjectMeta[] projects
        +string activeProjectId
        +AlarmRecord[] alarms
        +NetworkElement[] networkElements
        +AlarmTypeDefinition[] alarmTypeDefinitions
        +AggregationViewMode aggregationViewMode
        +TimeWindowMinutes aggregationWindow
        +PageRoute currentPage
        +loadProjects() Promise
        +switchProject(id) Promise
        +createProject(name) Promise
        +deleteProject(id) Promise
        +renameProject(id, name) Promise
        +addAlarms(alarms) void
        +setAggregationWindow(minutes) void
        +setAggregationViewMode(mode) void
        +persistCurrentProject() Promise
        +exportBackup() Promise~string~
        +importBackup(json) Promise~void~
    }

    class AlarmAggregator {
        +aggregate(alarms, windowMinutes) AlarmGroup[]
        -groupByNEBoard(alarms) Map~string, AlarmRecord[]~
        -findClusters(records, windowMs) AlarmRecord[][]
        -calculateRootCauseScore(cluster) number
        -inferSeverity(count) AlarmStormSeverity
    }

    class ChartToImage {
        +svgToDataURL(svgElement) Promise~string~
        +captureAllCharts(container) Promise~Map~string, string~~
    }

    AlarmGroup --> AlarmRecord : contains
    ReportData --> AlarmGroup : references
    ReportData --> ReportMeta : contains
    AppStore --> ProjectMeta : manages
    AppStore --> OTNDatabase : uses
    AppStore --> AlarmRecord : manages
    OTNDatabase --> ProjectMeta : CRUD
    OTNDatabase --> AlarmRecord : CRUD
    AlarmAggregator --> AlarmGroup : produces
    AlarmAggregator --> AlarmRecord : consumes
```

### 4. 程序调用流程

#### 4.1 应用启动与数据恢复

```mermaid
sequenceDiagram
    participant main as main.tsx
    participant store as useAppStore
    participant db as OTNDatabase
    participant app as App.tsx

    main->>store: 初始化
    store->>db: getAllProjects()
    db-->>store: ProjectMeta[]
    store->>store: set projects

    alt 有历史项目
        store->>db: loadAlarms(activeProjectId)
        store->>db: loadNetworkElements(activeProjectId)
        store->>db: loadAlarmTypeDefinitions(activeProjectId)
        db-->>store: data arrays
        store->>store: set alarms, networkElements, alarmTypeDefinitions
        store->>app: 渲染仪表盘（已恢复数据）
    else 无项目或首次使用
        store->>store: 加载 mockData（现有逻辑）
        store->>app: 渲染仪表盘（预置数据）
    end
```

#### 4.2 数据导入 → 持久化流程

```mermaid
sequenceDiagram
    participant Import as Import.tsx
    participant store as useAppStore
    participant db as OTNDatabase

    Import->>Import: 解析XLS文件
    Import->>Import: 列映射确认
    Import->>store: addAlarms(newAlarms)
    store->>store: alarms = [...alarms, ...newAlarms]
    store->>db: saveAlarms(projectId, newAlarms)
    db->>db: IndexedDB putAll (批量写入)
    store->>db: updateProjectMeta(projectId, {alarmCount, updatedAt})
    db-->>store: success
    store-->>Import: 导入完成
```

#### 4.3 告警根因聚合分析流程

```mermaid
sequenceDiagram
    participant Analysis as AlarmAnalysis.tsx
    participant agg as alarmAggregator
    participant store as useAppStore
    participant Timeline as AlarmTimeline.tsx

    Analysis->>store: 读取 alarms, aggregationWindow
    store-->>Analysis: AlarmRecord[]

    alt 聚合视图模式
        Analysis->>agg: aggregate(alarms, windowMinutes)
        agg->>agg: groupByNEBoard(alarms)
        agg->>agg: 对每组按时间排序
        agg->>agg: 滑动窗口扫描 findClusters()
        agg->>agg: 对每个cluster: calculateRootCauseScore()
        agg->>agg: inferSeverity(count)
        agg-->>Analysis: AlarmGroup[]
        Analysis->>Timeline: 渲染聚合列表
    else 明细视图模式
        Analysis->>Analysis: 现有表格展示逻辑
    end
```

#### 4.4 巡检报告 PDF 导出流程

```mermaid
sequenceDiagram
    participant Report as InspectionReport.tsx
    participant ChartUtil as chartToImage
    participant Browser as window

    Report->>Report: 点击"导出PDF"
    Report->>ChartUtil: captureAllCharts(containerEl)
    ChartUtil->>ChartUtil: 遍历所有 SVG 元素
    ChartUtil->>ChartUtil: svgToDataURL(svgEl)
    Note over ChartUtil: SVG → XMLSerializer → Blob → Image → Canvas → dataURL
    ChartUtil-->>Report: Map<chartId, dataURL>
    Report->>Report: 替换 SVG 为 <img src=dataURL>
    Report->>Browser: window.print()
    Note over Browser: @media print CSS 生效
    Browser->>Browser: 打印/保存为PDF
```

### 5. 不明之处与假设

| 序号 | 不明点 | 假设与处理 |
|------|--------|-----------|
| 1 | 项目删除时是否物理删除 IndexedDB 数据 | **是**，删除 project 记录 + 级联删除其下所有 alarms/NEs/definitions |
| 2 | 网元数据(NE)是否也走导入→持久化流程 | **是**，Import 页在导入告警时，NE 数据一并写入 IndexedDB |
| 3 | 告警聚合中 `最早时间戳` 如何归一化 | 使用窗口内 min-max 归一化：`normTime = 1 - (t - tMin) / (tMax - tMin)` |
| 4 | 200MB 容量限制如何检查 | `navigator.storage.estimate()` 估算；写入前检查当前项目 dataSizeBytes |
| 5 | vite-plugin-singlefile 与 @media print 兼容性 | print CSS 在构建后仍会保留（它是标准 CSS at-rule，vite 不会移除） |
| 6 | 报告"结论自动生成"的智能程度 | 基于规则模板：根据紧急告警占比、清除率、风暴数量生成预设结论语句 |
| 7 | 项目切换时未保存数据的处理 | 切换前自动调用 `persistCurrentProject()` |

---

## Part B: 任务分解

### 6. 新增依赖包

```
- idb@^8.0.0: IndexedDB 异步封装库（~1.5KB gzipped）
```

**无需新增其他依赖。** PDF 导出使用浏览器原生 API，图表截图使用原生 Canvas API，均不引入外部库以避免与 `vite-plugin-singlefile` 冲突。

### 7. 任务列表

#### T01: 持久化基础设施 + 类型扩展

| 属性 | 内容 |
|------|------|
| **Task ID** | T01 |
| **优先级** | P0 |
| **复杂度** | L |
| **依赖** | 无 |

**源文件**:
- `src/types/index.ts` (**修改**) — 新增 `ProjectMeta`, `AlarmGroup`, `AlarmStormSeverity`, `AggregationViewMode`, `TimeWindowMinutes`, `ReportMeta`, `ReportData`, 扩展 `PageRoute`
- `src/db/index.ts` (**新增**) — IndexedDB 完整封装：openDB, 项目CRUD, alarms/NEs/definitions 批量存取, JSON 导入导出, 容量检查
- `src/store/useAppStore.ts` (**修改**) — 扩展 store：`projects[]`, `activeProjectId`, `aggregationViewMode`, `aggregationWindow`；新增 actions：`loadProjects()`, `switchProject()`, `createProject()`, `deleteProject()`, `renameProject()`, `persistCurrentProject()`, `exportBackup()`, `importBackup()`
- `src/main.tsx` (**修改**) — 应用启动时调用 `store.loadProjects()` 初始化

**说明**: 这是 V1.1 的基石任务。所有后续任务都依赖此任务完成后的类型定义、数据库接口和 store 扩展。

---

#### T02: 项目管理页面 + 导入持久化

| 属性 | 内容 |
|------|------|
| **Task ID** | T02 |
| **优先级** | P0 |
| **复杂度** | M |
| **依赖** | T01 |

**源文件**:
- `src/pages/Projects.tsx` (**新增**) — 项目列表页：网格卡片展示所有项目，新建（对话框输入名称），切换（点击卡片 → switchProject），重命名（内联编辑），删除（二次确认），JSON 备份导出/导入按钮
- `src/pages/Import.tsx` (**修改**) — 导入完成后调用 `store.persistCurrentProject()` 自动保存至 IndexedDB；若当前无项目自动创建"默认项目"
- `src/App.tsx` (**修改**) — 新增 `'projects'` 路由映射到 `<Projects />`
- `src/components/Layout.tsx` (**修改**) — NAV_ITEMS 新增 `{ key: 'projects', label: '项目管理', icon: <FolderIcon /> }`

**说明**: 实现 P0-1 的 UI 层。导入页面不再仅存内存，刷新后数据完整恢复。

---

#### T03: 告警根因聚合分析

| 属性 | 内容 |
|------|------|
| **Task ID** | T03 |
| **优先级** | P0 |
| **复杂度** | L |
| **依赖** | T01 |

**源文件**:
- `src/utils/alarmAggregator.ts` (**新增**) — 核心算法：`aggregate(alarms, windowMinutes) → AlarmGroup[]`，包含 `groupByNEBoard()`, `findClusters()`（滑动窗口）, `calculateRootCauseScore()`（最早×0.6 + 级别×0.4）, `inferSeverity()`
- `src/components/AlarmTimeline.tsx` (**新增**) — 时间线可视化组件：左侧时间轴 + 根因标签（红色高亮）+ 衍生告警列表；支持展开/折叠
- `src/components/AlarmStormCard.tsx` (**新增**) — 仪表盘卡片组件：Top10 告警风暴网元排名，显示网元名、风暴条数、严重程度标签
- `src/pages/Dashboard.tsx` (**修改**) — 在"图表区域"下方新增一行 `<AlarmStormCard />`
- `src/pages/AlarmAnalysis.tsx` (**修改**) — 新增聚合/明细视图切换 ToggleButton；聚合模式下用 `<AlarmTimeline />` 替换现有表格；新增时间窗口选择器（5/15/30/60min）

**说明**: 实现 P0-2 全部功能。算法复杂度 O(n log n)，通过 Map 分组 + 排序 + 单遍滑动窗口，可在数秒内处理数万条告警。

---

#### T04: 巡检报告模板 + PDF导出

| 属性 | 内容 |
|------|------|
| **Task ID** | T04 |
| **优先级** | P0 |
| **复杂度** | L |
| **依赖** | T01, T03 |

**源文件**:
- `src/utils/chartToImage.ts` (**新增**) — SVG → PNG 转换工具：`svgToDataURL(svgElement)` 用 XMLSerializer → Blob → Image → Canvas → toDataURL；`captureAllCharts(container)` 批量捕获
- `src/components/ReportCover.tsx` (**新增**) — 报告封面组件：标题、周期、编制人、部门、日期、OTN 图标
- `src/pages/InspectionReport.tsx` (**新增**) — 6章节报告页面：
  1. 封面（ReportCover + 元数据预填表单）
  2. 数据摘要（告警总数/活动/清除率、网元在线率）
  3. 告警趋势图（AreaChart → 截图嵌入）
  4. 告警分布（级别饼图 + 省份柱状图 → 截图嵌入）
  5. Top告警风暴网元（T03 的 AlarmStormCard 复用）
  6. 结论与建议（自动生成文本 + 可编辑区域）
  所有章节在页面上可滚动预览，点击"导出PDF"按钮触发 print
- `src/report-print.css` (**新增**) — @media print 规则：隐藏侧边栏/顶栏/按钮，报告全宽展示，A4 页面分页（page-break-after），图表 img 自适应
- `src/App.tsx` (**修改**) — 新增 `'inspection-report'` 路由
- `src/components/Layout.tsx` (**修改**) — 新增 `{ key: 'inspection-report', label: '巡检报告', icon: <PictureAsPdfIcon /> }`

**依赖 T03 原因**: InspectionReport 需要复用 `AlarmStormCard` 的数据和类型。

---

#### T05: 路由集成 + 收尾调试

| 属性 | 内容 |
|------|------|
| **Task ID** | T05 |
| **优先级** | P1 |
| **复杂度** | S |
| **依赖** | T02, T03, T04 |

**源文件**:
- `src/App.tsx` (**修改**) — 最终确认全部路由映射（含 projects, inspection-report），默认路由逻辑：无项目时跳转 projects，有项目时跳转 dashboard
- `src/components/Layout.tsx` (**修改**) — 版本号更新为 v1.1.0；顶栏新增项目名称显示（当前活跃项目）
- `package.json` (**修改**) — 版本号更新为 "1.1.0"；确认 `idb` 依赖已添加
- `src/store/useAppStore.ts` (**修改**) — 边界处理：项目切换时 loading 状态、空项目提示、存储容量超限警告

**说明**: 最终集成。确保所有页面跳转顺畅，项目切换时页面数据正确刷新，无遗漏的边界情况。

---

### 8. 任务依赖图

```mermaid
graph TD
    T01["T01: 持久化基础设施 + 类型扩展<br/>types + db + store + main"]
    T02["T02: 项目管理页面 + 导入持久化<br/>Projects + Import修改 + App路由 + Layout导航"]
    T03["T03: 告警根因聚合分析<br/>aggregator + Timeline + StormCard + Dashboard + Analysis"]
    T04["T04: 巡检报告模板 + PDF导出<br/>chartToImage + ReportCover + InspectionReport + printCSS"]
    T05["T05: 路由集成 + 收尾调试<br/>App路由确认 + Layout更新 + 边界处理"]

    T01 --> T02
    T01 --> T03
    T01 --> T04
    T03 --> T04
    T02 --> T05
    T03 --> T05
    T04 --> T05
```

**并行建议**: T02 和 T03 可并行开发（均仅依赖 T01）；T04 串行于 T03 之后（依赖 AlarmStormCard 组件）；T05 在所有功能完成后收尾。

---

### 9. 共享知识约定

```
## 数据规范
- 所有日期时间使用 ISO 8601 字符串（UTC），显示时由 dayjs 转换为本地时区
- 项目ID 使用 crypto.randomUUID() 生成
- 告警ID 使用 `{projectId}-{alarmNo}-{timestamp}` 格式确保唯一性

## IndexedDB
- 数据库名: 'otn-alarm-tool'
- 版本: 1（首次创建）
- Object Stores: projects, alarms, networkElements, alarmTypeDefinitions
- alarms/networkElements/alarmTypeDefinitions 均含 projectId 字段 + 'by-project' 索引
- 写入使用 idb 的批量事务，每批最多 1000 条

## Store 集成
- Store 中的 data arrays (alarms, networkElements) 是 IndexedDB 的"热缓存"
- 导入/修改数据后立即 persistCurrentProject()
- 项目切换前自动 persistCurrentProject() 再 loadProjectData()
- 应用启动时 loadProjects() → 有项目则 loadProjectData(activeProjectId)

## 告警聚合
- 分组键: `${neName}::${slotNo}::${boardName}`
- 窗口: 以分组内第一条告警为起点滑动，相邻告警间隔 ≤ windowMs 则归入同一 cluster
- 根因评分: score = normalizedEarliestTime * 0.6 + normalizedLevel * 0.4
  - normalizedEarliestTime = 1 - (alarm.time - clusterMinTime) / (clusterMaxTime - clusterMinTime)
  - normalizedLevel = ALARM_LEVEL_ORDER[alarm.level] / 4
- 风暴分类: storm(≥10条), cluster(5-9条), scattered(2-4条)

## PDF 导出
- 使用 window.print() + @media print CSS
- 图表在打印前通过 chartToImage.ts 转为 PNG dataURL，替换 SVG
- print CSS 中隐藏: .no-print 类名元素（侧边栏、顶栏、按钮、表单）
- 分页: .page-break 类名应用 page-break-after: always
- 报告页面在屏幕上正常展示，仅在 print 时触发样式变化

## 单文件打包兼容
- 不引入任何 CDN 依赖
- 不引入 html2canvas（防止与 vite-plugin-singlefile 的 ESM 处理冲突）
- 所有图表截图使用纯 Canvas API 实现
```

---

### 10. 潜在风险与技术盲点

| 风险 | 影响 | 缓解措施 |
|------|------|---------|
| **IndexedDB 写入性能** | 数万条告警逐条写入极慢 | 使用 idb 的批量事务，每批 1000 条；导入时显示两阶段进度（解析→持久化） |
| **IndexedDB 容量超限** | 200MB 限制，浏览器可能拒绝写入 | 每次写入前用 `navigator.storage.estimate()` 估算；超限时提示用户清理旧项目 |
| **Safari IndexedDB 限制** | Safari 私有模式下 IndexedDB 不可用 | 检测 API 可用性，降级为 localStorage（≤5MB）或纯内存模式 + 提示 |
| **图表 SVG → Canvas 跨域** | Recharts SVG 内嵌样式/foreignObject 可能导致 Canvas 渲染失败 | 使用 XMLSerializer 序列化 SVG，内联所有 computed style 后再转 Canvas |
| **@media print 浏览器差异** | Chrome/Edge/Firefox 打印效果不一致 | 使用标准 CSS print 属性，避免 `@page` 高级特性；测试三主流浏览器 |
| **vite-plugin-singlefile + 动态 import** | idb 库的 ESM 打包行为可能与 singlefile 冲突 | idb 是纯 ESM 无副作用库，已验证兼容；构建后在浏览器验证 |
| **告警聚合的内存峰值** | 2469×数万条分组后的中间对象可能占用大量内存 | 分批次处理（每次处理 500 个 NE 分组）；结果实时输出而非全量缓存 |
| **项目切换时数据一致性** | 用户可能在 Import 进行中切换项目 | 项目切换前检查 isImporting 状态，若正在导入则阻止切换并提示 |
