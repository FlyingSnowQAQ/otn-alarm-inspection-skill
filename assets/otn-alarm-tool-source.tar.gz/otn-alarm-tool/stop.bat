@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo ========================================
echo   Stopping OTN Alarm Tool Server
echo ========================================
echo.

:: Step 1: Kill by PID file (our own server.js)
set PID_FILE=.server.pid
if exist "%PID_FILE%" (
    set /p TARGET_PID=<"%PID_FILE%"
    if not "!TARGET_PID!"=="" (
        echo  [INFO] Found saved PID: !TARGET_PID!
        taskkill /pid !TARGET_PID! /f >nul 2>nul && (
            echo  [OK] Server (!TARGET_PID!) stopped.
        )
    )
    del "%PID_FILE%" 2>nul
)

:: Step 2: Kill anything on port 8080 and 8081
echo  [INFO] Releasing ports 8080 and 8081...

powershell -ExecutionPolicy Bypass -Command ^
"$ports = @(8899, 8900); ^
 Get-NetTCPConnection -ErrorAction SilentlyContinue ^| ^
 Where-Object { $ports -contains $_.LocalPort -and $_.State -eq 'Listen' } ^| ^
 ForEach-Object { ^
    try { ^
        Stop-Process -Id $_.OwningProcess -Force -ErrorAction Stop; ^
        Write-Host ('  [OK] Port ' + $_.LocalPort + ' released (PID ' + $_.OwningProcess + ')') ^
    } catch { ^
        Write-Host ('  [!] Could not release port ' + $_.LocalPort) ^
    } ^
}"

:: Verify
ping 127.0.0.1 -n 3 >nul

echo.
echo  [OK] Done. Ports released.
echo.
pause