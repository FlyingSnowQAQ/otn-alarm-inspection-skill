/**
 * 构建后处理脚本
 * 移除 <script type="module" crossorigin> 中的 module/crossorigin 属性，
 * 使生成的单文件 HTML 在 file:// 协议下也能正常工作（直接双击打开）。
 *
 * 用法 (在 package.json 中配置)：
 *   "build": "tsc -b && vite build && node scripts/fix-build.js"
 */

import { readFileSync, writeFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const distHtml = resolve(__dirname, '..', 'dist', 'index.html');

try {
  let html = readFileSync(distHtml, 'utf-8');

  // 移除 type="module" 和 crossorigin 属性（使脚本在 file:// 协议下可执行）
  html = html.replace(
    /<script\s+type="module"\s+crossorigin>/g,
    '<script>'
  );

  writeFileSync(distHtml, html, 'utf-8');
  console.log(`✅ fix-build: 已处理 ${distHtml}`);
  console.log('   -> 移除 type="module" 和 crossorigin 属性');
} catch (err) {
  console.error('❌ fix-build 失败:', err.message);
  process.exit(1);
}
