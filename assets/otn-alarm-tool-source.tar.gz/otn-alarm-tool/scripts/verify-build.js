/**
 * 构建验证脚本 — 在每次构建后自动检查产出物是否可用
 *
 * 用法: node scripts/verify-build.js
 * 集成在 build 脚本中: tsc -b && vite build && node scripts/fix-build.js && node scripts/verify-build.js
 */

import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const distPath = path.resolve(__dirname, '..', 'dist', 'index.html');
const PORT = 18997;

let allPass = true;

function check(label, condition) {
  const status = condition ? '✅' : '❌';
  console.log(`  ${status} ${label}`);
  if (!condition) allPass = false;
}

console.log('');
console.log('═══════════════════════════════════');
console.log('  Build Verification');
console.log('═══════════════════════════════════');
console.log('');

// 1. 文件存在性检查
console.log('── File Check ──');
const exists = fs.existsSync(distPath);
check('dist/index.html exists', exists);

if (!exists) {
  console.log('\n  ❌ FAILED: dist/index.html not found!\n');
  process.exit(1);
}

const stats = fs.statSync(distPath);
const sizeKB = (stats.size / 1024).toFixed(1);
check(`File size: ${sizeKB}KB`, sizeKB > 100);

// 2. 文件内容检查
console.log('\n── Content Check ──');
const html = fs.readFileSync(distPath, 'utf8');

// 检查关键标记
check('Has <div id="root">', /id=["']root["']/.test(html));
check('Has <script> tag (not type=module)', /<script>(?!\s*type=["']module["'])/.test(html));
  check(`No type="module" on script tag`, !/<script[^>]*type=["']module["']/.test(html));
  check(`No crossorigin attribute on script tag`, !/<script[^>]*crossorigin/.test(html));
check('Has app content (useAppStore)', html.includes('useAppStore'));

// 3. HTTP 服务检查
console.log('\n── HTTP Server Check ──');

try {
  const htmlServed = await new Promise((resolve, reject) => {
    const server = http.createServer((req, res) => {
      if (req.url === '/') {
        const raw = fs.readFileSync(distPath);
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(raw);
      } else {
        res.writeHead(404);
        res.end();
      }
    });

    server.listen(PORT, () => {
      http.get(`http://localhost:${PORT}`, (res) => {
        let data = '';
        res.on('data', (chunk) => (data += chunk));
        res.on('end', () => {
          server.close();
          resolve(data);
        });
      }).on('error', (err) => {
        server.close();
        reject(err);
      });
    });

    server.on('error', reject);
  });

  check('HTTP 200 OK', !!htmlServed);
  check('Content contains useAppStore', htmlServed.includes('useAppStore'));
  check('Content contains createRoot', htmlServed.includes('createRoot') || htmlServed.includes('ReactDOM'));
  check('Has <script> tag in served content', htmlServed.includes('<script>'));
} catch (err) {
  check('HTTP server test', false);
  console.log(`  Error: ${err.message}`);
}

// 4. 总结
console.log('');
console.log('═══════════════════════════════════');
if (allPass) {
  console.log('  ✅ ALL CHECKS PASSED');
  console.log(`  Final size: ${sizeKB}KB`);
  console.log('  Ready for deployment.');
} else {
  console.log('  ❌ SOME CHECKS FAILED');
  console.log('  Review the issues above.');
}
console.log('═══════════════════════════════════');
console.log('');

process.exit(allPass ? 0 : 1);
