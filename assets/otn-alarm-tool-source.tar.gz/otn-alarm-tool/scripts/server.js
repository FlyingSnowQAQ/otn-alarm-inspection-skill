/**
 * OTN 告警巡检工具 — 本地 HTTP 服务器
 *
 * 双击即可启动（配合 启动工具.bat），在浏览器中打开工具。
 * 使用 Node.js 内置的 http 模块，无需安装额外依赖。
 */

import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { exec } from 'node:child_process';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..', 'dist');
const PORT = 8899;
const PID_FILE = path.resolve(__dirname, '..', '.server.pid');

// Write PID file for stop.bat to read
fs.writeFileSync(PID_FILE, String(process.pid), 'utf8');
process.on('exit', () => {
  try { fs.unlinkSync(PID_FILE); } catch {}
});

/** MIME 类型映射 */
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
};

const server = http.createServer((req, res) => {
  if (req.method !== 'GET') {
    res.writeHead(405);
    return res.end('Method Not Allowed');
  }

  let urlPath = req.url === '/' ? '/index.html' : req.url;
  const filePath = path.join(root, urlPath);

  if (!filePath.startsWith(root)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }

  const ext = path.extname(filePath);
  const mimeType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, data) => {
    if (err) {
      if (err.code === 'ENOENT') {
        fs.readFile(path.join(root, 'index.html'), (err2, data2) => {
          if (err2) {
            res.writeHead(500);
            return res.end('Internal Server Error');
          }
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end(data2);
        });
      } else {
        res.writeHead(500);
        res.end('Internal Server Error');
      }
      return;
    }
    res.writeHead(200, { 'Content-Type': mimeType });
    res.end(data);
  });
});

/**
 * 启动服务器（可选端口）
 */
function startServer(port) {
  server.listen(port, () => {
    const addr = server.address();
    const actualPort = addr.port;
    const url = `http://localhost:${actualPort}`;
    console.log('');
    console.log('========================================');
    console.log('  OTN Alarm Tool is running');
    console.log('');
    console.log('  >>>  Open in browser:  ' + url + '  <<<');
    console.log('');
    console.log('  Press Ctrl+C to stop the server');
    console.log('========================================');
    console.log('');

    // Try to open browser (async, non-blocking)
    let browserOpened = false;
    try {
      const platform = process.platform;
      if (platform === 'win32') {
        // Method 1: start command (most reliable on Windows)
        exec('start "" "' + url + '"', { shell: process.env.COMSPEC || 'cmd.exe' }, (err) => {
          if (err) {
            // Method 2: try microsoft-edge protocol
            exec('cmd /c start microsoft-edge:"' + url + '"', (err2) => {
              if (err2) {
                console.log('  [!] Could not auto-open browser');
              }
            });
          }
        });
        browserOpened = true;
      } else if (platform === 'darwin') {
        exec('open "' + url + '"');
        browserOpened = true;
      } else {
        exec('xdg-open "' + url + '"');
        browserOpened = true;
      }
    } catch {
      // silent fallback
    }

    if (!browserOpened) {
      console.log('');
      console.log('  Copy this link and open in your browser:');
    }
    console.log('  ' + url);
    console.log('');
  });
}

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    const newPort = PORT + 1;
    console.log('  Port ' + PORT + ' is in use, trying ' + newPort + '...');
    startServer(newPort);
  } else {
    console.error('  Server error:', err.message);
  }
});

startServer(PORT);
