const fs = require('fs');
const raw = fs.readFileSync('C:/Users/42515/AppData/Local/Temp/ne_system.json', 'utf8');
const d = JSON.parse(raw);
const lines = d.content.split('\n');

const neMap = {};
let headerFound = false;
for (const l of lines) {
  if (!headerFound) {
    if (l.includes('网元名称') && l.includes('所属传输系统')) headerFound = true;
    continue;
  }
  if (l.startsWith('|---') || l.trim() === '') continue;
  const parts = l.split('|');
  const ne = (parts[2] || '').trim();
  const sysStr = (parts[6] || '').trim();
  if (ne && ne.startsWith('N-') && sysStr) {
    const systems = [...new Set(sysStr.split(';').map(s => s.trim()).filter(Boolean))];
    neMap[ne] = systems;
  }
}

const neCount = Object.keys(neMap).length;
const sysSet = new Set();
for (const systems of Object.values(neMap)) systems.forEach(s => sysSet.add(s));
const sysCount = sysSet.size;

let output = `/**
 * NE → 所属传输系统(复用段) 映射表
 *
 * 数据来源：网元归属传输系统-烽火.xlsx（知识库: 移动一干400G）
 * 共 ${neCount} 个NE，${sysCount} 个传输系统
 */
export const NE_SYSTEM_MAP: Record<string, string[]> = {\n`;

const entries = Object.entries(neMap).sort((a, b) => a[0].localeCompare(b[0]));
for (const [ne, systems] of entries) {
  const sysArr = systems.map(s => JSON.stringify(s)).join(', ');
  output += `  ${JSON.stringify(ne)}: [${sysArr}],\n`;
}

output += `};\n\n`;
output += `export const SYSTEM_NE_MAP: Record<string, string[]> = {};\n`;
output += `for (const [ne, systems] of Object.entries(NE_SYSTEM_MAP)) {\n`;
output += `  for (const sys of systems) {\n`;
output += `    if (!SYSTEM_NE_MAP[sys]) SYSTEM_NE_MAP[sys] = [];\n`;
output += `    if (!SYSTEM_NE_MAP[sys].includes(ne)) SYSTEM_NE_MAP[sys].push(ne);\n`;
output += `  }\n`;
output += `}\n`;

fs.writeFileSync('C:/Users/42515/AppData/Local/Temp/neSystemMap_new.ts', output, 'utf8');
console.log('NE count:', neCount);
console.log('System count:', sysCount);
console.log('File size:', fs.statSync('C:/Users/42515/AppData/Local/Temp/neSystemMap_new.ts').size, 'bytes');
